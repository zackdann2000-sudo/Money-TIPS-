// GreenScore — interações do site (sem login): tema, favoritos, filtros, abas, alertas e APIs personalizadas.
(function () {
  var TZ = "America/Sao_Paulo";
  var root = document.documentElement;
  function $(s, el) { return (el || document).querySelector(s); }
  function $$(s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); }
  // Preferências salvas em cookie (1 ano) com cópia em memória; chaves de API ficam apenas na memória.
  var MEM = {};
  var SECRETS = {};
  function readCookie(k) { var m = document.cookie.match(new RegExp("(?:^|; )" + k + "=([^;]*)")); return m ? decodeURIComponent(m[1]) : null; }
  function writeCookie(k, v) { try { document.cookie = k + "=" + encodeURIComponent(v) + "; max-age=31536000; path=/; SameSite=Lax"; } catch (e) {} }
  function load(k, d) {
    if (k in MEM) return JSON.parse(MEM[k]);
    try { var v = readCookie(k); if (v) { MEM[k] = v; return JSON.parse(v); } } catch (e) {}
    return d;
  }
  function save(k, v) {
    if (k === "gs-apis") {
      v = v.map(function (a) { if (a.key) SECRETS[a.id] = a.key; var c = Object.assign({}, a); delete c.key; return c; });
    }
    MEM[k] = JSON.stringify(v);
    writeCookie(k, MEM[k]);
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function dayKey(d) { return new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(d); }

  // ---------- tema ----------
  function setTheme(t) {
    root.classList.add("theme-anim");
    root.classList.toggle("light", t === "light");
    writeCookie("gs-theme", t);
    var m = $('meta[name="theme-color"]');
    if (m) m.setAttribute("content", t === "light" ? "#ffffff" : "#07110d");
    $$("[data-theme-label]").forEach(function (n) { n.textContent = t === "light" ? "Tema claro" : "Tema escuro"; });
    setTimeout(function () { root.classList.remove("theme-anim"); }, 250);
  }
  function currentTheme() { return root.classList.contains("light") ? "light" : "dark"; }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-theme-toggle]");
    if (b) setTheme(currentTheme() === "light" ? "dark" : "light");
    var c = e.target.closest && e.target.closest("[data-theme-set]");
    if (c) setTheme(c.getAttribute("data-theme-set"));
  });

  // ---------- toasts e notificações ----------
  function toast(title, body) {
    var wrap = $("[data-toasts]");
    if (!wrap) return;
    var t = document.createElement("div");
    t.className = "toast";
    t.innerHTML = "<strong>" + esc(title) + "</strong>" + (body ? "<div style='opacity:.8;margin-top:2px'>" + esc(body) + "</div>" : "");
    wrap.appendChild(t);
    setTimeout(function () { t.remove(); }, 6000);
  }
  var ALERT_DEFAULTS = { goal: true, start: true, half: true, end: true, red: true, lineup: false };
  function alerts() { var a = load("gs-alerts", {}); var o = {}; for (var k in ALERT_DEFAULTS) o[k] = a[k] === undefined ? ALERT_DEFAULTS[k] : a[k]; return o; }
  function notify(kind, title, body) {
    if (!alerts()[kind]) return;
    toast(title, body);
    try {
      if ("Notification" in window && Notification.permission === "granted") new Notification(title, { body: body, icon: undefined, tag: title });
    } catch (e) {}
  }

  // ---------- favoritos ----------
  function favs() { var f = load("gs-fav", {}); f.match = f.match || {}; f.team = f.team || {}; f.league = f.league || {}; return f; }
  function isFav(kind, id) { return !!favs()[kind][id]; }
  function toggleFav(kind, id, label, extra) {
    var f = favs();
    if (f[kind][id]) { delete f[kind][id]; toast("Removido dos favoritos", label); }
    else { f[kind][id] = { label: label, extra: extra || "", at: Date.now() }; toast("Adicionado aos favoritos", label + " · você receberá alertas enquanto o site estiver aberto"); }
    save("gs-fav", f);
    paintStars();
    applyFilters();
    renderFavPage();
  }
  function paintStars() {
    var f = favs();
    $$("[data-fav]").forEach(function (b) {
      var on = !!f[b.getAttribute("data-fav")][b.getAttribute("data-fav-id")];
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    var n = Object.keys(f.match).length + Object.keys(f.team).length + Object.keys(f.league).length;
    $$("[data-fav-count]").forEach(function (el) { el.textContent = String(n); });
  }
  // partida é "favorita" se ela, um dos times ou a liga estiver seguida
  function rowIsFav(row) {
    var f = favs();
    return !!(f.match[row.getAttribute("data-live-id")] || f.team[row.getAttribute("data-home-id")] || f.team[row.getAttribute("data-away-id")] || f.league[row.getAttribute("data-league-id")]);
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-fav]");
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();
    toggleFav(b.getAttribute("data-fav"), b.getAttribute("data-fav-id"), b.getAttribute("data-fav-label"), b.getAttribute("data-fav-extra"));
  });

  // ---------- placar: dias + filtros ----------
  var state = { day: null, filter: "all" };
  function labelDay(k) {
    var now = new Date();
    var today = dayKey(now), tom = dayKey(new Date(now.getTime() + 864e5)), yes = dayKey(new Date(now.getTime() - 864e5));
    var p = k.split("-");
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2], 15));
    var base = new Intl.DateTimeFormat("pt-BR", { timeZone: TZ, weekday: "short", day: "2-digit", month: "2-digit" }).format(d).replace(".", "");
    if (k === today) return "Hoje";
    if (k === tom) return "Amanhã";
    if (k === yes) return "Ontem";
    return base.charAt(0).toUpperCase() + base.slice(1);
  }
  function applyFilters() {
    var board = $("[data-board]");
    if (!board) return;
    var rows = $$(".mrow", board);
    var any = 0;
    rows.forEach(function (r) {
      var st = r.getAttribute("data-state");
      var okDay = state.filter === "live" || state.filter === "fav" || !state.day || r.getAttribute("data-day") === state.day;
      var okF = state.filter === "all" || (state.filter === "live" && st === "live") || (state.filter === "finished" && st === "finished") || (state.filter === "scheduled" && st === "scheduled") || (state.filter === "fav" && rowIsFav(r));
      var show = okDay && okF;
      r.hidden = !show;
      if (show) any++;
    });
    $$("[data-group]", board).forEach(function (g) { g.hidden = !$$(".mrow", g).some(function (r) { return !r.hidden; }); });
    var empty = $("[data-board-empty]");
    if (empty) {
      empty.hidden = any > 0;
      empty.textContent = state.filter === "fav" ? "Você ainda não segue nenhum jogo, time ou liga. Toque na estrela ★ ao lado de uma partida para seguir." : state.filter === "live" ? "Nenhum jogo ao vivo agora nas competições monitoradas." : "Nenhuma partida para este filtro.";
    }
    $$("[data-filter]").forEach(function (b) { b.setAttribute("aria-selected", b.getAttribute("data-filter") === state.filter ? "true" : "false"); });
    $$("[data-day-btn]").forEach(function (b) { b.setAttribute("aria-selected", b.getAttribute("data-day-btn") === state.day && state.filter !== "live" && state.filter !== "fav" ? "true" : "false"); });
    // contadores
    var live = rows.filter(function (r) { return r.getAttribute("data-state") === "live"; }).length;
    $$("[data-count-live]").forEach(function (n) { n.textContent = String(live); var b = n.classList.contains("bg-rose-500") ? n : n.closest(".bg-rose-500"); if (b && b.closest("[data-filter]") == null) b.hidden = live === 0; });
  }
  function initBoard() {
    var btns = $$("[data-day-btn]");
    if (!btns.length) return;
    var today = dayKey(new Date());
    btns.forEach(function (b) {
      var k = b.getAttribute("data-day-btn");
      var l = $("[data-day-label]", b);
      if (l) l.textContent = labelDay(k);
    });
    var has = btns.some(function (b) { return b.getAttribute("data-day-btn") === today; });
    state.day = has ? today : btns[0].getAttribute("data-day-btn");
    var hasLive = $$("[data-board] .mrow").some(function (r) { return r.getAttribute("data-state") === "live"; });
    if (location.hash === "#ao-vivo" && hasLive) state.filter = "live";
    applyFilters();
    var sel = $('[data-day-btn][aria-selected="true"]');
    if (sel && sel.scrollIntoView) sel.scrollIntoView({ block: "nearest", inline: "center" });
  }
  document.addEventListener("click", function (e) {
    var d = e.target.closest && e.target.closest("[data-day-btn]");
    if (d) { state.day = d.getAttribute("data-day-btn"); if (state.filter === "live" || state.filter === "fav") state.filter = "all"; applyFilters(); }
    var f = e.target.closest && e.target.closest("[data-filter]");
    if (f) { state.filter = f.getAttribute("data-filter"); applyFilters(); }
  });

  // ---------- abas genéricas ----------
  function initTabs() {
    $$("[data-tabs]").forEach(function (box) {
      var tabs = $$("[data-tab]", box);
      var panels = $$("[data-panel]", box);
      function show(id, push) {
        if (!tabs.some(function (t) { return t.getAttribute("data-tab") === id; })) id = tabs[0] && tabs[0].getAttribute("data-tab");
        tabs.forEach(function (t) { t.setAttribute("aria-selected", t.getAttribute("data-tab") === id ? "true" : "false"); });
        panels.forEach(function (p) { p.hidden = p.getAttribute("data-panel") !== id; });
        if (push && history.replaceState) history.replaceState(null, "", "#" + id);
      }
      tabs.forEach(function (t) { t.addEventListener("click", function (e) { e.preventDefault(); show(t.getAttribute("data-tab"), true); }); });
      var h = (location.hash || "").slice(1);
      show(h || box.getAttribute("data-tabs-default") || (tabs[0] && tabs[0].getAttribute("data-tab")), false);
    });
    // filtros simples de lista (ex.: notícias, esportes)
    $$("[data-chipset]").forEach(function (set) {
      var target = $(set.getAttribute("data-chipset"));
      if (!target) return;
      set.addEventListener("click", function (e) {
        var c = e.target.closest("[data-chip]");
        if (!c) return;
        var v = c.getAttribute("data-chip");
        $$("[data-chip]", set).forEach(function (x) { x.setAttribute("aria-selected", x === c ? "true" : "false"); });
        $$("[data-cat]", target).forEach(function (x) { x.hidden = v !== "all" && x.getAttribute("data-cat") !== v; });
      });
    });
  }

  // ---------- página de favoritos/alertas ----------
  function renderFavPage() {
    var box = $("[data-fav-page]");
    if (!box) return;
    var f = favs();
    var sections = [
      { k: "match", t: "Partidas", empty: "Nenhuma partida seguida." },
      { k: "team", t: "Times", empty: "Nenhum time seguido." },
      { k: "league", t: "Competições", empty: "Nenhuma competição seguida." },
    ];
    var bl = $("[data-base-link]");
    var base = bl ? (bl.getAttribute("href") || "/").replace(/index\.html$/, "") : "/";
    var sfx = base === "/" ? "" : "/index.html";
    box.innerHTML = sections.map(function (s) {
      var ids = Object.keys(f[s.k]);
      var items = ids.length ? ids.map(function (id) {
        var it = f[s.k][id];
        var href = s.k === "match" ? base + "jogos/" + id + sfx : s.k === "team" && it.extra ? base + "times/" + it.extra + sfx : s.k === "league" && it.extra ? base + "ligas/" + it.extra + sfx : "#";
        return "<li class='mrow'><button type='button' class='star' aria-pressed='true' data-fav='" + s.k + "' data-fav-id='" + esc(id) + "' data-fav-label='" + esc(it.label) + "' data-fav-extra='" + esc(it.extra) + "' aria-label='Deixar de seguir " + esc(it.label) + "'>★</button><a class='min-w-0 flex-1 truncate text-[0.78rem] font-semibold' href='" + href + "'>" + esc(it.label) + "</a></li>";
      }).join("") : "<li class='px-3 py-3 text-[0.72rem] muted'>" + s.empty + "</li>";
      return "<section class='board'><div class='board-head'>" + s.t + " <span class='muted'>· " + ids.length + "</span></div><ul>" + items + "</ul></section>";
    }).join("");
  }
  function initAlerts() {
    var box = $("[data-alert-prefs]");
    if (!box) return;
    var a = alerts();
    $$("[data-alert]", box).forEach(function (t) {
      var k = t.getAttribute("data-alert");
      t.setAttribute("aria-checked", a[k] ? "true" : "false");
      t.addEventListener("click", function () {
        var cur = load("gs-alerts", {});
        var v = t.getAttribute("aria-checked") !== "true";
        cur[k] = v;
        save("gs-alerts", cur);
        t.setAttribute("aria-checked", v ? "true" : "false");
      });
    });
    var perm = $("[data-notif-perm]");
    var st = $("[data-notif-status]");
    function paint() {
      if (!st) return;
      if (!("Notification" in window)) { st.textContent = "Este navegador não suporta notificações. Os alertas aparecem como avisos dentro do site."; return; }
      st.textContent = Notification.permission === "granted" ? "Notificações do navegador ativadas." : Notification.permission === "denied" ? "Notificações bloqueadas no navegador. Libere nas configurações do site para receber alertas." : "Notificações do navegador ainda não autorizadas.";
    }
    paint();
    if (perm) perm.addEventListener("click", function () {
      if (!("Notification" in window)) return toast("Notificações indisponíveis", "Use os avisos dentro do site.");
      Notification.requestPermission().then(function () { paint(); if (Notification.permission === "granted") notify("goal", "GreenScore", "Alertas ativados. Você será avisado dos seus favoritos."); });
    });
    var test = $("[data-notif-test]");
    if (test) test.addEventListener("click", function () { toast("Gol! (teste)", "Exemplo de alerta: Bahia 1 x 0 Vitória · 23'"); });
  }

  // ---------- APIs personalizadas ----------
  var PRESETS = {
    "api-football": { name: "API-Football (API-Sports)", base: "https://v3.football.api-sports.io", test: "/status", authType: "header", authName: "x-apisports-key", kind: "Futebol", docs: "https://www.api-football.com/documentation-v3" },
    "football-data": { name: "football-data.org", base: "https://api.football-data.org/v4", test: "/competitions", authType: "header", authName: "X-Auth-Token", kind: "Futebol", docs: "https://www.football-data.org/documentation/quickstart" },
    "the-odds-api": { name: "The Odds API", base: "https://api.the-odds-api.com/v4", test: "/sports", authType: "query", authName: "apiKey", kind: "Odds", docs: "https://the-odds-api.com/liveapi/guides/v4/" },
    "thesportsdb": { name: "TheSportsDB", base: "https://www.thesportsdb.com/api/v1/json/3", test: "/all_leagues.php", authType: "none", authName: "", kind: "Multiesporte", docs: "https://www.thesportsdb.com/documentation" },
    "sportmonks": { name: "SportMonks Football", base: "https://api.sportmonks.com/v3/football", test: "/leagues", authType: "query", authName: "api_token", kind: "Futebol", docs: "https://docs.sportmonks.com/football" },
    "espn": { name: "ESPN (pública)", base: "https://site.api.espn.com/apis/site/v2/sports", test: "/soccer/bra.1/scoreboard", authType: "none", authName: "", kind: "Multiesporte", docs: "https://site.api.espn.com/apis/site/v2/sports/soccer/bra.1/scoreboard" },
  };
  // Provedores que agora passam pelo backend (evita CORS e exposição da chave).
  var SERVER_BASES = [["https://api.football-data.org", "football-data", "football-data.org"], ["https://v3.football.api-sports.io", "api-football", "API-Football"], ["https://api.the-odds-api.com", "the-odds-api", "The Odds API"], ["https://api.sportmonks.com", "sportmonks", "SportMonks"], ["https://www.thesportsdb.com", "thesportsdb", "TheSportsDB"]];
  function apis() { return load("gs-apis", []).map(function (a) { if (SECRETS[a.id]) a.key = SECRETS[a.id]; return a; }); }
  function buildRequest(a) {
    var url = (a.base || "").replace(/\/$/, "") + (a.test ? (a.test.charAt(0) === "/" ? a.test : "/" + a.test) : "");
    var headers = {};
    if (a.authType === "header" && a.authName && a.key) headers[a.authName] = a.key;
    if (a.authType === "bearer" && a.key) headers["Authorization"] = "Bearer " + a.key;
    if (a.authType === "query" && a.authName && a.key) url += (url.indexOf("?") >= 0 ? "&" : "?") + encodeURIComponent(a.authName) + "=" + encodeURIComponent(a.key);
    return { url: url, headers: headers };
  }
  function testApi(a, out) {
    var req = buildRequest(a);
    var t0 = performance.now();
    out.innerHTML = "<p class='text-[0.7rem] muted'>Testando conexão…</p>";
    fetch(req.url, { headers: req.headers })
      .then(function (r) {
        var ms = Math.round(performance.now() - t0);
        return r.text().then(function (txt) {
          var pretty = txt;
          try { pretty = JSON.stringify(JSON.parse(txt), null, 2); } catch (e) {}
          var ok = r.ok;
          var list = apis();
          list.forEach(function (x) { if (x.id === a.id) { x.lastStatus = r.status; x.lastOk = ok; x.lastAt = Date.now(); } });
          save("gs-apis", list);
          out.innerHTML = "<p class='text-[0.72rem] font-extrabold " + (ok ? "text-emerald-300" : "text-rose-300") + "'>" + (ok ? "Conectada" : "Falhou") + " · HTTP " + r.status + " · " + ms + " ms</p><pre class='mt-1 max-h-60 overflow-auto rounded-lg bg-[var(--surface-2)] p-2 text-[0.62rem] leading-snug'>" + esc(pretty.slice(0, 4000)) + (pretty.length > 4000 ? "\n…" : "") + "</pre>";
          renderApis();
        });
      })
      .catch(function (err) {
        out.innerHTML = "<p class='text-[0.72rem] font-extrabold text-rose-300'>Não foi possível conectar</p><p class='text-[0.66rem] muted'>" + esc(err && err.message ? err.message : "Erro de rede") + ". O navegador não alcançou a API: pode ser bloqueio de CORS, rede ou endereço errado. APIs com chave (football-data.org, API-Football, The Odds API, SportMonks) devem ser cadastradas em Integrações no servidor.</p>";
      });
  }
  function renderApis() {
    var list = $("[data-api-list]");
    if (!list) return;
    var items = apis();
    var c = $("[data-api-count]");
    if (c) c.textContent = String(items.length);
    if (!items.length) { list.innerHTML = "<p class='px-3 py-4 text-center text-[0.72rem] muted'>Nenhuma API adicionada ainda. Use um modelo pronto ou preencha o formulário.</p>"; return; }
    list.innerHTML = items.map(function (a) {
      var st = a.lastAt ? (a.lastOk ? "<span class='chip !border-emerald-500/40 !text-emerald-300'>● online · HTTP " + a.lastStatus + "</span>" : "<span class='chip !border-rose-500/40 !text-rose-300'>● erro · HTTP " + (a.lastStatus || "—") + "</span>") : "<span class='chip'>não testada</span>";
      var masked = a.key ? "••••" + a.key.slice(-4) : "sem chave";
      var server = SERVER_BASES.filter(function (b) { return (a.base || "").indexOf(b[0]) === 0; })[0];
      if (server) st = "<span class='chip !border-amber-500/40 !text-amber-300'>use a integração no servidor</span> <button type='button' class='text-[0.62rem] font-bold text-[var(--brand)]' data-int-config='" + server[1] + "'>Configurar " + esc(server[2]) + "</button>";
      return "<div class='border-b border-[var(--line)] px-3 py-2.5 last:border-0' data-api-item='" + esc(a.id) + "'><div class='flex flex-wrap items-center gap-2'><p class='min-w-0 flex-1 truncate text-[0.82rem] font-extrabold'>" + esc(a.name) + " <span class='text-[0.62rem] font-semibold muted'>· " + esc(a.kind || "Geral") + "</span></p>" + st + "</div><p class='mt-0.5 truncate text-[0.64rem] muted'>" + esc(a.base) + esc(a.test || "") + " · auth: " + esc(a.authType === "none" ? "nenhuma" : a.authType + (a.authName ? " " + a.authName : "")) + " · " + esc(masked) + "</p><div class='mt-1.5 flex gap-1.5'><button type='button' class='btn btn-primary !px-2.5 !py-1 !text-[0.66rem]' data-api-test='" + esc(a.id) + "'>Testar conexão</button><button type='button' class='btn btn-ghost !px-2.5 !py-1 !text-[0.66rem]' data-api-edit='" + esc(a.id) + "'>Editar</button><button type='button' class='btn btn-ghost !px-2.5 !py-1 !text-[0.66rem]' data-api-del='" + esc(a.id) + "'>Remover</button></div><div class='mt-1.5' data-api-out></div></div>";
    }).join("");
  }
  function initApis() {
    var form = $("[data-api-form]");
    if (!form) return;
    renderApis();
    var authSel = form.elements.authType;
    function syncAuth() { var v = authSel.value; $$("[data-auth-field]", form).forEach(function (el) { el.hidden = v === "none"; }); var n = $("[data-auth-name]", form); if (n) n.hidden = v === "none" || v === "bearer"; }
    authSel.addEventListener("change", syncAuth);
    syncAuth();
    document.addEventListener("click", function (e) {
      var p = e.target.closest && e.target.closest("[data-preset]");
      if (p) {
        var x = PRESETS[p.getAttribute("data-preset")];
        if (!x) return;
        form.elements.id.value = "";
        form.elements.name.value = x.name; form.elements.base.value = x.base; form.elements.test.value = x.test; form.elements.authType.value = x.authType; form.elements.authName.value = x.authName; form.elements.kind.value = x.kind; form.elements.key.value = "";
        syncAuth();
        var d = $("[data-preset-docs]"); if (d) { d.href = x.docs; d.hidden = false; d.textContent = "Documentação de " + x.name + " ↗"; }
        form.scrollIntoView({ behavior: "smooth", block: "start" });
        if (x.authType !== "none") form.elements.key.focus();
      }
      var t = e.target.closest && e.target.closest("[data-api-test]");
      if (t) { var a = apis().filter(function (z) { return z.id === t.getAttribute("data-api-test"); })[0]; if (a) testApi(a, $("[data-api-out]", t.closest("[data-api-item]"))); }
      var del = e.target.closest && e.target.closest("[data-api-del]");
      if (del) { save("gs-apis", apis().filter(function (z) { return z.id !== del.getAttribute("data-api-del"); })); renderApis(); toast("API removida"); }
      var ed = e.target.closest && e.target.closest("[data-api-edit]");
      if (ed) { var b = apis().filter(function (z) { return z.id === ed.getAttribute("data-api-edit"); })[0]; if (b) { ["id", "name", "base", "test", "authType", "authName", "key", "kind"].forEach(function (k) { form.elements[k].value = b[k] || ""; }); syncAuth(); form.scrollIntoView({ behavior: "smooth" }); } }
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var a = {};
      ["id", "name", "base", "test", "authType", "authName", "key", "kind"].forEach(function (k) { a[k] = (form.elements[k].value || "").trim(); });
      if (!/^https?:\/\//i.test(a.base)) { toast("URL inválida", "A URL base precisa começar com https://"); form.elements.base.focus(); return; }
      if (!a.name) a.name = a.base.replace(/^https?:\/\//, "").split("/")[0];
      var list = apis();
      if (a.id) list = list.map(function (z) { return z.id === a.id ? Object.assign(z, a) : z; });
      else { a.id = "api-" + Date.now().toString(36); list.push(a); }
      save("gs-apis", list);
      form.reset(); form.elements.id.value = ""; syncAuth();
      renderApis();
      toast("API salva", a.name + " · salva somente neste navegador");
      var item = $('[data-api-item="' + a.id + '"]');
      if (item) testApi(a, $("[data-api-out]", item));
    });
    var exp = $("[data-api-export]");
    if (exp) exp.addEventListener("click", function () {
      var blob = new Blob([JSON.stringify(apis().map(function (a) { var c = Object.assign({}, a); delete c.key; return c; }), null, 2)], { type: "application/json" });
      var u = URL.createObjectURL(blob); var l = document.createElement("a"); l.href = u; l.download = "greenscore-apis.json"; l.click(); setTimeout(function () { URL.revokeObjectURL(u); }, 1000);
    });
    // status das fontes nativas
    $$("[data-source-check]").forEach(function (el) {
      var url = el.getAttribute("data-source-check");
      var t0 = performance.now();
      fetch(url).then(function (r) { el.innerHTML = r.ok ? "<span class='text-emerald-300'>● online · " + Math.round(performance.now() - t0) + " ms</span>" : "<span class='text-rose-300'>● HTTP " + r.status + "</span>"; }).catch(function () { el.innerHTML = "<span class='text-rose-300'>● sem resposta</span>"; });
    });
  }

  window.GS = { toast: toast, notify: notify, rowIsFav: rowIsFav, applyFilters: applyFilters, favs: favs, isFav: isFav };

  function init() {
    $$("[data-theme-label]").forEach(function (n) { n.textContent = currentTheme() === "light" ? "Tema claro" : "Tema escuro"; });
    paintStars();
    initBoard();
    initTabs();
    renderFavPage();
    initAlerts();
    initApis();
    paintStars();
  }
  if (window.GS_ready) window.GS_ready(init); else if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

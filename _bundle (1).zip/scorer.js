/* GREEN SCORER · interações (abas, filtros, rankings, alertas). Sem dependências. */
(function () {
  "use strict";
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function parseCond(str) {
    return (str || "").split(";").filter(Boolean).map(function (c) {
      var i = c.indexOf(":");
      return { g: c.slice(0, i), vals: c.slice(i + 1).split(",") };
    });
  }
  function matches(state, str) {
    return parseCond(str).every(function (c) { return state[c.g] === undefined || c.vals.indexOf(state[c.g]) >= 0 || c.vals.indexOf("*") >= 0; });
  }

  function initScope(scope) {
    var state = {};
    $$("[data-sx-set]", scope).forEach(function (b) {
      var p = b.getAttribute("data-sx-set").split(":");
      if (b.getAttribute("aria-selected") === "true" || b.classList.contains("on")) state[p[0]] = p[1];
      if (state[p[0]] === undefined) state[p[0]] = undefined;
    });
    // aba principal pelo hash (#estatisticas)
    var h = decodeURIComponent((location.hash || "").slice(1));
    if (h && $$('[data-sx-set="tab:' + h + '"]', scope).length) state.tab = h;

    function apply() {
      $$("[data-sx-set]", scope).forEach(function (b) {
        var p = b.getAttribute("data-sx-set").split(":");
        var on = state[p[0]] === p[1];
        b.setAttribute("aria-selected", on ? "true" : "false");
        b.classList.toggle("on", on);
      });
      $$("[data-sx-if]", scope).forEach(function (el) { el.hidden = !matches(state, el.getAttribute("data-sx-if")); });
      $$("[data-sx-list]", scope).forEach(function (list) {
        if (list.closest("[hidden]")) return;
        var limit = Number(list.getAttribute("data-limit") || 10);
        var shown = 0;
        $$("[data-sx-item]", list).forEach(function (it) {
          var ok = matches(state, it.getAttribute("data-sx-item"));
          if (ok) shown++;
          it.hidden = !ok || shown > limit;
          var n = it.querySelector("[data-rank-num]");
          if (n && ok) n.textContent = shown + "º";
        });
        var total = $$("[data-sx-item]", list).filter(function (it) { return matches(state, it.getAttribute("data-sx-item")); }).length;
        var more = list.parentNode.querySelector("[data-sx-more]");
        if (more && more.parentNode === list.parentNode) more.hidden = total <= limit;
        var empty = list.parentNode.querySelector("[data-sx-empty]");
        if (empty) empty.hidden = total > 0;
      });
      // centraliza a aba ativa na faixa rolável
      $$(".sx-scroll [aria-selected='true']", scope).forEach(function (b) {
        var bar = b.closest(".sx-scroll");
        if (bar && !bar.closest("[hidden]")) {
          var l = b.offsetLeft - (bar.clientWidth - b.offsetWidth) / 2;
          bar.scrollTo({ left: Math.max(0, l), behavior: "smooth" });
        }
      });
    }

    window.addEventListener("hashchange", function () {
      var h2 = decodeURIComponent((location.hash || "").slice(1));
      if (h2 && $$('[data-sx-set="tab:' + h2 + '"]', scope).length) { state.tab = h2; apply(); }
    });

    scope.addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("[data-sx-set]");
      if (b && scope.contains(b)) {
        var p = b.getAttribute("data-sx-set").split(":");
        state[p[0]] = p[1];
        if (p[0] === "tab" && history.replaceState) history.replaceState(null, "", "#" + p[1]);
        apply();
        return;
      }
      var more = e.target.closest && e.target.closest("[data-sx-more]");
      if (more) {
        var list = more.parentNode.querySelector("[data-sx-list]");
        if (list) { list.setAttribute("data-limit", String(Number(list.getAttribute("data-limit") || 10) + 10)); apply(); }
        return;
      }
      var row = e.target.closest && e.target.closest("[data-sx-hl] tbody tr");
      if (row) {
        $$("tr.hl", row.closest("table")).forEach(function (r) { r.classList.remove("hl"); });
        row.classList.add("hl");
      }
    });
    apply();
  }

  // ---- alertas (cookie, sem armazenamento local do navegador) ----
  function readAlerts() {
    var m = document.cookie.match(/(?:^|; )gs-alerts=([^;]*)/);
    try { return m ? JSON.parse(decodeURIComponent(m[1])) : {}; } catch (e) { return {}; }
  }
  function writeAlerts(o) {
    document.cookie = "gs-alerts=" + encodeURIComponent(JSON.stringify(o)) + "; path=/; max-age=31536000; SameSite=Lax";
  }
  function initAlerts() {
    var sw = $$("[data-sx-switch]");
    if (!sw.length) return;
    var st = readAlerts();
    sw.forEach(function (s) {
      var k = s.getAttribute("data-sx-switch");
      if (st[k] !== undefined) s.setAttribute("aria-checked", st[k] ? "true" : "false");
      s.addEventListener("click", function () {
        var on = s.getAttribute("aria-checked") !== "true";
        s.setAttribute("aria-checked", on ? "true" : "false");
        st[k] = on; writeAlerts(st);
      });
    });
    var perm = document.querySelector("[data-sx-perm]");
    var out = document.querySelector("[data-sx-perm-out]");
    function show() {
      if (!out) return;
      if (!("Notification" in window)) { out.textContent = "Este navegador não suporta notificações."; return; }
      out.textContent = Notification.permission === "granted" ? "Notificações permitidas neste navegador." : Notification.permission === "denied" ? "Notificações bloqueadas. Libere nas configurações do navegador." : "As notificações ainda não foram permitidas.";
    }
    if (perm) perm.addEventListener("click", function () {
      if ("Notification" in window && Notification.requestPermission) Notification.requestPermission().then(show, show); else show();
    });
    show();
  }

  function init() {
    $$("[data-sx-scope]").forEach(initScope);
    initAlerts();
  }
  if (window.GS_ready) window.GS_ready(init); else if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

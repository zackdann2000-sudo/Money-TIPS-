// Atualiza placares e status direto da API pública da ESPN (sem recarregar a página).
// Corrige jogos que já terminaram: nada fica "ao vivo" depois do apito final.
(function () {
  var INTERVAL = 30;
  var left = INTERVAL;
  var TZ = "America/Sao_Paulo";
  var MAXMIN = { soccer: 150, basketball: 200, hockey: 210, baseball: 300, football: 240, volleyball: 180 };
  var prev = {}; // id -> {state, h, a, half, redH, redA}

  function ymd(offset) {
    var d = new Date(Date.now() + (offset || 0) * 86400000);
    return new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(d).replace(/-/g, "");
  }
  function rows(id) { return document.querySelectorAll('[data-live-id="' + id + '"]'); }
  function paths() {
    var set = {};
    document.querySelectorAll("[data-live-id][data-path]").forEach(function (el) { set[el.getAttribute("data-path")] = 1; });
    return Object.keys(set);
  }
  function hhmm(iso) { return new Intl.DateTimeFormat("pt-BR", { timeZone: TZ, hour: "2-digit", minute: "2-digit" }).format(new Date(iso)); }
  function isFav(el) { return window.GS && window.GS.rowIsFav ? window.GS.rowIsFav(el) : false; }
  function notify(kind, title, body) { if (window.GS && window.GS.notify) window.GS.notify(kind, title, body); }

  function setStatus(el, state, text) {
    el.setAttribute("data-state", state);
    var big = el.hasAttribute("data-live-header");
    el.querySelectorAll('[data-role="status"]').forEach(function (status) {
      if (state === "live") {
        status.className = big ? "inline-flex items-center gap-1 text-[0.7rem] font-extrabold text-rose-400" : "inline-flex items-center justify-center gap-1 text-[0.62rem] font-extrabold text-rose-400";
        status.innerHTML = '<span class="live-dot !h-1.5 !w-1.5"></span> ' + text;
      } else if (state === "finished") {
        status.className = big ? "text-[0.7rem] font-bold muted" : "text-[0.6rem] font-bold muted";
        status.textContent = text || "Encerrado";
      } else {
        status.className = big ? "text-[0.7rem] font-bold muted" : "text-[0.68rem] font-extrabold";
        status.textContent = text;
      }
    });
    if (el.classList.contains("card")) el.classList.toggle("!border-rose-500/35", state === "live");
  }

  function apply(ev, path) {
    var list = rows(ev.id);
    if (!list.length) return;
    var comp = ev.competitions && ev.competitions[0];
    if (!comp) return;
    var type = (ev.status && ev.status.type) || {};
    var st = type.state;
    var cs = comp.competitors || [];
    var home = cs.filter(function (c) { return c.homeAway === "home"; })[0] || cs[0];
    var away = cs.filter(function (c) { return c.homeAway === "away"; })[0] || cs[1];
    var soccer = path.indexOf("soccer/") === 0;
    var half = type.name === "STATUS_HALFTIME";
    var clock = half ? "Intervalo" : soccer ? (ev.status.displayClock || "AO VIVO") : (type.shortDetail || "AO VIVO");
    var redH = 0, redA = 0;
    (comp.details || []).forEach(function (d) { if (d.redCard) { if (d.team && home && d.team.id === home.team.id) redH++; else redA++; } });
    var label = (home && home.team ? home.team.shortDisplayName || home.team.displayName : "") + " x " + (away && away.team ? away.team.shortDisplayName || away.team.displayName : "");
    var h = home ? String(home.score || "0") : "", a = away ? String(away.score || "0") : "";
    var p = prev[ev.id];
    list.forEach(function (el) {
      if (st === "in") setStatus(el, "live", clock);
      else if (st === "post") setStatus(el, "finished", /pen|AET|ET/i.test(type.shortDetail || "") ? "Encerrado (" + type.shortDetail.replace("FT-Pens", "pên.").replace("AET", "prorr.") + ")" : "Encerrado");
      else if (type.name === "STATUS_POSTPONED") setStatus(el, "scheduled", "Adiado");
      if (st !== "pre") {
        var hs = el.querySelectorAll('[data-role="score-home"]'), as = el.querySelectorAll('[data-role="score-away"]');
        hs.forEach(function (n) { n.textContent = h; });
        as.forEach(function (n) { n.textContent = a; });
      }
    });
    // alertas para favoritos (somente quando algo muda enquanto o site está aberto)
    var el0 = list[0];
    if (p && isFav(el0)) {
      if (p.state === "pre" && st === "in") notify("start", "Começou: " + label, "A partida está ao vivo.");
      if (st === "in" && (p.h !== h || p.a !== a) && (p.h !== "" || p.a !== "")) notify("goal", (soccer ? "Gol! " : "Placar: ") + label, h + " x " + a + " · " + clock);
      if (!p.half && half) notify("half", "Intervalo: " + label, h + " x " + a);
      if (p.state !== "post" && st === "post") notify("end", "Fim de jogo: " + label, "Placar final " + h + " x " + a);
      if (redH + redA > (p.redH + p.redA)) notify("red", "Cartão vermelho! " + label, "Expulsão na partida · " + clock);
    }
    prev[ev.id] = { state: st, h: h, a: a, half: half, redH: redH, redA: redA };
  }

  // Fallback sem internet: um jogo cujo início já passou do tempo máximo não pode continuar "ao vivo".
  function timeFallback() {
    var now = Date.now();
    document.querySelectorAll("[data-live-id][data-kickoff]").forEach(function (el) {
      var k = Date.parse(el.getAttribute("data-kickoff"));
      if (!k) return;
      var sport = (el.getAttribute("data-path") || "soccer/").split("/")[0];
      var max = (MAXMIN[sport] || 180) * 60000;
      var st = el.getAttribute("data-state");
      var mins = (now - k) / 60000;
      if (st === "live" && now - k > max) setStatus(el, "finished", "Encerrado");
      if (st === "scheduled" && now - k > max) {
        setStatus(el, "finished", "Encerrado");
      } else if (st === "scheduled" && mins > 0 && mins < max / 60000) {
        el.querySelectorAll('[data-role="status"]').forEach(function (s) { if (!/Adiado/.test(s.textContent)) s.textContent = hhmm(el.getAttribute("data-kickoff")); });
      }
    });
  }

  function sync() {
    var ps = paths();
    if (!ps.length) return;
    var dates = [ymd(-1), ymd(0)];
    ps.forEach(function (p) {
      dates.forEach(function (d) {
        fetch("https://site.api.espn.com/apis/site/v2/sports/" + p + "/scoreboard?dates=" + d)
          .then(function (r) { return r.json(); })
          .then(function (j) { (j.events || []).forEach(function (ev) { apply(ev, p); }); if (window.GS && window.GS.applyFilters) window.GS.applyFilters(); })
          .catch(function () {});
      });
    });
    document.querySelectorAll("[data-live-updated]").forEach(function (n) { n.textContent = hhmm(new Date().toISOString()); });
  }
  function tick() {
    left -= 1;
    if (left <= 0) { left = INTERVAL; sync(); }
    document.querySelectorAll("[data-live-countdown]").forEach(function (n) { n.textContent = left + "s"; });
  }
  document.addEventListener("click", function (e) {
    var t = e.target && e.target.closest && e.target.closest("[data-live-refresher]");
    if (t) { left = INTERVAL; sync(); }
  });
  function start() { timeFallback(); if (window.GS && window.GS.applyFilters) window.GS.applyFilters(); sync(); }
  if (window.GS_ready) window.GS_ready(start); else if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
  setInterval(tick, 1000);
})();

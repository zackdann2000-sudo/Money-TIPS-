/* GreenScore · integrações pelo servidor. O navegador só fala com o backend do próprio GreenScore. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function toast(t, b) { if (window.GS && window.GS.toast) window.GS.toast(t, b); }

  // Base do backend: placeholder reescrito no deploy de prévia; vazio = mesma origem (Vercel / next start).
  var raw = window.GS_API_BASE || "";
  var API = raw.indexOf("__PORT_") === 0 ? "" : raw.replace(/\/$/, "");
  var ADMIN = ""; // token só em memória
  var STATE = { reachable: null, list: [], admin: false, server: null };

  function call(method, path, body) {
    var headers = { Accept: "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (ADMIN) headers.Authorization = "Bearer " + ADMIN;
    var ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 20000) : null;
    return fetch(API + path, { method: method, headers: headers, body: body !== undefined ? JSON.stringify(body) : undefined, credentials: "same-origin", signal: ctrl ? ctrl.signal : undefined })
      .then(function (r) {
        if (timer) clearTimeout(timer);
        return r.text().then(function (t) {
          var j = null;
          try { j = JSON.parse(t); } catch (e) {}
          if (!j) return { httpStatus: r.status, json: { ok: false, error: { code: "BACKEND", message: r.status === 404 ? "O backend do GreenScore não está disponível neste endereço." : "Resposta inesperada do backend (HTTP " + r.status + ").", hint: r.status === 404 ? "A versão estática do site não tem servidor. Use a prévia com backend ou publique na Vercel." : "Tente novamente." } } };
          return { httpStatus: r.status, json: j };
        });
      })
      .catch(function (e) {
        if (timer) clearTimeout(timer);
        var aborted = e && e.name === "AbortError";
        return { httpStatus: 0, json: { ok: false, error: { code: aborted ? "TIMEOUT" : "BACKEND", message: aborted ? "O backend demorou demais para responder." : "Não foi possível falar com o backend do GreenScore.", hint: aborted ? "Tente novamente." : "Verifique se o servidor está no ar. Esta falha é entre o navegador e o GreenScore, não com o provedor." } } };
      });
  }

  var LABEL = { conectada: ["Conectada", "!border-emerald-500/40 !text-emerald-300"], pendente: ["Pendente de verificação", "!border-amber-500/40 !text-amber-300"], erro: ["Erro no último teste", "!border-rose-500/40 !text-rose-300"], "nao-configurada": ["Não configurada", ""] };
  function fmtDate(iso) { try { return new Date(iso).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }); } catch (e) { return iso; } }

  function errorHtml(err, httpStatus) {
    if (!err) return "";
    var code = err.code ? "<span class='chip !text-[0.56rem]'>" + esc(err.code) + "</span> " : "";
    var http = err.httpStatus ? " · HTTP do provedor " + esc(err.httpStatus) : httpStatus ? " · HTTP " + esc(httpStatus) : "";
    return "<div class='rounded-lg border border-rose-500/30 bg-rose-500/5 px-2.5 py-2'><p class='text-[0.7rem] font-extrabold text-rose-300'>" + code + esc(err.message) + http + "</p>" + (err.hint ? "<p class='mt-0.5 text-[0.62rem] muted'>" + esc(err.hint) + "</p>" : "") + (err.diagnosticId ? "<p class='mt-0.5 text-[0.56rem] muted'>Diagnóstico: <code>" + esc(err.diagnosticId) + "</code></p>" : "") + "</div>";
  }
  function successHtml(j, temporary) {
    var r = j.result || {};
    var bits = [];
    if (j.httpStatus) bits.push("HTTP " + j.httpStatus);
    if (j.ms !== undefined) bits.push(j.ms + " ms");
    if (r.account) bits.push("conta: " + r.account);
    if (r.plan) bits.push(r.plan);
    if (r.competitions !== undefined) bits.push(r.competitions + " competições listadas");
    if (r.quota && r.quota.remaining !== undefined) bits.push("restam " + r.quota.remaining + " req " + (r.quota.note || ""));
    var title = temporary ? "Chave válida (teste sem salvar)" : j.saved ? "Conectada e salva no servidor" : j.keptExisting ? "Conexão validada com a chave já salva" : "Conexão validada";
    var warn = (r.warnings || []).concat(j.warning ? [j.warning] : []);
    return "<div class='rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-2.5 py-2'><p class='text-[0.7rem] font-extrabold text-emerald-300'>" + esc(title) + "</p><p class='mt-0.5 text-[0.62rem] muted'>" + esc(bits.join(" · ")) + "</p>" + warn.map(function (w) { return "<p class='mt-0.5 text-[0.6rem] text-amber-300'>" + esc(w) + "</p>"; }).join("") + "</div>";
  }

  function paintBackend() {
    var st = $("[data-backend-status]");
    var info = $("[data-backend-info]");
    if (!st) return;
    if (STATE.reachable === false) { st.className = "chip !border-rose-500/40 !text-rose-300"; st.textContent = "● backend indisponível"; return; }
    if (STATE.reachable) {
      st.className = "chip !border-emerald-500/40 !text-emerald-300";
      st.textContent = STATE.admin ? "● online · modo administrador" : "● online";
      var s = STATE.server || {};
      var msgs = [];
      if (!s.adminConfigured) msgs.push("GREENSCORE_ADMIN_TOKEN não configurado no servidor: cadastro desativado.");
      if (!s.encryptionConfigured) msgs.push("GREENSCORE_ENCRYPTION_KEY ausente: só chaves por variável de ambiente.");
      if (s.adminConfigured && !STATE.admin) msgs.push(ADMIN ? "Token de administrador inválido." : "Informe o token de administrador para salvar, testar e remover.");
      if (info) info.textContent = msgs.length ? msgs.join(" ") : "Token aceito. O token fica só na memória desta aba.";
    }
  }

  function paintCards() {
    var n = 0;
    STATE.list.forEach(function (a) {
      var card = $('[data-int-card="' + a.id + '"]');
      if (!card) return;
      var lab = LABEL[a.status] || LABEL["nao-configurada"];
      if (a.status === "conectada") n++;
      var chip = $("[data-int-status]", card);
      var label = lab[0];
      if (a.configured && a.source === "public" && a.status === "conectada") label = "Conectada (chave pública)";
      if (a.configured && a.source === "env" && a.status === "nao-configurada") label = "Configurada por variável";
      chip.className = "chip " + lab[1];
      chip.textContent = "● " + label;
      var d = [];
      if (a.source === "env") d.push("Chave: variável de ambiente " + esc(a.envVar));
      else if (a.keyHint) d.push("Chave: " + esc(a.keyHint));
      else if (!a.keyRequired) d.push("Chave: pública de teste (sem cadastro)");
      if (a.lastCheckedAt) d.push("Último teste: " + esc(fmtDate(a.lastCheckedAt)));
      var lr = a.lastResult;
      var extra = "";
      if (lr && !lr.ok) extra = "<p class='text-rose-300'>" + esc(lr.message) + (lr.httpStatus ? " (HTTP " + esc(lr.httpStatus) + ")" : "") + (lr.diagnosticId ? " · " + esc(lr.diagnosticId) : "") + "</p>";
      if (lr && lr.ok && lr.quota && lr.quota.remaining !== undefined) d.push("Cota: " + esc(lr.quota.remaining) + " " + esc(lr.quota.note || ""));
      if (lr && lr.ok && lr.plan) d.push(esc(lr.plan));
      $("[data-int-detail]", card).innerHTML = "<p class='muted'>" + d.join(" · ") + "</p>" + extra;
      var rm = $("[data-int-remove]", card);
      if (rm) rm.hidden = !(a.configured && a.source === "store");
    });
    var c = $("[data-int-connected]");
    if (c) c.textContent = String(n);
    paintExploreOptions();
  }

  function refresh() {
    return call("GET", "/api/integrations").then(function (r) {
      if (!r.json || !r.json.integrations) { STATE.reachable = false; paintBackend(); return; }
      STATE.reachable = true;
      STATE.admin = !!r.json.admin;
      STATE.server = r.json.server;
      STATE.list = r.json.integrations;
      paintBackend();
      paintCards();
    });
  }

  function needAdmin(out) {
    if (STATE.reachable === false) { out.innerHTML = errorHtml({ code: "BACKEND", message: "Backend indisponível.", hint: "A versão estática do site não tem servidor. Use a prévia com backend ou a Vercel." }); return true; }
    if (STATE.server && !STATE.server.adminConfigured) { out.innerHTML = errorHtml({ code: "SERVER_CONFIG", message: "O servidor não tem GREENSCORE_ADMIN_TOKEN configurado.", hint: "Defina a variável de ambiente e reinicie o servidor." }); return true; }
    if (!STATE.admin) { out.innerHTML = errorHtml({ code: "UNAUTHORIZED", message: "Informe o token de administrador no topo da página.", hint: "Sem ele não é possível salvar, testar ou remover integrações." }); var t = $("[data-admin-token]"); if (t) t.focus(); return true; }
    return false;
  }

  function adapterInfo(id) { return STATE.list.filter(function (x) { return x.id === id; })[0]; }

  function syncForm(form) {
    var id = form.elements.provider.value;
    var a = adapterInfo(id);
    var info = $("[data-int-form-info]", form);
    var wrap = $("[data-int-key-wrap]", form);
    if (a && info) info.textContent = "Base: " + a.baseUrl + " · " + a.auth + (a.keyRequired ? "" : " · chave opcional") + (a.source === "env" ? " · chave definida por variável de ambiente" : a.keyHint ? " · chave atual " + a.keyHint : "");
    if (wrap) wrap.hidden = !!(a && a.source === "env");
    form.elements.key.placeholder = a && (a.keyHint || a.configured) ? "Deixe vazio para manter a chave atual" : a && !a.keyRequired ? "Opcional (sem chave usa a pública de teste)" : "Cole sua chave aqui";
  }

  function initForm() {
    var form = $("[data-int-form]");
    if (!form) return;
    var out = $("[data-int-form-out]", form);
    form.elements.provider.addEventListener("change", function () { syncForm(form); out.innerHTML = ""; });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (needAdmin(out)) return;
      var provider = form.elements.provider.value;
      var key = (form.elements.key.value || "").trim();
      var a = adapterInfo(provider);
      if (!key && a && a.keyRequired && !a.configured) { out.innerHTML = errorHtml({ code: "VALIDATION", message: "Informe a chave da API.", hint: "Copie a chave no painel de " + a.name + "." }); form.elements.key.focus(); return; }
      out.innerHTML = "<p class='text-[0.7rem] muted'>Testando pelo servidor…</p>";
      call("POST", "/api/integrations", { provider: provider, key: key }).then(function (r) {
        var j = r.json;
        if (j.ok) { out.innerHTML = successHtml(j, false); form.elements.key.value = ""; toast(j.saved ? "API conectada" : "Conexão validada", (a ? a.name : provider)); }
        else out.innerHTML = (j.saved ? "<p class='mb-1 text-[0.66rem] font-bold text-amber-300'>Chave salva como pendente de verificação. Ela ainda não está confirmada.</p>" : "<p class='mb-1 text-[0.66rem] font-bold muted'>Nada foi salvo.</p>") + errorHtml(j.error, r.httpStatus);
        refresh().then(function () { syncForm(form); });
      });
    });
    var temp = $("[data-int-temp]", form);
    if (temp) temp.addEventListener("click", function () {
      if (needAdmin(out)) return;
      var provider = form.elements.provider.value;
      var key = (form.elements.key.value || "").trim();
      if (!key) { out.innerHTML = errorHtml({ code: "VALIDATION", message: "Cole uma chave para testar sem salvar.", hint: "Para testar a chave já salva, use \"Testar conexão\" no cartão do provedor." }); return; }
      out.innerHTML = "<p class='text-[0.7rem] muted'>Testando pelo servidor (sem salvar)…</p>";
      call("POST", "/api/integrations/" + encodeURIComponent(provider) + "/test", { key: key }).then(function (r) {
        out.innerHTML = r.json.ok ? successHtml(r.json, true) : "<p class='mb-1 text-[0.66rem] font-bold muted'>Nada foi salvo.</p>" + errorHtml(r.json.error, r.httpStatus);
      });
    });
    form.addEventListener("reset", function () { setTimeout(function () { out.innerHTML = ""; syncForm(form); }, 0); });
    document.addEventListener("click", function (e) {
      var cfg = e.target.closest && e.target.closest("[data-int-config]");
      if (cfg) { form.elements.provider.value = cfg.getAttribute("data-int-config"); syncForm(form); out.innerHTML = ""; form.scrollIntoView({ behavior: "smooth", block: "start" }); if (!form.querySelector("[data-int-key-wrap]").hidden) form.elements.key.focus(); }
      var tb = e.target.closest && e.target.closest("[data-int-test]");
      if (tb) {
        var card = tb.closest("[data-int-card]");
        var o = $("[data-int-out]", card);
        if (needAdmin(o)) return;
        o.innerHTML = "<p class='text-[0.7rem] muted'>Testando pelo servidor…</p>";
        call("POST", "/api/integrations/" + encodeURIComponent(tb.getAttribute("data-int-test")) + "/test", {}).then(function (r) { o.innerHTML = r.json.ok ? successHtml(r.json, false) : errorHtml(r.json.error, r.httpStatus); refresh(); });
      }
      var rm = e.target.closest && e.target.closest("[data-int-remove]");
      if (rm) {
        var card2 = rm.closest("[data-int-card]");
        var o2 = $("[data-int-out]", card2);
        if (needAdmin(o2)) return;
        var id = rm.getAttribute("data-int-remove");
        if (!window.confirm("Remover a chave de " + ((adapterInfo(id) || {}).name || id) + " do servidor?")) return;
        call("DELETE", "/api/integrations/" + encodeURIComponent(id)).then(function (r) { o2.innerHTML = r.json.ok ? "<p class='text-[0.68rem] font-bold muted'>Chave removida do servidor.</p>" : errorHtml(r.json.error, r.httpStatus); refresh(); });
      }
    });
    var tok = $("[data-admin-token]");
    var apply = $("[data-admin-apply]");
    function useToken() { ADMIN = (tok.value || "").trim(); refresh().then(function () { if (STATE.admin) toast("Modo administrador ativo"); }); }
    if (apply) apply.addEventListener("click", useToken);
    if (tok) tok.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); useToken(); } });
  }

  // ---------- explorar dados ----------
  var HINTS = {
    "football-data": "Códigos: BSA (Brasileirão), PL, PD, SA, BL1, FL1, CL, CLI. Partidas: até 10 dias por consulta.",
    "api-football": "Competição = ID da liga (71 = Brasileirão). Temporada obrigatória para partidas e classificação.",
    "the-odds-api": "Competição = chave do esporte (ex.: soccer_brazil_campeonato). Placares dos últimos 3 dias (consome créditos).",
    sportmonks: "Partidas por data (De). O plano gratuito cobre poucas ligas.",
    thesportsdb: "Competição = ID numérico da liga (4351 = Brasileirão). Classificação aceita temporada.",
    espn: "Competição = código ESPN (bra.1, eng.1…). Partidas por data (De).",
  };
  function paintExploreOptions() {
    var f = $("[data-explore-form]");
    if (!f) return;
    $$("option", f.elements.provider).forEach(function (o) {
      var a = adapterInfo(o.value);
      var ops = a ? a.operations : [];
      o.textContent = (a ? a.name : o.value) + (a && !a.configured && a.keyRequired ? " (não configurado)" : "");
      o.dataset.ops = ops.join(",");
    });
    syncExplore(f);
  }
  function syncExplore(f) {
    var p = f.elements.provider.value;
    var opt = f.elements.provider.selectedOptions[0];
    var ops = (opt && opt.dataset.ops ? opt.dataset.ops : "competitions,matches,standings").split(",");
    $$("option", f.elements.resource).forEach(function (o) { o.disabled = ops.indexOf(o.value) < 0; });
    if (f.elements.resource.selectedOptions[0] && f.elements.resource.selectedOptions[0].disabled) { var first = $$("option", f.elements.resource).filter(function (o) { return !o.disabled; })[0]; if (first) f.elements.resource.value = first.value; }
    var h = $("[data-explore-hint]");
    if (h) h.textContent = HINTS[p] || "";
  }
  var KIND = { "ao-vivo": "Dados ao vivo", "agenda-e-resultados": "Agenda e resultados", historico: "Dados consolidados", catalogo: "Catálogo do provedor" };
  var STATUS = { agendado: "Agendado", "ao-vivo": "Ao vivo", intervalo: "Intervalo", encerrado: "Encerrado", adiado: "Adiado", cancelado: "Cancelado", suspenso: "Suspenso", desconhecido: "—" };
  function renderData(j) {
    var head = "<div class='flex flex-wrap items-center gap-1.5 border-b border-[var(--line)] px-3 py-2 text-[0.6rem]'><span class='chip !border-emerald-500/40 !text-emerald-300'>Fonte: " + esc(j.providerName) + "</span><span class='chip'>" + esc(KIND[j.dataKind] || j.dataKind) + "</span><span class='muted'>Atualizado às " + esc(fmtDate(j.fetchedAt)) + (j.cached ? " (cache)" : "") + "</span></div>";
    var notes = (j.notes || []).map(function (n) { return "<p class='px-3 pt-1 text-[0.58rem] muted'>" + esc(n) + "</p>"; }).join("");
    var d = j.data;
    var body = "";
    if (j.operation === "competitions") {
      if (!d.length) body = "<p class='px-3 py-4 text-center text-[0.7rem] muted'>Nenhuma competição retornada.</p>";
      else body = d.slice(0, 200).map(function (c) { return "<div class='mrow !py-1.5'><span class='w-14 shrink-0 text-[0.62rem] font-bold'>" + esc(c.code || c.id) + "</span><span class='min-w-0 flex-1 truncate text-[0.72rem]'>" + esc(c.name) + "</span><span class='shrink-0 text-[0.56rem] muted'>" + esc([c.area, c.plan].filter(Boolean).join(" · ")) + "</span></div>"; }).join("");
    } else if (j.operation === "matches") {
      if (!d.length) body = "<p class='px-3 py-4 text-center text-[0.7rem] muted'>Nenhuma partida no período informado.</p>";
      else body = d.slice(0, 200).map(function (m) {
        var sc = m.score.home === null || m.score.away === null ? "–" : m.score.home + " x " + m.score.away;
        var live = m.status === "ao-vivo" || m.status === "intervalo";
        return "<div class='mrow !py-1.5'><span class='w-24 shrink-0 text-[0.58rem] " + (live ? "font-bold text-rose-400" : "muted") + "'>" + esc(STATUS[m.status] || m.status) + "<br>" + esc(fmtDate(m.kickoff)) + "</span><span class='min-w-0 flex-1 truncate text-[0.72rem]'>" + esc(m.home.name) + " <b>" + esc(sc) + "</b> " + esc(m.away.name) + "</span><span class='hidden shrink-0 text-[0.56rem] muted sm:inline'>" + esc(m.competition || "") + "</span></div>";
      }).join("");
    } else {
      body = (d.groups || []).map(function (g) {
        return "<p class='px-3 pt-2 text-[0.64rem] font-extrabold'>" + esc(g.name) + "</p><div class='overflow-x-auto'><table class='w-full text-[0.66rem]'><thead><tr class='muted'><th class='px-2 text-left'>#</th><th class='text-left'>Time</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th><th class='px-2'>P</th></tr></thead><tbody>" + g.rows.map(function (r) { return "<tr class='border-t border-[var(--line)]'><td class='px-2 py-1'>" + r.position + "</td><td class='max-w-[10rem] truncate'>" + esc(r.team.name) + "</td><td class='text-center'>" + r.played + "</td><td class='text-center'>" + r.won + "</td><td class='text-center'>" + r.draw + "</td><td class='text-center'>" + r.lost + "</td><td class='text-center'>" + (r.goalDifference === null ? "–" : r.goalDifference) + "</td><td class='px-2 text-center font-extrabold'>" + r.points + "</td></tr>"; }).join("") + "</tbody></table></div>";
      }).join("") || "<p class='px-3 py-4 text-center text-[0.7rem] muted'>Sem classificação disponível.</p>";
    }
    return head + notes + body;
  }
  function query(params) {
    var qs = Object.keys(params).filter(function (k) { return params[k]; }).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]); }).join("&");
    return call("GET", "/api/football/" + params.resource + "?" + qs.replace(/(^|&)resource=[^&]*/, ""));
  }
  function initExplore() {
    var f = $("[data-explore-form]");
    if (!f) return;
    var out = $("[data-explore-out]");
    var today = new Date();
    var iso = function (d) { return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
    f.elements.dateFrom.value = iso(new Date(today.getTime() - 2 * 86400000));
    f.elements.dateTo.value = iso(new Date(today.getTime() + 3 * 86400000));
    f.elements.competition.value = "BSA";
    f.elements.provider.addEventListener("change", function () { syncExplore(f); });
    f.addEventListener("submit", function (e) {
      e.preventDefault();
      var p = {};
      ["provider", "resource", "competition", "dateFrom", "dateTo", "season"].forEach(function (k) { p[k] = (f.elements[k].value || "").trim(); });
      if (p.resource === "competitions") { p.dateFrom = p.dateTo = p.competition = ""; }
      if (p.resource === "standings") { p.dateFrom = p.dateTo = ""; }
      out.innerHTML = "<div class='space-y-1.5 p-3'><div class='h-3 w-1/2 animate-pulse rounded bg-[var(--surface-2)]'></div><div class='h-3 w-3/4 animate-pulse rounded bg-[var(--surface-2)]'></div><div class='h-3 w-2/3 animate-pulse rounded bg-[var(--surface-2)]'></div></div>";
      query(p).then(function (r) { out.innerHTML = r.json.ok ? renderData(r.json) : "<div class='p-3'>" + errorHtml(r.json.error, r.httpStatus) + "</div>"; });
    });
  }

  // ---------- widget da página de liga ----------
  function initLeagueWidgets() {
    $$("[data-ext-standings]").forEach(function (box) {
      var st = $("[data-ext-status]", box);
      var body = $("[data-ext-body]", box);
      query({ resource: "standings", provider: box.getAttribute("data-provider"), competition: box.getAttribute("data-competition") }).then(function (r) {
        var j = r.json;
        if (j.ok) { st.textContent = "Atualizado às " + fmtDate(j.fetchedAt) + (j.cached ? " (cache)" : ""); body.innerHTML = renderData(j); body.classList.remove("muted"); return; }
        var code = j.error && j.error.code;
        if (code === "AUTH_MISSING" || code === "BACKEND") { st.textContent = code === "BACKEND" ? "Backend indisponível nesta versão" : "Não conectado"; return; }
        st.textContent = "Indisponível";
        body.innerHTML = errorHtml(j.error, r.httpStatus);
      });
    });
  }

  function init() {
    initForm();
    initExplore();
    initLeagueWidgets();
    if ($("[data-backend-panel]")) refresh().then(function () { var f = $("[data-int-form]"); if (f) syncForm(f); });
  }
  if (window.GS_ready) window.GS_ready(init); else if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

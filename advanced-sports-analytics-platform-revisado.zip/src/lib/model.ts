/**
 * Modelo preditivo GreenScore — v1.0
 * Poisson bivariado com correção de Dixon-Coles para placares baixos,
 * ratings de ataque/defesa por time, vantagem de mando estimada e
 * ponderação temporal exponencial (meia-vida configurável).
 *
 * Toda probabilidade sai da MESMA matriz de placares, o que garante
 * consistência matemática entre 1X2, over/under, BTTS e placares.
 */

export const MODEL_VERSION = "dc-poisson-1.0";
export const HALF_LIFE_DAYS = 120;
const MAX_GOALS = 8;
const RHO_GRID = [-0.2, -0.15, -0.1, -0.05, 0, 0.05];

export type HistMatch = { date: Date; home: string; away: string; hg: number; ag: number; neutral?: boolean };

export type TeamRating = { attack: number; defense: number; n: number; weight: number };
export type FittedModel = {
  teams: Map<string, TeamRating>;
  homeAdv: number;
  leagueAvgHome: number;
  leagueAvgAway: number;
  rho: number;
  matchesUsed: number;
  asOf: Date;
};

const weightFor = (date: Date, asOf: Date) => Math.pow(0.5, Math.max(0, asOf.getTime() - date.getTime()) / 86400000 / HALF_LIFE_DAYS);

/** Ajuste por mínimos quadrados ponderados iterativos (IPF multiplicativo) com encolhimento para a média. */
export function fitModel(history: HistMatch[], asOf = new Date()): FittedModel | null {
  const data = history.filter((m) => m.date.getTime() <= asOf.getTime());
  if (data.length < 20) return null;
  const teams = new Map<string, TeamRating>();
  let wSum = 0, hgSum = 0, agSum = 0;
  for (const m of data) {
    const w = weightFor(m.date, asOf);
    wSum += w; hgSum += m.hg * w; agSum += m.ag * w;
    for (const t of [m.home, m.away]) if (!teams.has(t)) teams.set(t, { attack: 1, defense: 1, n: 0, weight: 0 });
    teams.get(m.home)!.n += 1; teams.get(m.away)!.n += 1;
    teams.get(m.home)!.weight += w; teams.get(m.away)!.weight += w;
  }
  const avgHome = hgSum / wSum;
  const avgAway = agSum / wSum;
  let homeAdv = Math.max(1, avgHome / Math.max(0.3, avgAway));
  const PRIOR = 4; // peso (em jogos) do encolhimento para 1.0

  for (let iter = 0; iter < 40; iter++) {
    // ataque
    for (const [name, r] of teams) {
      let num = PRIOR, den = PRIOR;
      for (const m of data) {
        const w = weightFor(m.date, asOf);
        if (m.home === name) { num += w * m.hg / avgAway; den += w * (m.neutral ? 1 : homeAdv) * teams.get(m.away)!.defense; }
        if (m.away === name) { num += w * m.ag / avgAway; den += w * teams.get(m.home)!.defense; }
      }
      r.attack = num / den;
    }
    // defesa
    for (const [name, r] of teams) {
      let num = PRIOR, den = PRIOR;
      for (const m of data) {
        const w = weightFor(m.date, asOf);
        if (m.home === name) { num += w * m.ag / avgAway; den += w * teams.get(m.away)!.attack; }
        if (m.away === name) { num += w * m.hg / avgAway; den += w * (m.neutral ? 1 : homeAdv) * teams.get(m.home)!.attack; }
      }
      r.defense = num / den;
    }
    // normalização (média geométrica 1) e vantagem de mando
    const names = [...teams.keys()];
    const gA = Math.exp(names.reduce((s, n) => s + Math.log(teams.get(n)!.attack), 0) / names.length);
    const gD = Math.exp(names.reduce((s, n) => s + Math.log(teams.get(n)!.defense), 0) / names.length);
    for (const r of teams.values()) { r.attack /= gA; r.defense /= gD; }
    let num = 0, den = 0;
    for (const m of data) {
      if (m.neutral) continue;
      const w = weightFor(m.date, asOf);
      num += w * m.hg / avgAway;
      den += w * teams.get(m.home)!.attack * teams.get(m.away)!.defense;
    }
    homeAdv = Math.min(2, Math.max(0.9, num / den));
  }
  // rho (Dixon-Coles) por máxima verossimilhança em grade
  let bestRho = 0, bestLL = -Infinity;
  for (const rho of RHO_GRID) {
    let ll = 0;
    for (const m of data) {
      const w = weightFor(m.date, asOf);
      const { lh, la } = lambdas({ teams, homeAdv, leagueAvgHome: avgHome, leagueAvgAway: avgAway, rho, matchesUsed: data.length, asOf }, m.home, m.away, m.neutral);
      const p = scoreProb(lh, la, m.hg, m.ag, rho);
      ll += w * Math.log(Math.max(1e-9, p));
    }
    if (ll > bestLL) { bestLL = ll; bestRho = rho; }
  }
  return { teams, homeAdv, leagueAvgHome: avgHome, leagueAvgAway: avgAway, rho: bestRho, matchesUsed: data.length, asOf };
}

export function lambdas(model: FittedModel, home: string, away: string, neutral = false) {
  const h = model.teams.get(home) ?? { attack: 1, defense: 1, n: 0, weight: 0 };
  const a = model.teams.get(away) ?? { attack: 1, defense: 1, n: 0, weight: 0 };
  const lh = model.leagueAvgAway * h.attack * a.defense * (neutral ? 1 : model.homeAdv);
  const la = model.leagueAvgAway * a.attack * h.defense;
  return { lh: Math.min(5, Math.max(0.15, lh)), la: Math.min(5, Math.max(0.15, la)) };
}

const fact = (n: number): number => (n <= 1 ? 1 : n * fact(n - 1));
const pois = (l: number, k: number) => (Math.exp(-l) * Math.pow(l, k)) / fact(k);

function tau(lh: number, la: number, x: number, y: number, rho: number) {
  if (x === 0 && y === 0) return 1 - lh * la * rho;
  if (x === 0 && y === 1) return 1 + lh * rho;
  if (x === 1 && y === 0) return 1 + la * rho;
  if (x === 1 && y === 1) return 1 - rho;
  return 1;
}

export function scoreProb(lh: number, la: number, x: number, y: number, rho: number) {
  return Math.max(0, tau(lh, la, x, y, rho) * pois(lh, x) * pois(la, y));
}

export type Markets = {
  home: number; draw: number; away: number;
  over05: number; over15: number; over25: number; over35: number; under25: number;
  btts: number; homeScores: number; awayScores: number;
  lambdaHome: number; lambdaAway: number;
  scorelines: { score: string; p: number }[];
  homeGoalsRange: [number, number]; awayGoalsRange: [number, number];
};

/** Deriva todos os mercados a partir da matriz de placares (normalizada). */
export function markets(lh: number, la: number, rho: number, startHome = 0, startAway = 0): Markets {
  const grid: number[][] = [];
  let total = 0;
  for (let x = 0; x <= MAX_GOALS; x++) {
    grid[x] = [];
    for (let y = 0; y <= MAX_GOALS; y++) { grid[x][y] = scoreProb(lh, la, x, y, rho); total += grid[x][y]; }
  }
  let home = 0, draw = 0, away = 0, over05 = 0, over15 = 0, over25 = 0, over35 = 0, btts = 0, homeScores = 0, awayScores = 0;
  const lines: { score: string; p: number }[] = [];
  const hDist = new Array(MAX_GOALS + 1).fill(0), aDist = new Array(MAX_GOALS + 1).fill(0);
  for (let x = 0; x <= MAX_GOALS; x++) for (let y = 0; y <= MAX_GOALS; y++) {
    const p = grid[x][y] / total;
    const fx = x + startHome, fy = y + startAway, tot = fx + fy;
    if (fx > fy) home += p; else if (fx === fy) draw += p; else away += p;
    if (tot > 0) over05 += p; if (tot > 1) over15 += p; if (tot > 2) over25 += p; if (tot > 3) over35 += p;
    if (fx > 0 && fy > 0) btts += p; if (fx > 0) homeScores += p; if (fy > 0) awayScores += p;
    hDist[Math.min(MAX_GOALS, fx)] += p; aDist[Math.min(MAX_GOALS, fy)] += p;
    lines.push({ score: `${fx}-${fy}`, p });
  }
  const range = (dist: number[]): [number, number] => {
    let cum = 0, lo = 0, hi = MAX_GOALS;
    for (let i = 0; i < dist.length; i++) { cum += dist[i]; if (cum >= 0.15) { lo = i; break; } }
    cum = 0;
    for (let i = 0; i < dist.length; i++) { cum += dist[i]; if (cum >= 0.85) { hi = i; break; } }
    return [lo, hi];
  };
  lines.sort((a, b) => b.p - a.p);
  return {
    home, draw, away, over05, over15, over25, over35, under25: 1 - over25, btts, homeScores, awayScores,
    lambdaHome: lh + startHome, lambdaAway: la + startAway,
    scorelines: lines.slice(0, 8),
    homeGoalsRange: range(hDist), awayGoalsRange: range(aDist),
  };
}

/** Atualização ao vivo: gols restantes ~ Poisson(λ × fração restante), somados ao placar atual. */
export function liveMarkets(lh: number, la: number, rho: number, minute: number, homeScore: number, awayScore: number) {
  const remaining = Math.max(0, Math.min(1, (90 - minute) / 90));
  // após o 1º tempo, o rho de placar baixo perde sentido — zera a correção
  const rhoLive = minute > 20 ? 0 : rho;
  return markets(Math.max(0.02, lh * remaining), Math.max(0.02, la * remaining), rhoLive, homeScore, awayScore);
}

/* ------------------------- Modelo simplificado (fallback) ------------------------- */

export const FALLBACK_MODEL_VERSION = "fallback-simples-1.0";

export type SimpleInputs = { homeGames: HistMatch[]; awayGames: HistMatch[]; homeExt: string; awayExt: string; leagueAvgGoals?: number; homeAdv?: number };

/**
 * Fallback quando a equipe tem < 5 jogos na competição: usa a média simples de gols
 * marcados/sofridos das últimas 10 partidas gerais de cada time (qualquer competição),
 * com encolhimento para a média da liga proporcional ao tamanho da amostra, e vantagem
 * de mando padrão. As probabilidades continuam saindo da matriz de placares (Poisson, ρ=0).
 */
export function simpleLambdas(inp: SimpleInputs) {
  const leagueAvg = inp.leagueAvgGoals ?? 2.7; // gols por jogo (soma)
  const perSide = leagueAvg / 2;
  const homeAdv = inp.homeAdv ?? 1.2;
  const rate = (games: HistMatch[], team: string) => {
    if (!games.length) return { gf: perSide, ga: perSide, n: 0 };
    let gf = 0, ga = 0;
    for (const g of games) { const home = g.home === team; gf += home ? g.hg : g.ag; ga += home ? g.ag : g.hg; }
    const n = games.length;
    const w = n / (n + 3); // encolhimento: 3 jogos "virtuais" na média da liga
    return { gf: w * (gf / n) + (1 - w) * perSide, ga: w * (ga / n) + (1 - w) * perSide, n };
  };
  const h = rate(inp.homeGames, inp.homeExt), a = rate(inp.awayGames, inp.awayExt);
  // λ casa = média entre ataque da casa e defesa do visitante (e vice-versa), com fator casa dividido
  const lh = Math.min(5, Math.max(0.2, ((h.gf + a.ga) / 2) * Math.sqrt(homeAdv)));
  const la = Math.min(5, Math.max(0.2, ((a.gf + h.ga) / 2) / Math.sqrt(homeAdv)));
  return { lh, la, sampleHome: h.n, sampleAway: a.n };
}

/* ------------------------------- Avaliação ------------------------------- */

export type EvalRow = { pHome: number; pDraw: number; pAway: number; pOver25: number; pBtts: number; hg: number; ag: number; league: string; date: Date };

export function brierMulti(p: [number, number, number], outcome: 0 | 1 | 2) {
  return p.reduce((s, pi, i) => s + Math.pow(pi - (i === outcome ? 1 : 0), 2), 0);
}
export function logLoss(pOutcome: number) {
  return -Math.log(Math.max(1e-6, pOutcome));
}

export function outcomeOf(hg: number, ag: number): 0 | 1 | 2 {
  return hg > ag ? 0 : hg === ag ? 1 : 2;
}

/**
 * Backtest temporal: para cada jogo (a partir do mínimo de histórico), o modelo é ajustado
 * SOMENTE com partidas anteriores à data do jogo. Referência: frequências 1X2 e over 2,5
 * observadas até aquela data (modelo "ingênuo").
 */
export function backtest(history: HistMatch[], opts: { minPrior?: number; step?: number } = {}) {
  const sorted = [...history].sort((a, b) => a.date.getTime() - b.date.getTime());
  const minPrior = opts.minPrior ?? 60;
  const step = opts.step ?? 1;
  const rows: EvalRow[] = [];
  const baseRows: { p: [number, number, number]; pOver: number; hg: number; ag: number }[] = [];
  let cache: { key: string; model: FittedModel | null } | null = null;
  for (let i = minPrior; i < sorted.length; i += step) {
    const m = sorted[i];
    const dayKey = m.date.toISOString().slice(0, 10);
    if (!cache || cache.key !== dayKey) {
      const asOf = new Date(m.date.getTime() - 1);
      cache = { key: dayKey, model: fitModel(sorted.slice(0, i), asOf) };
    }
    const model = cache.model;
    if (!model) continue;
    const th = model.teams.get(m.home), ta = model.teams.get(m.away);
    if (!th || !ta || th.n < 5 || ta.n < 5) continue;
    const { lh, la } = lambdas(model, m.home, m.away, m.neutral);
    const mk = markets(lh, la, model.rho);
    rows.push({ pHome: mk.home, pDraw: mk.draw, pAway: mk.away, pOver25: mk.over25, pBtts: mk.btts, hg: m.hg, ag: m.ag, league: "", date: m.date });
    const prior = sorted.slice(0, i);
    const n = prior.length;
    const fh = prior.filter((x) => x.hg > x.ag).length / n, fd = prior.filter((x) => x.hg === x.ag).length / n;
    const fo = prior.filter((x) => x.hg + x.ag > 2).length / n;
    baseRows.push({ p: [fh, fd, 1 - fh - fd], pOver: fo, hg: m.hg, ag: m.ag });
  }
  return summarize(rows, baseRows);
}

export function summarize(rows: EvalRow[], baseRows: { p: [number, number, number]; pOver: number; hg: number; ag: number }[]) {
  const n = rows.length;
  if (!n) return null;
  let brier = 0, ll = 0, brierOver = 0, llOver = 0, bBrier = 0, bLL = 0, bBrierOver = 0, correct = 0, bCorrect = 0;
  const bins = Array.from({ length: 10 }, () => ({ sumP: 0, hits: 0, n: 0 }));
  rows.forEach((r, i) => {
    const o = outcomeOf(r.hg, r.ag);
    const p: [number, number, number] = [r.pHome, r.pDraw, r.pAway];
    brier += brierMulti(p, o); ll += logLoss(p[o]);
    const over = r.hg + r.ag > 2 ? 1 : 0;
    brierOver += Math.pow(r.pOver25 - over, 2); llOver += logLoss(over ? r.pOver25 : 1 - r.pOver25);
    if (p.indexOf(Math.max(...p)) === o) correct += 1;
    const b = baseRows[i];
    bBrier += brierMulti(b.p, o); bLL += logLoss(Math.max(1e-6, b.p[o])); bBrierOver += Math.pow(b.pOver - over, 2);
    if (b.p.indexOf(Math.max(...b.p)) === o) bCorrect += 1;
    // calibração: probabilidade do favorito do modelo
    const fav = Math.max(...p);
    const bin = Math.min(9, Math.floor(fav * 10));
    bins[bin].sumP += fav; bins[bin].n += 1; if (p.indexOf(fav) === o) bins[bin].hits += 1;
  });
  return {
    n,
    brier: brier / n, logLoss: ll / n, accuracy: correct / n,
    brierOver25: brierOver / n, logLossOver25: llOver / n,
    baseline: { brier: bBrier / n, logLoss: bLL / n, accuracy: bCorrect / n, brierOver25: bBrierOver / n },
    calibration: bins.map((b, i) => ({ range: `${i * 10}-${i * 10 + 10}%`, n: b.n, predicted: b.n ? b.sumP / b.n : null, observed: b.n ? b.hits / b.n : null })).filter((b) => b.n > 0),
  };
}

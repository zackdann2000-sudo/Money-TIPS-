import { and, eq, inArray, sql } from "drizzle-orm";
import webpush from "web-push";
import { db } from "@/db";
import { pushSubscriptions } from "@/db/schema";
import { VAPID_PRIVATE_KEY, VAPID_PUBLIC_KEY, VAPID_SUBJECT } from "@/lib/vapid-keys";

/* ====================================================================== */
/*  Web Push nativo (VAPID) — envio do servidor para o celular/desktop     */
/*  mesmo com o site fechado. Chaves fixas em src/lib/vapid-keys.ts        */
/*  (a privada só é lida aqui, no servidor).                               */
/* ====================================================================== */

const PUBLIC_KEY = VAPID_PUBLIC_KEY;
const PRIVATE_KEY = VAPID_PRIVATE_KEY;
const SUBJECT = VAPID_SUBJECT;

let configured = false;
function ensureConfigured() {
  if (configured) return true;
  // Chaves VAPID fixas no servidor (pública + privada) — par validado com web-push
  webpush.setVapidDetails(
    "mailto:zackdann2000@gmail.com",
    "BKhuZ7nBFVRlc05eRSMpZylx3OVimtudepf-5qLEHVIM83frLg50lyTz8qnHuMLA01BIw8DBAza5pONrM8sSh7M",
    "AXFUwKc7qtno7Wa06svSP0NogFYqnRwnQ1T0gGfZrRE",
  );
  configured = true;
  return true;
}

export const pushEnabled = () => Boolean(PUBLIC_KEY && PRIVATE_KEY);
export const vapidPublicKey = () => PUBLIC_KEY;

export type PushPayload = { title: string; body: string; url?: string; tag?: string; type?: string; icon?: string };

type SubscriptionJSON = { endpoint: string; keys: { p256dh: string; auth: string } };

export async function salvarSubscription(userId: number, sub: SubscriptionJSON, userAgent = "") {
  if (!sub?.endpoint || !sub.keys?.p256dh || !sub.keys?.auth) throw new Error("Subscription inválida.");
  await db
    .insert(pushSubscriptions)
    .values({ userId, endpoint: sub.endpoint, p256dh: sub.keys.p256dh, auth: sub.keys.auth, userAgent: userAgent.slice(0, 300) })
    .onConflictDoUpdate({ target: pushSubscriptions.endpoint, set: { userId, p256dh: sub.keys.p256dh, auth: sub.keys.auth, userAgent: userAgent.slice(0, 300), failures: 0 } });
}

export async function removerSubscription(endpoint: string, userId?: number) {
  await db.delete(pushSubscriptions).where(userId ? and(eq(pushSubscriptions.endpoint, endpoint), eq(pushSubscriptions.userId, userId)) : eq(pushSubscriptions.endpoint, endpoint));
}

export async function listarSubscriptions(userId: number) {
  return db.select({ id: pushSubscriptions.id, endpoint: pushSubscriptions.endpoint, userAgent: pushSubscriptions.userAgent, createdAt: pushSubscriptions.createdAt, lastUsedAt: pushSubscriptions.lastUsedAt }).from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
}

/**
 * enviarNotificacao(userId, titulo, mensagem)
 * Recupera todas as inscrições do usuário e envia via webpush.sendNotification.
 * 404/410 (inscrição expirada/cancelada) → remove do banco.
 */
export async function enviarNotificacao(userId: number, titulo: string, mensagem: string, extra: Omit<PushPayload, "title" | "body"> = {}) {
  if (!ensureConfigured()) return { enviadas: 0, removidas: 0, erro: "VAPID não configurado" };
  const subs = await db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
  if (!subs.length) return { enviadas: 0, removidas: 0 };
  const payload = JSON.stringify({ title: titulo, body: mensagem, url: extra.url ?? "/notificacoes", tag: extra.tag ?? "greenscore", type: extra.type ?? "info", icon: extra.icon ?? "/icon.svg" } satisfies PushPayload);
  let enviadas = 0;
  const expiradas: string[] = [];
  const falhas: number[] = [];
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload, { TTL: 60 * 60, urgency: extra.type === "goal" ? "high" : "normal" });
        enviadas += 1;
      } catch (error) {
        const status = (error as { statusCode?: number }).statusCode;
        if (status === 404 || status === 410) expiradas.push(s.endpoint); // inscrição morta → remover
        else falhas.push(s.id);
        console.error("web-push", status, s.endpoint.slice(0, 48), (error as Error).message);
      }
    }),
  );
  if (expiradas.length) await db.delete(pushSubscriptions).where(inArray(pushSubscriptions.endpoint, expiradas));
  if (falhas.length) await db.update(pushSubscriptions).set({ failures: sql`${pushSubscriptions.failures} + 1` }).where(inArray(pushSubscriptions.id, falhas));
  if (enviadas) await db.update(pushSubscriptions).set({ lastUsedAt: new Date() }).where(and(eq(pushSubscriptions.userId, userId)));
  return { enviadas, removidas: expiradas.length, falhas: falhas.length };
}

/** Envia para vários usuários (usado pelos alertas de favoritos). Não bloqueia o fluxo principal. */
export function enviarParaUsuarios(userIds: number[], titulo: string, mensagem: string, extra: Omit<PushPayload, "title" | "body"> = {}) {
  if (!pushEnabled() || !userIds.length) return;
  void Promise.allSettled(userIds.map((id) => enviarNotificacao(id, titulo, mensagem, extra)));
}

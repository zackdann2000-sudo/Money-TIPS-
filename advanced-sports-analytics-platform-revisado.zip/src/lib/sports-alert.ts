import { callIntegration, getIntegration } from "@/lib/providers";

/* ====================================================================== */
/*  Feed estilo "Sports Alert" — formato de saída idêntico ao do app:       */
/*  { kickoff_utc, status, isLive, isFinished, homeTeamLogo, awayTeamLogo,  */
/*    leagueId, country, basicStats }                                       */
/*  Fonte primária: Sportmonks v3 (sua chave no painel).                   */
/*  Fallback: Bzzoiro (já ativa) — mesmo formato de saída.                  */
/* ====================================================================== */

export type SportsAlertStatus = "scheduled" | "live" | "halftime" | "finished" | "postponed" | "cancelled";

export type BasicStats = {
  xg: { home: number | null; away: number | null };
  possession: { home: number | null; away: number | null };
  shots: { home: number | null; away: number | null };
  shotsOnTarget: { home: number | null; away: number | null };
  corners: { home: number | null; away: number | null };
  updatedAt: string;
  source: "sportmonks" | "bzzoiro";
};

export type SportsAlertMatch = {
  id: number;
  kickoff_utc: string;
  status: SportsAlertStatus;
  isLive: boolean;
  isFinished: boolean;
  homeTeamLogo: string;
  awayTeamLogo: string;
  leagueId: number;
  country: string;
  basicStats: BasicStats | null;
  // campos de apoio para o card (o app original também os entrega em outro nó)
  homeTeam: string;
  awayTeam: string;
  leagueName: string;
  homeScore: number | null;
  awayScore: number | null;
  minute: number | null;
  source: "sportmonks" | "bzzoiro";
};

export type SportsAlertFeed = { date: string; source: "sportmonks" | "bzzoiro" | "none"; matches: SportsAlertMatch[]; error?: string; fallbackReason?: string };

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);
const feedCache = new Map<string, { at: number; feed: SportsAlertFeed }>();
const statsCache = new Map<string, { at: number; stats: BasicStats | null }>();
const FEED_TTL = 60_000;
const STATS_TTL = 30_000;

/** Dia "de hoje" no fuso de Brasília (o app agrupa jogos pelo dia local do usuário). */
export function todayUtcDate(offset = 0) {
  const d = new Date(Date.now() + offset * 86400000);
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

/* ------------------------------- Sportmonks ------------------------------- */

type SmFixture = {
  id: number;
  league_id: number;
  starting_at: string; // "2026-10-19 15:20:00" (UTC)
  starting_at_timestamp?: number;
  state?: { state?: string; short_name?: string; developer_name?: string };
  state_id?: number;
  league?: { id: number; name: string; country_id?: number; country?: { name?: string } };
  participants?: { id: number; name: string; image_path?: string; meta?: { location?: "home" | "away" } }[];
  scores?: { description?: string; score?: { goals?: number; participant?: "home" | "away" } }[];
  periods?: { ticking?: boolean; minutes?: number; time_added?: number }[];
};

// Estados Sportmonks v3 (state_id → significado). Ref.: docs "States".
const SM_LIVE_STATES = new Set(["INPLAY_1ST_HALF", "INPLAY_2ND_HALF", "INPLAY_ET", "INPLAY_ET_2ND_HALF", "INPLAY_PENALTIES", "LIVE", "EXTRA_TIME", "PEN_LIVE"]);
const SM_HT_STATES = new Set(["HT", "BREAK", "PEN_BREAK", "EXTRA_TIME_BREAK"]);
const SM_FINISHED_STATES = new Set(["FT", "AET", "FT_PEN", "FINISHED"]);
const SM_POSTPONED = new Set(["POSTPONED", "DELAYED", "SUSPENDED", "INTERRUPTED", "ABANDONED"]);
const SM_CANCELLED = new Set(["CANCELLED", "WALKOVER", "AWARDED", "DELETED"]);

function smStatus(f: SmFixture): SportsAlertStatus {
  const s = (f.state?.developer_name ?? f.state?.state ?? "").toUpperCase();
  if (SM_LIVE_STATES.has(s)) return "live";
  if (SM_HT_STATES.has(s)) return "halftime";
  if (SM_FINISHED_STATES.has(s)) return "finished";
  if (SM_POSTPONED.has(s)) return "postponed";
  if (SM_CANCELLED.has(s)) return "cancelled";
  return "scheduled";
}

function smKickoff(f: SmFixture) {
  if (f.starting_at_timestamp) return new Date(f.starting_at_timestamp * 1000).toISOString();
  return new Date(`${f.starting_at.replace(" ", "T")}Z`).toISOString();
}

function smScore(f: SmFixture, side: "home" | "away") {
  const current = f.scores?.find((s) => s.description === "CURRENT" && s.score?.participant === side) ?? f.scores?.find((s) => s.score?.participant === side);
  return num(current?.score?.goals);
}

async function sportmonksFeed(date: string): Promise<SportsAlertFeed> {
  const res = await callIntegration("sportmonks", `/fixtures/between/${date}/${nextDay(date)}`, { include: "league.country;participants;state;scores;periods", per_page: "200" });
  if (!res.ok) return { date, source: "none", matches: [], error: res.message };
  const list = ((res.data as { data?: SmFixture[] }).data ?? []).filter((f) => localDay(smKickoff(f)) === date);
  const matches: SportsAlertMatch[] = list.map((f) => {
    const home = f.participants?.find((p) => p.meta?.location === "home");
    const away = f.participants?.find((p) => p.meta?.location === "away");
    const status = smStatus(f);
    const minute = f.periods?.find((p) => p.ticking)?.minutes ?? null;
    return {
      id: f.id,
      kickoff_utc: smKickoff(f),
      status,
      isLive: status === "live" || status === "halftime",
      isFinished: status === "finished",
      homeTeamLogo: home?.image_path ?? "",
      awayTeamLogo: away?.image_path ?? "",
      leagueId: f.league_id,
      country: f.league?.country?.name ?? "",
      basicStats: null,
      homeTeam: home?.name ?? "Mandante",
      awayTeam: away?.name ?? "Visitante",
      leagueName: f.league?.name ?? "",
      homeScore: smScore(f, "home"),
      awayScore: smScore(f, "away"),
      minute,
      source: "sportmonks",
    };
  });
  return { date, source: "sportmonks", matches };
}

async function sportmonksLiveStats(matchId: number): Promise<BasicStats | null> {
  const res = await callIntegration("sportmonks", `/fixtures/${matchId}`, { include: "statistics.type;xGFixture;participants" });
  if (!res.ok) return null;
  const d = (res.data as { data?: { participants?: { id: number; meta?: { location?: string } }[]; statistics?: { participant_id: number; location?: string; type?: { code?: string; developer_name?: string; name?: string }; type_id?: number; data?: { value?: number } }[]; xgfixture?: { participant_id?: number; location?: string; data?: { value?: number } }[] } }).data;
  if (!d) return null;
  const homeId = d.participants?.find((p) => p.meta?.location === "home")?.id;
  const side = (row: { participant_id: number; location?: string }) => row.location ?? (row.participant_id === homeId ? "home" : "away");
  const stat = (match: RegExp, typeId: number) => {
    const out = { home: null as number | null, away: null as number | null };
    for (const row of d.statistics ?? []) {
      const code = (row.type?.developer_name ?? row.type?.code ?? row.type?.name ?? "").toLowerCase();
      if (match.test(code) || row.type_id === typeId) out[side(row) as "home" | "away"] = num(row.data?.value);
    }
    return out;
  };
  const xg = { home: null as number | null, away: null as number | null };
  for (const row of d.xgfixture ?? []) xg[(row.location ?? (row.participant_id === homeId ? "home" : "away")) as "home" | "away"] = num(row.data?.value);
  return {
    xg,
    possession: stat(/ball[-_ ]?possession/, 45),
    shots: stat(/shots[-_ ]?total|^shots$/, 42),
    shotsOnTarget: stat(/shots[-_ ]?on[-_ ]?target/, 86),
    corners: stat(/corner/, 34),
    updatedAt: new Date().toISOString(),
    source: "sportmonks",
  };
}

/* -------------------------------- Bzzoiro --------------------------------- */

type BzEvent = { id: number; league_id: number; league_name?: string; home_team: string; away_team: string; home_team_id: number; away_team_id: number; event_date: string; status: string; period?: string; current_minute?: number | null; home_score?: number | null; away_score?: number | null };

function bzStatus(e: BzEvent): SportsAlertStatus {
  const s = e.status.toLowerCase();
  if (s === "finished" || e.period === "FT") return "finished";
  if (s === "inprogress" || s === "live" || s === "inplay") return e.period === "HT" ? "halftime" : "live";
  if (s.includes("postpon") || s.includes("suspend") || s.includes("delay")) return "postponed";
  if (s.includes("cancel") || s.includes("abandon")) return "cancelled";
  return "scheduled";
}

const bzLeagueCountry = new Map<number, string>();
async function bzCountry(leagueId: number) {
  const hit = bzLeagueCountry.get(leagueId);
  if (hit !== undefined) return hit;
  const res = await callIntegration("bzzoiro", `/leagues/${leagueId}/`);
  const country = res.ok ? String((res.data as { country?: string }).country ?? "") : "";
  bzLeagueCountry.set(leagueId, country);
  return country;
}

const localDay = (iso: string) => {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date(iso));
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
};
const nextDay = (date: string) => new Date(new Date(`${date}T12:00:00Z`).getTime() + 86400000).toISOString().slice(0, 10);

async function bzzoiroFeed(date: string): Promise<SportsAlertFeed> {
  const events: BzEvent[] = [];
  let page = 1;
  while (page <= 5) {
    const res = await callIntegration("bzzoiro", "/events/", { date_from: date, date_to: nextDay(date), page_size: "200", page: String(page) });
    if (!res.ok) return { date, source: "none", matches: [], error: res.message };
    const raw = res.data as { results?: BzEvent[]; next?: string | null };
    events.push(...(raw.results ?? []));
    if (!raw.next) break;
    page += 1;
  }
  const dayEvents = events.filter((e) => localDay(e.event_date) === date);
  const leagueIds = [...new Set(dayEvents.map((e) => e.league_id))];
  await Promise.all(leagueIds.slice(0, 40).map((id) => bzCountry(id)));
  const matches: SportsAlertMatch[] = dayEvents.map((e) => {
    const status = bzStatus(e);
    return {
      id: e.id,
      kickoff_utc: new Date(e.event_date).toISOString(),
      status,
      isLive: status === "live" || status === "halftime",
      isFinished: status === "finished",
      homeTeamLogo: "", // Bzzoiro não expõe logos no plano público → placeholder no card
      awayTeamLogo: "",
      leagueId: e.league_id,
      country: bzLeagueCountry.get(e.league_id) ?? "",
      basicStats: null,
      homeTeam: e.home_team,
      awayTeam: e.away_team,
      leagueName: e.league_name ?? "",
      homeScore: num(e.home_score),
      awayScore: num(e.away_score),
      minute: num(e.current_minute),
      source: "bzzoiro",
    };
  });
  return { date, source: "bzzoiro", matches };
}

async function bzzoiroLiveStats(matchId: number): Promise<BasicStats | null> {
  const res = await callIntegration("bzzoiro", `/events/${matchId}/stats/`);
  if (!res.ok) return null;
  const p = res.data as { stats?: { home?: Record<string, unknown>; away?: Record<string, unknown> } };
  const h = p.stats?.home, a = p.stats?.away;
  if (!h || !a) return null;
  const xgOf = (s: Record<string, unknown>) => { const xg = s.xg as { actual?: unknown; estimated?: unknown } | undefined; return num(xg?.actual) ?? num(xg?.estimated); };
  const pair = (k: string) => ({ home: num(h[k]), away: num(a[k]) });
  const stats: BasicStats = { xg: { home: xgOf(h), away: xgOf(a) }, possession: pair("ball_possession"), shots: pair("total_shots"), shotsOnTarget: pair("shots_on_target"), corners: pair("corner_kicks"), updatedAt: new Date().toISOString(), source: "bzzoiro" };
  const any = Object.values(stats).some((v) => typeof v === "object" && v && "home" in v && ((v as { home: number | null }).home !== null || (v as { away: number | null }).away !== null));
  return any ? stats : null;
}

/* -------------------------------- Serviço --------------------------------- */

/** Lista de jogos do dia no formato Sports Alert. Sportmonks → Bzzoiro (fallback). Cache 60s. */
export async function getDailyMatches(date = todayUtcDate()): Promise<SportsAlertFeed> {
  const hit = feedCache.get(date);
  if (hit && Date.now() - hit.at < FEED_TTL) return hit.feed;
  let feed: SportsAlertFeed;
  let fallbackReason: string | undefined;
  const sm = await getIntegration("sportmonks");
  if (sm) {
    feed = await sportmonksFeed(date);
    if (feed.source === "none") {
      fallbackReason = `Sportmonks: ${feed.error}`;
      feed = await bzzoiroFeed(date);
    }
  } else {
    fallbackReason = "Sportmonks não configurada no painel (Admin → APIs de dados) — usando Bzzoiro.";
    feed = await bzzoiroFeed(date);
  }
  feed.fallbackReason = fallbackReason;
  feed.matches.sort((x, y) => Number(y.isLive) - Number(x.isLive) || x.kickoff_utc.localeCompare(y.kickoff_utc));
  feedCache.set(date, { at: Date.now(), feed });
  return feed;
}

/** Estatísticas ao vivo (xG, posse, chutes, escanteios). Só preenche quando isLive. Cache 30s. */
export async function getLiveMatchStats(matchId: number, source: "sportmonks" | "bzzoiro" = "sportmonks"): Promise<BasicStats | null> {
  const key = `${source}:${matchId}`;
  const hit = statsCache.get(key);
  if (hit && Date.now() - hit.at < STATS_TTL) return hit.stats;
  const stats = source === "sportmonks" ? await sportmonksLiveStats(matchId) : await bzzoiroLiveStats(matchId);
  statsCache.set(key, { at: Date.now(), stats });
  return stats;
}

/** Feed completo: jogos do dia + basicStats preenchido para os que estão ao vivo. */
export async function getDailyMatchesWithLiveStats(date = todayUtcDate(), maxLive = 20) {
  const feed = await getDailyMatches(date);
  const live = feed.matches.filter((m) => m.isLive).slice(0, maxLive);
  await Promise.all(live.map(async (m) => { m.basicStats = await getLiveMatchStats(m.id, m.source); }));
  return feed;
}

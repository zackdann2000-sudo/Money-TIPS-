import { and, asc, desc, eq, inArray, isNull, lt, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { playerSeasonStats, players, syncState, teams } from "@/db/schema";
import { ESPN_LEAGUES, slugify } from "@/lib/espn";
import { espnFetch } from "@/lib/espn-fetch";

/* ------------------------------------------------------------------ */
/*  Fonte de dados: ESPN (elencos + estatísticas por atleta/temporada) */
/*  Arquitetura independente do fornecedor: toda leitura passa por     */
/*  `RawPlayerStats` — para trocar de API basta mapear para esse tipo. */
/* ------------------------------------------------------------------ */

const SITE = "https://site.api.espn.com/apis/site/v2/sports/soccer";
const CORE = "https://sports.core.api.espn.com/v2/sports/soccer/leagues";
const ROSTER_TTL_MS = 6 * 60 * 60 * 1000; // elencos: 6h
const DETAIL_TTL_MS = 6 * 60 * 60 * 1000; // estatísticas detalhadas: 6h
const ENRICH_PER_SYNC = 220; // atletas enriquecidos por rodada de sincronização

export const PLAYER_LEAGUES = ESPN_LEAGUES.map((l) => ({ code: l.code, name: l.name, country: l.country, flag: l.flag }));

export const POSITIONS: Record<string, { label: string; plural: string }> = {
  G: { label: "Goleiro", plural: "Goleiros" },
  D: { label: "Defensor", plural: "Defensores (zagueiros e laterais)" },
  M: { label: "Meio-campista", plural: "Meio-campistas (volantes e meias)" },
  F: { label: "Atacante", plural: "Atacantes (pontas e centroavantes)" },
};

type RawPlayerStats = {
  externalId: string;
  name: string;
  shortName: string;
  position: string;
  positionName: string;
  nationality: string;
  flag: string;
  age: number | null;
  dateOfBirth: string;
  jersey: string;
  headshot: string;
  teamExternalId: string;
  teamName: string;
  teamLogo: string;
  season: number;
  stats: Record<string, number>;
};

async function fetchJson<T>(url: string, timeoutMs = 10000): Promise<T | null> {
  // elencos/estatísticas mudam pouco: cache de 5 min (mínimo 30 s garantido pelo cliente)
  return espnFetch<T>(url, { timeoutMs, ttlMs: 5 * 60_000 });
}

function flatStats(statistics: { splits?: { categories?: { stats?: { name: string; value?: number }[] }[] } } | undefined) {
  const out: Record<string, number> = {};
  for (const category of statistics?.splits?.categories ?? []) {
    for (const stat of category.stats ?? []) {
      if (typeof stat.value === "number") out[stat.name] = stat.value;
    }
  }
  return out;
}

type RosterResponse = {
  season?: { year?: number };
  team?: { id?: string; displayName?: string; logos?: { href?: string }[]; logo?: string };
  athletes?: {
    id: string;
    displayName?: string;
    fullName?: string;
    shortName?: string;
    age?: number;
    dateOfBirth?: string;
    jersey?: string;
    citizenship?: string;
    flag?: { href?: string };
    headshot?: { href?: string } | string;
    position?: { abbreviation?: string; name?: string };
    statistics?: { splits?: { categories?: { stats?: { name: string; value?: number }[] }[] } };
  }[];
};

async function fetchLeagueTeams(code: string): Promise<{ id: string; name: string; logo: string }[]> {
  const data = await fetchJson<{ sports?: { leagues?: { teams?: { team: { id: string; displayName: string; logos?: { href?: string }[] } }[] }[] }[] }>(`${SITE}/${code}/teams?limit=60`);
  const list = data?.sports?.[0]?.leagues?.[0]?.teams ?? [];
  return list.map((t) => ({ id: t.team.id, name: t.team.displayName, logo: t.team.logos?.[0]?.href ?? "" }));
}

async function fetchRoster(code: string, teamId: string): Promise<RawPlayerStats[]> {
  const data = await fetchJson<RosterResponse>(`${SITE}/${code}/teams/${teamId}/roster`);
  if (!data?.athletes) return [];
  const season = Number(data.season?.year ?? new Date().getFullYear());
  const teamName = data.team?.displayName ?? "";
  const teamLogo = data.team?.logos?.[0]?.href ?? data.team?.logo ?? "";
  return data.athletes.map((a) => ({
    externalId: a.id,
    name: a.fullName ?? a.displayName ?? "Jogador",
    shortName: a.shortName ?? a.displayName ?? "",
    position: (a.position?.abbreviation ?? "M").slice(0, 1).toUpperCase(),
    positionName: a.position?.name ?? "",
    nationality: a.citizenship ?? "",
    flag: a.flag?.href ?? "",
    age: typeof a.age === "number" ? a.age : null,
    dateOfBirth: a.dateOfBirth ?? "",
    jersey: a.jersey ?? "",
    headshot: typeof a.headshot === "string" ? a.headshot : (a.headshot?.href ?? ""),
    teamExternalId: teamId,
    teamName,
    teamLogo,
    season,
    stats: flatStats(a.statistics),
  }));
}

const n = (v: number | undefined) => Math.round(v ?? 0);

async function upsertRosterPlayers(code: string, rows: RawPlayerStats[]) {
  if (!rows.length) return 0;
  const teamRows = await db.select({ id: teams.id, externalId: teams.externalId }).from(teams).where(inArray(teams.externalId, [...new Set(rows.map((r) => r.teamExternalId))]));
  const teamByExt = new Map(teamRows.map((t) => [t.externalId ?? "", t.id]));
  let count = 0;
  for (const row of rows) {
    const [player] = await db
      .insert(players)
      .values({
        source: "espn",
        externalId: row.externalId,
        name: row.name,
        shortName: row.shortName,
        slug: slugify(row.name) || `jogador-${row.externalId}`,
        position: ["G", "D", "M", "F"].includes(row.position) ? row.position : "M",
        positionName: row.positionName,
        nationality: row.nationality,
        flag: row.flag,
        age: row.age,
        dateOfBirth: row.dateOfBirth,
        jersey: row.jersey,
        headshot: row.headshot,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [players.source, players.externalId],
        set: {
          name: row.name,
          shortName: row.shortName,
          position: ["G", "D", "M", "F"].includes(row.position) ? row.position : "M",
          positionName: row.positionName,
          nationality: row.nationality,
          flag: row.flag,
          age: row.age,
          jersey: row.jersey,
          headshot: row.headshot,
          updatedAt: new Date(),
        },
      })
      .returning({ id: players.id });
    const s = row.stats;
    const base = {
      teamExternalId: row.teamExternalId,
      teamId: teamByExt.get(row.teamExternalId) ?? null,
      teamName: row.teamName,
      teamLogo: row.teamLogo,
      appearances: n(s.appearances),
      subIns: n(s.subIns),
      goals: n(s.totalGoals),
      assists: n(s.goalAssists),
      shots: n(s.totalShots),
      shotsOnTarget: n(s.shotsOnTarget),
      foulsCommitted: n(s.foulsCommitted),
      foulsSuffered: n(s.foulsSuffered),
      yellowCards: n(s.yellowCards),
      redCards: n(s.redCards),
      offsides: n(s.offsides),
      ownGoals: n(s.ownGoals),
      saves: n(s.saves),
      shotsFaced: n(s.shotsFaced),
      goalsConceded: n(s.goalsConceded),
      updatedAt: new Date(),
    };
    await db
      .insert(playerSeasonStats)
      .values({ playerId: player.id, leagueCode: code, season: row.season, ...base })
      .onConflictDoUpdate({ target: [playerSeasonStats.playerId, playerSeasonStats.leagueCode, playerSeasonStats.season], set: base });
    count += 1;
  }
  return count;
}

/** Busca as estatísticas completas do atleta na temporada (minutos, passes, desarmes, duelos...). */
export async function enrichPlayerStats(statRowId: number, externalId: string, code: string, season: number) {
  const data = await fetchJson<{ splits?: { categories?: { stats?: { name: string; value?: number }[] }[] } }>(`${CORE}/${code}/seasons/${season}/types/1/athletes/${externalId}/statistics`, 8000);
  if (!data?.splits) {
    await db.update(playerSeasonStats).set({ detailedAt: new Date() }).where(eq(playerSeasonStats.id, statRowId));
    return false;
  }
  const s = flatStats(data);
  await db
    .update(playerSeasonStats)
    .set({
      detailed: true,
      detailedAt: new Date(),
      minutes: n(s.minutes),
      starts: n(s.starts),
      appearances: n(s.appearances) || undefined,
      goals: n(s.totalGoals),
      assists: n(s.goalAssists),
      shots: n(s.totalShots),
      shotsOnTarget: n(s.shotsOnTarget),
      foulsCommitted: n(s.foulsCommitted),
      foulsSuffered: n(s.foulsSuffered),
      yellowCards: n(s.yellowCards),
      redCards: n(s.redCards),
      offsides: n(s.offsides),
      penaltyGoals: n(s.penaltyKickGoals),
      penaltyShots: n(s.penaltyKickShots),
      headedGoals: n(s.headedGoals),
      totalPasses: n(s.totalPasses),
      accuratePasses: n(s.accuratePasses),
      totalCrosses: n(s.totalCrosses),
      accurateCrosses: n(s.accurateCrosses),
      shotAssists: n(s.shotAssists),
      bigChancesCreated: n(s.bigChanceCreated),
      tackles: n(s.totalTackles),
      tacklesWon: n(s.effectiveTackles),
      interceptions: n(s.interceptions),
      clearances: n(s.effectiveClearance),
      blockedShots: n(s.blockedShots),
      recoveries: n(s.recoveries),
      duels: n(s.duels),
      duelsWon: n(s.duelsWon),
      touches: n(s.touches),
      cleanSheets: n(s.cleanSheet),
      saves: n(s.saves),
      shotsFaced: n(s.shotsFaced),
      goalsConceded: n(s.goalsConceded),
      updatedAt: new Date(),
    })
    .where(eq(playerSeasonStats.id, statRowId));
  return true;
}

async function runPool<T>(items: T[], limit: number, worker: (item: T) => Promise<unknown>) {
  let index = 0;
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (index < items.length) {
        const item = items[index++];
        try {
          await worker(item);
        } catch (error) {
          console.error("players pool error", error);
        }
      }
    }),
  );
}

/** Enriquecimento progressivo: atletas com minutos ausentes/obsoletos, priorizando quem mais joga. */
export async function enrichStalePlayers(code: string, season: number, limit = ENRICH_PER_SYNC) {
  const cutoff = new Date(Date.now() - DETAIL_TTL_MS);
  const rows = await db
    .select({ id: playerSeasonStats.id, externalId: players.externalId })
    .from(playerSeasonStats)
    .innerJoin(players, eq(players.id, playerSeasonStats.playerId))
    .where(and(eq(playerSeasonStats.leagueCode, code), eq(playerSeasonStats.season, season), sql`${playerSeasonStats.appearances} > 0`, or(isNull(playerSeasonStats.detailedAt), lt(playerSeasonStats.detailedAt, cutoff))))
    .orderBy(asc(playerSeasonStats.detailed), desc(playerSeasonStats.appearances))
    .limit(limit);
  await runPool(rows, 8, (row) => enrichPlayerStats(row.id, row.externalId, code, season));
  return rows.length;
}

const inflight = new Map<string, Promise<{ ok: boolean; message: string; players: number }>>();

export async function getPlayersSyncState(code: string) {
  const [row] = await db.select().from(syncState).where(eq(syncState.key, `players:${code}`)).limit(1);
  return row ?? null;
}

/** Sincroniza uma liga: elencos (base) + enriquecimento progressivo. Respeita TTL de 6h. */
export async function syncLeaguePlayers(code: string, force = false) {
  const key = `players:${code}`;
  const existing = inflight.get(key);
  if (existing) return existing;
  const task = (async () => {
    const state = await getPlayersSyncState(code);
    const fresh = state?.lastSuccessAt && Date.now() - new Date(state.lastSuccessAt).getTime() < ROSTER_TTL_MS;
    if (fresh && !force) {
      const season = await currentSeasonFor(code);
      if (season) await enrichStalePlayers(code, season, 40);
      return { ok: true, message: state?.lastMessage ?? "cache", players: state?.matchesSynced ?? 0 };
    }
    await db.insert(syncState).values({ key, lastRunAt: new Date() }).onConflictDoUpdate({ target: syncState.key, set: { lastRunAt: new Date() } });
    const leagueTeams = await fetchLeagueTeams(code);
    if (!leagueTeams.length) {
      const message = "Fonte indisponível para esta competição no momento";
      await db.update(syncState).set({ lastMessage: message }).where(eq(syncState.key, key));
      return { ok: false, message, players: 0 };
    }
    let total = 0;
    let season = 0;
    await runPool(leagueTeams, 5, async (team) => {
      const roster = await fetchRoster(code, team.id);
      if (roster.length) season = roster[0].season;
      const count = await upsertRosterPlayers(code, roster);
      total += count;
    });
    if (season) await enrichStalePlayers(code, season);
    const message = `${total} jogadores · ${leagueTeams.length} clubes · temporada ${season || "?"}`;
    await db.update(syncState).set({ lastSuccessAt: new Date(), lastMessage: message, matchesSynced: total }).where(eq(syncState.key, key));
    return { ok: true, message, players: total };
  })().finally(() => inflight.delete(key));
  inflight.set(key, task);
  return task;
}

export async function currentSeasonFor(code: string) {
  const [row] = await db
    .select({ season: playerSeasonStats.season })
    .from(playerSeasonStats)
    .where(eq(playerSeasonStats.leagueCode, code))
    .orderBy(desc(playerSeasonStats.season))
    .limit(1);
  return row?.season ?? null;
}

export async function availableSeasons(code?: string) {
  const rows = await db
    .selectDistinct({ season: playerSeasonStats.season })
    .from(playerSeasonStats)
    .where(code ? eq(playerSeasonStats.leagueCode, code) : undefined)
    .orderBy(desc(playerSeasonStats.season));
  return rows.map((r) => r.season);
}

/* ------------------------------------------------------------------ */
/*  Métricas — todas derivadas de campos reais; "detailed" exige minutos */
/* ------------------------------------------------------------------ */

export type StatRow = typeof playerSeasonStats.$inferSelect & { player: typeof players.$inferSelect };

export type MetricDef = {
  key: string;
  label: string;
  short: string;
  category: string;
  needsDetailed?: boolean;
  minSample?: { field: "shots" | "totalPasses" | "savesPlusConceded" | "appearances" | "cards" | "duels" | "totalCrosses" | "tackles"; value: number; label: string };
  format?: "int" | "dec" | "pct";
  lowerIsBetter?: boolean;
  gkOnly?: boolean;
  compute: (r: StatRow) => number | null;
  note?: string;
};

const per90 = (value: number, minutes: number | null) => (minutes && minutes > 0 ? (value / minutes) * 90 : null);
const perGame = (value: number, apps: number) => (apps > 0 ? value / apps : null);
const ratio = (a: number, b: number) => (b > 0 ? a / b : null);
const cards = (r: StatRow) => r.yellowCards + r.redCards;

export const METRIC_CATEGORIES: { key: string; label: string; icon: string; description: string }[] = [
  { key: "gols", label: "Gols", icon: "⚽", description: "Desempenho ofensivo: gols, médias por jogo e por 90 minutos, pênaltis, gols de cabeça e participações." },
  { key: "finalizacoes", label: "Finalizações", icon: "🎯", description: "Volume e qualidade das finalizações. Precisão e conversão exigem amostra mínima de 10 finalizações." },
  { key: "assistencias", label: "Assistências & criação", icon: "🅰️", description: "Assistências, passes para finalização (passes decisivos) e grandes chances criadas." },
  { key: "faltas", label: "Faltas", icon: "✋", description: "Faltas cometidas e sofridas, com médias por jogo e por 90 minutos." },
  { key: "cartoes", label: "Cartões & disciplina", icon: "🟨", description: "Regra do total: amarelos + vermelhos (cada cartão conta 1; o segundo amarelo já aparece como vermelho na fonte)." },
  { key: "impedimentos", label: "Impedimentos", icon: "🚫", description: "Impedimentos individuais. Escanteios por jogador não são fornecidos pela fonte e não são exibidos." },
  { key: "passes", label: "Passes & posse", icon: "🔁", description: "Passes, precisão (mín. 100 passes), cruzamentos, recuperações e duelos ganhos." },
  { key: "defesa", label: "Defesa & goleiros", icon: "🛡️", description: "Desarmes, interceptações, cortes, bloqueios, defesas, % de defesas (mín. 10 chutes enfrentados) e jogos sem sofrer gol." },
  { key: "eficiencia", label: "Eficiência & regularidade", icon: "📈", description: "Médias por 90 minutos e regularidade (% de jogos como titular, mín. 10 jogos). Use o filtro de minutos mínimos para evitar amostras pequenas." },
];

export const METRICS: MetricDef[] = [
  // A. Gols
  { key: "goals", label: "Gols", short: "Gols", category: "gols", compute: (r) => r.goals },
  { key: "goalsPerGame", label: "Gols por partida", short: "G/J", category: "gols", format: "dec", compute: (r) => perGame(r.goals, r.appearances) },
  { key: "goalsPer90", label: "Gols por 90 min", short: "G/90", category: "gols", format: "dec", needsDetailed: true, compute: (r) => per90(r.goals, r.minutes) },
  { key: "penaltyGoals", label: "Pênaltis convertidos", short: "Pên.", category: "gols", needsDetailed: true, compute: (r) => r.penaltyGoals ?? null },
  { key: "headedGoals", label: "Gols de cabeça", short: "Cab.", category: "gols", needsDetailed: true, compute: (r) => r.headedGoals ?? null },
  { key: "involvements", label: "Participações em gols (G+A)", short: "G+A", category: "gols", compute: (r) => r.goals + r.assists },
  // B. Finalizações
  { key: "shots", label: "Finalizações", short: "Fin.", category: "finalizacoes", compute: (r) => r.shots },
  { key: "shotsOnTarget", label: "Finalizações no alvo", short: "No alvo", category: "finalizacoes", compute: (r) => r.shotsOnTarget },
  { key: "shotAccuracy", label: "Precisão das finalizações", short: "Prec.", category: "finalizacoes", format: "pct", minSample: { field: "shots", value: 10, label: "mín. 10 finalizações" }, compute: (r) => ratio(r.shotsOnTarget, r.shots) },
  { key: "shotsPerGame", label: "Finalizações por partida", short: "Fin./J", category: "finalizacoes", format: "dec", compute: (r) => perGame(r.shots, r.appearances) },
  { key: "shotsPer90", label: "Finalizações por 90 min", short: "Fin./90", category: "finalizacoes", format: "dec", needsDetailed: true, compute: (r) => per90(r.shots, r.minutes) },
  { key: "conversion", label: "Conversão (gols / finalizações)", short: "Conv.", category: "finalizacoes", format: "pct", minSample: { field: "shots", value: 10, label: "mín. 10 finalizações" }, compute: (r) => ratio(r.goals, r.shots) },
  // C. Assistências
  { key: "assists", label: "Assistências", short: "Ast.", category: "assistencias", compute: (r) => r.assists },
  { key: "assistsPerGame", label: "Assistências por partida", short: "A/J", category: "assistencias", format: "dec", compute: (r) => perGame(r.assists, r.appearances) },
  { key: "assistsPer90", label: "Assistências por 90 min", short: "A/90", category: "assistencias", format: "dec", needsDetailed: true, compute: (r) => per90(r.assists, r.minutes) },
  { key: "bigChancesCreated", label: "Grandes chances criadas", short: "GCC", category: "assistencias", needsDetailed: true, compute: (r) => r.bigChancesCreated ?? null },
  { key: "shotAssists", label: "Passes decisivos (para finalização)", short: "P.dec.", category: "assistencias", needsDetailed: true, compute: (r) => r.shotAssists ?? null },
  { key: "chancesPerGame", label: "Chances criadas por partida", short: "CC/J", category: "assistencias", format: "dec", needsDetailed: true, compute: (r) => perGame((r.shotAssists ?? 0) + (r.bigChancesCreated ?? 0), r.appearances), note: "passes decisivos + grandes chances" },
  { key: "involvementsPer90", label: "Participações em gols por 90", short: "G+A/90", category: "assistencias", format: "dec", needsDetailed: true, compute: (r) => per90(r.goals + r.assists, r.minutes) },
  // D. Faltas
  { key: "foulsCommitted", label: "Faltas cometidas", short: "FC", category: "faltas", compute: (r) => r.foulsCommitted },
  { key: "foulsCommittedPerGame", label: "Faltas cometidas por partida", short: "FC/J", category: "faltas", format: "dec", compute: (r) => perGame(r.foulsCommitted, r.appearances) },
  { key: "foulsCommittedPer90", label: "Faltas cometidas por 90", short: "FC/90", category: "faltas", format: "dec", needsDetailed: true, compute: (r) => per90(r.foulsCommitted, r.minutes) },
  { key: "foulsSuffered", label: "Faltas sofridas", short: "FS", category: "faltas", compute: (r) => r.foulsSuffered },
  { key: "foulsSufferedPerGame", label: "Faltas sofridas por partida", short: "FS/J", category: "faltas", format: "dec", compute: (r) => perGame(r.foulsSuffered, r.appearances) },
  { key: "foulsDiff", label: "Saldo (sofridas − cometidas)", short: "Saldo", category: "faltas", compute: (r) => r.foulsSuffered - r.foulsCommitted },
  // E. Cartões
  { key: "yellowCards", label: "Cartões amarelos", short: "CA", category: "cartoes", compute: (r) => r.yellowCards },
  { key: "redCards", label: "Cartões vermelhos", short: "CV", category: "cartoes", compute: (r) => r.redCards },
  { key: "totalCards", label: "Total de cartões (CA + CV)", short: "Cart.", category: "cartoes", compute: (r) => cards(r) },
  { key: "cardsPerGame", label: "Cartões por partida", short: "Cart./J", category: "cartoes", format: "dec", compute: (r) => perGame(cards(r), r.appearances) },
  { key: "cardsPer90", label: "Cartões por 90 min", short: "Cart./90", category: "cartoes", format: "dec", needsDetailed: true, compute: (r) => per90(cards(r), r.minutes) },
  { key: "minutesPerCard", label: "Minutos por cartão (menor = mais advertido)", short: "Min/cart.", category: "cartoes", format: "int", lowerIsBetter: true, needsDetailed: true, minSample: { field: "cards", value: 1, label: "mín. 1 cartão" }, compute: (r) => (cards(r) > 0 && r.minutes ? r.minutes / cards(r) : null) },
  // F. Impedimentos
  { key: "offsides", label: "Impedimentos", short: "Imp.", category: "impedimentos", compute: (r) => r.offsides },
  { key: "offsidesPerGame", label: "Impedimentos por partida", short: "Imp./J", category: "impedimentos", format: "dec", compute: (r) => perGame(r.offsides, r.appearances) },
  { key: "offsidesPer90", label: "Impedimentos por 90 min", short: "Imp./90", category: "impedimentos", format: "dec", needsDetailed: true, compute: (r) => per90(r.offsides, r.minutes) },
  // G. Passes
  { key: "totalPasses", label: "Passes realizados", short: "Passes", category: "passes", needsDetailed: true, compute: (r) => r.totalPasses ?? null },
  { key: "passAccuracy", label: "Precisão de passes", short: "Prec. passe", category: "passes", format: "pct", needsDetailed: true, minSample: { field: "totalPasses", value: 100, label: "mín. 100 passes" }, compute: (r) => ratio(r.accuratePasses ?? 0, r.totalPasses ?? 0) },
  { key: "accurateCrosses", label: "Cruzamentos certos", short: "Cruz. certos", category: "passes", needsDetailed: true, compute: (r) => r.accurateCrosses ?? null },
  { key: "totalCrosses", label: "Cruzamentos realizados", short: "Cruz.", category: "passes", needsDetailed: true, compute: (r) => r.totalCrosses ?? null },
  { key: "recoveries", label: "Bolas recuperadas", short: "Recup.", category: "passes", needsDetailed: true, compute: (r) => r.recoveries ?? null },
  { key: "duelsWon", label: "Duelos ganhos", short: "Duelos", category: "passes", needsDetailed: true, compute: (r) => r.duelsWon ?? null },
  { key: "duelWinRate", label: "% de duelos ganhos", short: "% duelos", category: "passes", format: "pct", needsDetailed: true, minSample: { field: "duels", value: 30, label: "mín. 30 duelos" }, compute: (r) => ratio(r.duelsWon ?? 0, r.duels ?? 0) },
  { key: "touches", label: "Toques na bola", short: "Toques", category: "passes", needsDetailed: true, compute: (r) => r.touches ?? null },
  // H. Defesa
  { key: "tackles", label: "Desarmes (tentativas)", short: "Desarmes", category: "defesa", needsDetailed: true, compute: (r) => r.tackles ?? null },
  { key: "tacklesWon", label: "Desarmes certos", short: "Des. certos", category: "defesa", needsDetailed: true, compute: (r) => r.tacklesWon ?? null },
  { key: "interceptions", label: "Interceptações", short: "Interc.", category: "defesa", needsDetailed: true, compute: (r) => r.interceptions ?? null },
  { key: "clearances", label: "Cortes / afastamentos", short: "Cortes", category: "defesa", needsDetailed: true, compute: (r) => r.clearances ?? null },
  { key: "blockedShots", label: "Finalizações bloqueadas", short: "Bloq.", category: "defesa", needsDetailed: true, compute: (r) => r.blockedShots ?? null },
  { key: "saves", label: "Defesas (goleiros)", short: "Defesas", category: "defesa", gkOnly: true, compute: (r) => r.saves },
  { key: "savePct", label: "% de defesas (goleiros)", short: "% def.", category: "defesa", format: "pct", gkOnly: true, minSample: { field: "savesPlusConceded", value: 20, label: "mín. 20 chutes no alvo enfrentados" }, compute: (r) => ratio(r.saves, r.saves + r.goalsConceded), note: "metodologia: defesas ÷ (defesas + gols sofridos)" },
  { key: "cleanSheets", label: "Jogos sem sofrer gol (goleiros)", short: "Clean", category: "defesa", gkOnly: true, needsDetailed: true, compute: (r) => r.cleanSheets ?? null },
  { key: "goalsConcededPerGame", label: "Gols sofridos por partida (goleiros)", short: "GS/J", category: "defesa", format: "dec", lowerIsBetter: true, gkOnly: true, minSample: { field: "appearances", value: 5, label: "mín. 5 jogos" }, compute: (r) => perGame(r.goalsConceded, r.appearances) },
  // I. Eficiência
  { key: "effGoalsPer90", label: "Gols por 90 min", short: "G/90", category: "eficiencia", format: "dec", needsDetailed: true, compute: (r) => per90(r.goals, r.minutes) },
  { key: "effAssistsPer90", label: "Assistências por 90 min", short: "A/90", category: "eficiencia", format: "dec", needsDetailed: true, compute: (r) => per90(r.assists, r.minutes) },
  { key: "effInvolvementsPer90", label: "Participações por 90 min", short: "G+A/90", category: "eficiencia", format: "dec", needsDetailed: true, compute: (r) => per90(r.goals + r.assists, r.minutes) },
  { key: "effPassAccuracy", label: "Precisão de passes", short: "Prec. passe", category: "eficiencia", format: "pct", needsDetailed: true, minSample: { field: "totalPasses", value: 100, label: "mín. 100 passes" }, compute: (r) => ratio(r.accuratePasses ?? 0, r.totalPasses ?? 0) },
  { key: "effShotAccuracy", label: "Precisão de finalizações", short: "Prec. fin.", category: "eficiencia", format: "pct", minSample: { field: "shots", value: 10, label: "mín. 10 finalizações" }, compute: (r) => ratio(r.shotsOnTarget, r.shots) },
  { key: "regularity", label: "Regularidade (% de jogos como titular)", short: "Titular %", category: "eficiencia", format: "pct", needsDetailed: true, minSample: { field: "appearances", value: 10, label: "mín. 10 jogos" }, compute: (r) => ratio(r.starts ?? 0, r.appearances), note: "metodologia: titularidades ÷ jogos disputados" },
  { key: "minutes", label: "Minutos jogados", short: "Min.", category: "eficiencia", needsDetailed: true, compute: (r) => r.minutes ?? null },
];

export const metricByKey = (key: string) => METRICS.find((m) => m.key === key);

function sampleValue(r: StatRow, field: NonNullable<MetricDef["minSample"]>["field"]) {
  if (field === "cards") return cards(r);
  if (field === "savesPlusConceded") return r.saves + r.goalsConceded;
  if (field === "totalPasses") return r.totalPasses ?? 0;
  if (field === "duels") return r.duels ?? 0;
  if (field === "totalCrosses") return r.totalCrosses ?? 0;
  if (field === "tackles") return r.tackles ?? 0;
  return r[field] ?? 0;
}

export function formatMetric(value: number | null, metric?: MetricDef) {
  if (value === null || Number.isNaN(value)) return "—";
  if (metric?.format === "pct") return `${(value * 100).toFixed(1)}%`;
  if (metric?.format === "dec") return value.toFixed(2);
  return Math.round(value).toLocaleString("pt-BR");
}

export type RankingFilters = {
  league?: string;
  season?: number;
  team?: string;
  position?: string;
  nationality?: string;
  search?: string;
  minApps?: number;
  minMinutes?: number;
  metric: string;
  order?: "desc" | "asc";
  page?: number;
  pageSize?: number;
};

export type RankedPlayer = {
  rank: number;
  stat: StatRow;
  value: number;
  perGame: number | null;
  per90: number | null;
};

export async function loadStatRows(filters: { league?: string; season?: number; team?: string; position?: string }) {
  const where = [];
  if (filters.league) where.push(eq(playerSeasonStats.leagueCode, filters.league));
  if (filters.season) where.push(eq(playerSeasonStats.season, filters.season));
  if (filters.team) where.push(eq(playerSeasonStats.teamExternalId, filters.team));
  if (filters.position) where.push(eq(players.position, filters.position));
  const rows = await db
    .select({ stat: playerSeasonStats, player: players })
    .from(playerSeasonStats)
    .innerJoin(players, eq(players.id, playerSeasonStats.playerId))
    .where(where.length ? and(...where) : undefined);
  return rows.map((r) => ({ ...r.stat, player: r.player })) as StatRow[];
}

export function rankRows(rows: StatRow[], filters: RankingFilters): { items: RankedPlayer[]; total: number; metric: MetricDef; excludedForSample: number } {
  const metric = metricByKey(filters.metric) ?? METRICS[0];
  const minApps = Math.max(filters.minApps ?? 1, metric.needsDetailed ? 1 : 1);
  const search = filters.search?.trim().toLowerCase();
  const nat = filters.nationality?.trim().toLowerCase();
  let excluded = 0;
  const scored: RankedPlayer[] = [];
  for (const r of rows) {
    if (r.appearances < minApps) continue;
    if (filters.minMinutes && (r.minutes ?? 0) < filters.minMinutes) continue;
    if (metric.gkOnly && r.player.position !== "G") continue;
    if (search && !`${r.player.name} ${r.player.shortName} ${r.teamName}`.toLowerCase().includes(search)) continue;
    if (nat && !r.player.nationality.toLowerCase().includes(nat)) continue;
    if (metric.minSample && sampleValue(r, metric.minSample.field) < metric.minSample.value) {
      excluded += 1;
      continue;
    }
    const value = metric.compute(r);
    if (value === null || Number.isNaN(value)) continue;
    if (metric.format !== "pct" && !metric.lowerIsBetter && value === 0 && filters.order !== "asc") continue;
    scored.push({ rank: 0, stat: r, value, perGame: perGame(value, r.appearances), per90: per90(value, r.minutes) });
  }
  const asc = filters.order === "asc";
  scored.sort((a, b) => {
    const diff = asc ? a.value - b.value : b.value - a.value;
    if (diff !== 0) return diff;
    return b.stat.appearances - a.stat.appearances;
  });
  scored.forEach((row, i) => (row.rank = i + 1));
  const page = Math.max(1, filters.page ?? 1);
  const size = Math.min(100, Math.max(10, filters.pageSize ?? 25));
  return { items: scored.slice((page - 1) * size, page * size), total: scored.length, metric, excludedForSample: excluded };
}

/** Médias da liga e da posição para comparação no perfil (apenas jogadores com ≥1 jogo). */
export function averagesFor(rows: StatRow[], position: string) {
  const played = rows.filter((r) => r.appearances > 0);
  const samePos = played.filter((r) => r.player.position === position);
  const avg = (list: StatRow[], f: (r: StatRow) => number | null) => {
    const vals = list.map(f).filter((v): v is number => v !== null && !Number.isNaN(v));
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  };
  const pick = (list: StatRow[]) => ({
    count: list.length,
    goalsPerGame: avg(list, (r) => perGame(r.goals, r.appearances)),
    assistsPerGame: avg(list, (r) => perGame(r.assists, r.appearances)),
    shotsPerGame: avg(list, (r) => perGame(r.shots, r.appearances)),
    foulsCommittedPerGame: avg(list, (r) => perGame(r.foulsCommitted, r.appearances)),
    foulsSufferedPerGame: avg(list, (r) => perGame(r.foulsSuffered, r.appearances)),
    cardsPerGame: avg(list, (r) => perGame(cards(r), r.appearances)),
    offsidesPerGame: avg(list, (r) => perGame(r.offsides, r.appearances)),
    passAccuracy: avg(list.filter((r) => (r.totalPasses ?? 0) >= 100), (r) => ratio(r.accuratePasses ?? 0, r.totalPasses ?? 0)),
    tacklesPerGame: avg(list.filter((r) => r.detailed), (r) => perGame(r.tackles ?? 0, r.appearances)),
    interceptionsPerGame: avg(list.filter((r) => r.detailed), (r) => perGame(r.interceptions ?? 0, r.appearances)),
    duelWinRate: avg(list.filter((r) => (r.duels ?? 0) >= 30), (r) => ratio(r.duelsWon ?? 0, r.duels ?? 0)),
  });
  return { league: pick(played), position: pick(samePos) };
}

export async function getPlayerProfile(playerId: number, league?: string, season?: number) {
  const [player] = await db.select().from(players).where(eq(players.id, playerId)).limit(1);
  if (!player) return null;
  const seasons = await db
    .select()
    .from(playerSeasonStats)
    .where(eq(playerSeasonStats.playerId, playerId))
    .orderBy(desc(playerSeasonStats.season), desc(playerSeasonStats.appearances));
  const current = seasons.find((s) => (!league || s.leagueCode === league) && (!season || s.season === season)) ?? seasons[0] ?? null;
  if (current && (!current.detailedAt || Date.now() - new Date(current.detailedAt).getTime() > DETAIL_TTL_MS) && current.appearances > 0) {
    await enrichPlayerStats(current.id, player.externalId, current.leagueCode, current.season);
  }
  const refreshed = current ? (await db.select().from(playerSeasonStats).where(eq(playerSeasonStats.id, current.id)).limit(1))[0] : null;
  return { player, seasons, current: refreshed ?? current };
}

export async function teamsInLeague(code: string, season?: number) {
  const rows = await db
    .selectDistinct({ id: playerSeasonStats.teamExternalId, name: playerSeasonStats.teamName, logo: playerSeasonStats.teamLogo })
    .from(playerSeasonStats)
    .where(and(eq(playerSeasonStats.leagueCode, code), season ? eq(playerSeasonStats.season, season) : undefined))
    .orderBy(asc(playerSeasonStats.teamName));
  return rows.filter((r) => r.id);
}

export async function nationalitiesInLeague(code?: string) {
  const rows = await db
    .selectDistinct({ nationality: players.nationality })
    .from(players)
    .innerJoin(playerSeasonStats, eq(playerSeasonStats.playerId, players.id))
    .where(code ? eq(playerSeasonStats.leagueCode, code) : undefined)
    .orderBy(asc(players.nationality));
  return rows.map((r) => r.nationality).filter(Boolean);
}

export async function getPlayersByIds(ids: number[], league?: string, season?: number) {
  if (!ids.length) return [];
  const rows = await db
    .select({ stat: playerSeasonStats, player: players })
    .from(playerSeasonStats)
    .innerJoin(players, eq(players.id, playerSeasonStats.playerId))
    .where(and(inArray(players.id, ids), league ? eq(playerSeasonStats.leagueCode, league) : undefined, season ? eq(playerSeasonStats.season, season) : undefined))
    .orderBy(desc(playerSeasonStats.season), desc(playerSeasonStats.appearances));
  const seen = new Set<number>();
  const out: StatRow[] = [];
  for (const r of rows) {
    if (seen.has(r.player.id)) continue;
    seen.add(r.player.id);
    out.push({ ...r.stat, player: r.player });
  }
  for (const r of out) {
    if (r.appearances > 0 && (!r.detailedAt || Date.now() - new Date(r.detailedAt).getTime() > DETAIL_TTL_MS)) {
      await enrichPlayerStats(r.id, r.player.externalId, r.leagueCode, r.season);
    }
  }
  const ids2 = out.map((r) => r.id);
  const fresh = ids2.length ? await db.select({ stat: playerSeasonStats, player: players }).from(playerSeasonStats).innerJoin(players, eq(players.id, playerSeasonStats.playerId)).where(inArray(playerSeasonStats.id, ids2)) : [];
  return ids.map((id) => fresh.find((f) => f.player.id === id)).filter(Boolean).map((r) => ({ ...r!.stat, player: r!.player })) as StatRow[];
}

export async function searchPlayers(query: string, league?: string, limit = 12) {
  const q = `%${query.trim().toLowerCase()}%`;
  if (query.trim().length < 2) return [];
  const rows = await db
    .select({ player: players, stat: playerSeasonStats })
    .from(players)
    .innerJoin(playerSeasonStats, eq(playerSeasonStats.playerId, players.id))
    .where(and(sql`lower(${players.name}) like ${q}`, league ? eq(playerSeasonStats.leagueCode, league) : undefined))
    .orderBy(desc(playerSeasonStats.appearances))
    .limit(limit * 3);
  const seen = new Set<number>();
  return rows.filter((r) => (seen.has(r.player.id) ? false : (seen.add(r.player.id), true))).slice(0, limit);
}

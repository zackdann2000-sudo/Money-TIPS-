import { and, eq, sql } from "drizzle-orm";
import { API_CACHE_TTL_MS, cached } from "@/lib/api-cache";
import { db } from "@/db";
import { leagues, matches, teams } from "@/db/schema";

export type ProviderId = "api-football" | "api-football-rapidapi" | "football-data" | "sportsdb" | "sportmonks" | "bzzoiro" | "custom";

export type ProviderPreset = {
  id: ProviderId;
  label: string;
  baseUrl: string;
  docs: string;
  testPath: string;
  authHint: string;
  coverage: string;
  supportsSync: boolean;
  keyRequired: boolean;
};

export const PROVIDER_PRESETS: ProviderPreset[] = [
  {
    id: "api-football",
    label: "API-Football (api-sports.io)",
    baseUrl: "https://v3.football.api-sports.io",
    docs: "https://www.api-football.com/documentation-v3",
    testPath: "/status",
    authHint: "Header x-apisports-key",
    coverage: "Jogos ao vivo, eventos, escalações, estatísticas e odds de 1.100+ ligas",
    supportsSync: true,
    keyRequired: true,
  },
  {
    id: "api-football-rapidapi",
    label: "API-Football via RapidAPI",
    baseUrl: "https://api-football-v1.p.rapidapi.com/v3",
    docs: "https://rapidapi.com/api-sports/api/api-football",
    testPath: "/status",
    authHint: "Headers x-rapidapi-key + x-rapidapi-host",
    coverage: "Mesmos dados da API-Football, assinatura pelo RapidAPI",
    supportsSync: true,
    keyRequired: true,
  },
  {
    id: "football-data",
    label: "Football-Data.org (v4)",
    baseUrl: "https://api.football-data.org/v4",
    docs: "https://www.football-data.org/documentation/quickstart",
    testPath: "/competitions",
    authHint: "Header X-Auth-Token",
    coverage: "Resultados, calendário, classificação e artilheiros das principais ligas (grátis: 10 req/min)",
    supportsSync: true,
    keyRequired: true,
  },
  {
    id: "sportsdb",
    label: "TheSportsDB",
    baseUrl: "https://www.thesportsdb.com/api/v1/json",
    docs: "https://www.thesportsdb.com/free_sports_api",
    testPath: "/all_leagues.php",
    authHint: "A chave entra na URL (use 123 para testes)",
    coverage: "Escudos, estádios, elencos e dados históricos",
    supportsSync: false,
    keyRequired: false,
  },
  {
    id: "sportmonks",
    label: "Sportmonks Football v3",
    baseUrl: "https://api.sportmonks.com/v3/football",
    docs: "https://docs.sportmonks.com/football",
    testPath: "/leagues",
    authHint: "Query api_token",
    coverage: "Dados ao vivo, xG, escalações e estatísticas avançadas",
    supportsSync: false,
    keyRequired: true,
  },
  {
    id: "bzzoiro",
    label: "Bzzoiro Sports Data (BSD)",
    baseUrl: "https://sports.bzzoiro.com/api/v2",
    docs: "https://sports.bzzoiro.com/docs/football/",
    testPath: "/coverage/",
    authHint: "Header Authorization: Token <chave>",
    coverage: "30+ ligas · estatísticas com xG · incidentes · odds · previsões ML (grátis, sem limite)",
    supportsSync: false,
    keyRequired: true,
  },
  {
    id: "custom",
    label: "API personalizada",
    baseUrl: "",
    docs: "",
    testPath: "/",
    authHint: "Header Authorization: Bearer <chave>",
    coverage: "Qualquer endpoint JSON próprio",
    supportsSync: false,
    keyRequired: false,
  },
];

export function presetFor(provider: string): ProviderPreset {
  const normalized = provider.toLowerCase();
  const exact = PROVIDER_PRESETS.find((p) => p.id === normalized);
  if (exact) return exact;
  if (normalized.includes("rapid")) return PROVIDER_PRESETS[1];
  if (normalized.includes("api-football") || normalized.includes("apisports") || normalized.includes("api sports")) return PROVIDER_PRESETS[0];
  if (normalized.includes("football-data") || normalized.includes("football data")) return PROVIDER_PRESETS[2];
  if (normalized.includes("sportsdb")) return PROVIDER_PRESETS[3];
  if (normalized.includes("sportmonks")) return PROVIDER_PRESETS[4];
  if (normalized.includes("bzzoiro")) return PROVIDER_PRESETS[5];
  return PROVIDER_PRESETS[6];
}

/** Corrige URLs comuns digitadas errado (site em vez da API, barra final, falta de versão). */
export function normalizeBaseUrl(provider: string, raw: string): string {
  const preset = presetFor(provider);
  let url = (raw || "").trim().replace(/\/+$/, "");
  if (preset.id === "custom") return url;
  if (!url) return preset.baseUrl;
  const lower = url.toLowerCase();
  if (preset.id === "football-data") {
    if (!lower.includes("api.football-data.org") || !/\/v\d/.test(lower)) return preset.baseUrl;
  }
  if (preset.id === "api-football") {
    if (!lower.includes("api-sports.io")) return preset.baseUrl;
  }
  if (preset.id === "api-football-rapidapi") {
    if (!lower.includes("rapidapi.com")) return preset.baseUrl;
    if (!/\/v3$/.test(lower)) url = `${url.replace(/\/v3.*$/, "")}/v3`;
  }
  if (preset.id === "sportmonks" && !lower.includes("api.sportmonks.com")) return preset.baseUrl;
  if (preset.id === "bzzoiro") {
    if (!lower.includes("bzzoiro.com")) return preset.baseUrl;
    if (!/\/api\/v2$/.test(lower)) return preset.baseUrl;
  }
  if (preset.id === "sportsdb") {
    if (!lower.includes("thesportsdb.com")) return preset.baseUrl;
    url = url.replace(/\/api\/v1\/json\/\w+$/, "/api/v1/json");
  }
  return url;
}

function buildRequest(provider: string, baseUrl: string, apiKey: string, path: string, query: Record<string, string> = {}) {
  const preset = presetFor(provider);
  const headers: Record<string, string> = { Accept: "application/json", "User-Agent": "GreenScore/1.0" };
  let url = `${baseUrl}${path}`;
  const params = new URLSearchParams(query);
  if (preset.id === "api-football") headers["x-apisports-key"] = apiKey;
  if (preset.id === "api-football-rapidapi") {
    headers["x-rapidapi-key"] = apiKey;
    headers["x-rapidapi-host"] = "api-football-v1.p.rapidapi.com";
  }
  if (preset.id === "football-data") headers["X-Auth-Token"] = apiKey;
  if (preset.id === "sportmonks") params.set("api_token", apiKey);
  if (preset.id === "bzzoiro") headers.Authorization = `Token ${apiKey}`;
  if (preset.id === "sportsdb") url = `${baseUrl}/${apiKey || "123"}${path}`;
  if (preset.id === "custom" && apiKey) headers.Authorization = `Bearer ${apiKey}`;
  const qs = params.toString();
  return { url: qs ? `${url}?${qs}` : url, headers };
}

export type ProviderResult = { ok: true; message: string; data: unknown } | { ok: false; message: string };

function friendlyHttpError(status: number, contentType: string, body: string, preset: ProviderPreset): string {
  const isHtml = contentType.includes("text/html") || body.trimStart().startsWith("<");
  if (isHtml) {
    return `HTTP ${status}: o endereço respondeu com uma página HTML, não com a API. Confira a Base URL — para ${preset.label} use ${preset.baseUrl || "a URL da API JSON"}.`;
  }
  if (status === 401 || status === 403) return `HTTP ${status}: chave inválida ou sem permissão (${preset.authHint}). Gere/copie novamente a chave no painel do provedor.`;
  if (status === 404) return `HTTP 404: endpoint não encontrado em ${preset.baseUrl}${preset.testPath}. Verifique a versão da API na Base URL.`;
  if (status === 429) return "HTTP 429: limite de requisições atingido. Aguarde um minuto ou faça upgrade do plano do provedor.";
  try {
    const parsed = JSON.parse(body) as { message?: string; error?: string; errors?: unknown };
    const detail = parsed.message ?? parsed.error ?? (typeof parsed.errors === "string" ? parsed.errors : "");
    if (detail) {
      const lower = String(detail).toLowerCase();
      const hint = lower.includes("token") || lower.includes("key") ? ` Confira a chave (${preset.authHint}).` : "";
      return `HTTP ${status}: ${String(detail).replace(/\.+$/, "")}.${hint}`;
    }
  } catch {
    /* corpo não é JSON */
  }
  const snippet = body.replace(/\s+/g, " ").slice(0, 140);
  return `HTTP ${status}: ${snippet || "resposta inesperada do provedor"}`;
}

/** Requisições GET aos provedores passam pela camada de cache (60 s, stale-on-error). `ttlMs: 0` desativa. */
export async function providerFetch(provider: string, baseUrl: string, apiKey: string, path: string, query: Record<string, string> = {}, opts: { ttlMs?: number } = {}): Promise<ProviderResult> {
  const ttl = opts.ttlMs ?? API_CACHE_TTL_MS;
  if (ttl <= 0) return providerFetchRaw(provider, baseUrl, apiKey, path, query);
  const key = `${presetFor(provider).id}:${normalizeBaseUrl(provider, baseUrl)}${path}?${new URLSearchParams(query).toString()}#${apiKey.slice(-6)}`;
  try {
    const r = await cached<ProviderResult>(presetFor(provider).id, key, async () => {
      const res = await providerFetchRaw(provider, baseUrl, apiKey, path, query);
      // falhas transitórias (limite, servidor, rede) lançam para acionar o stale-on-error; erros de chave/404 ficam cacheados pouco tempo
      if (!res.ok && /429|5\d\d|Tempo limite|conectar/.test(res.message)) throw new Error(res.message);
      return res;
    }, ttl);
    if (r.stale && r.value.ok) return { ...r.value, message: `${r.value.message} (cache de ${Math.round(r.ageMs / 1000)}s — provedor instável)` };
    return r.value;
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Falha no provedor" };
  }
}

async function providerFetchRaw(provider: string, baseUrl: string, apiKey: string, path: string, query: Record<string, string> = {}): Promise<ProviderResult> {
  const preset = presetFor(provider);
  const normalized = normalizeBaseUrl(provider, baseUrl);
  if (!normalized) return { ok: false, message: "Informe a Base URL da API." };
  if (preset.keyRequired && !apiKey) return { ok: false, message: `Esta integração exige chave (${preset.authHint}).` };
  const { url, headers } = buildRequest(provider, normalized, apiKey, path, query);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, { headers, signal: controller.signal, cache: "no-store" });
    const contentType = response.headers.get("content-type") ?? "";
    const text = await response.text();
    if (!response.ok) return { ok: false, message: friendlyHttpError(response.status, contentType, text, preset) };
    let data: unknown;
    try {
      data = JSON.parse(text);
    } catch {
      return { ok: false, message: `A resposta não é JSON (${contentType || "sem content-type"}). Confira a Base URL: ${normalized}` };
    }
    // API-Football devolve HTTP 200 com erros no corpo quando a chave é inválida.
    const errors = (data as { errors?: unknown })?.errors;
    if (errors && typeof errors === "object" && !Array.isArray(errors) && Object.keys(errors as object).length > 0) {
      const first = Object.values(errors as Record<string, string>)[0];
      return { ok: false, message: `Provedor recusou a requisição: ${String(first)}` };
    }
    if (Array.isArray(errors) && errors.length > 0) return { ok: false, message: `Provedor recusou a requisição: ${String(errors[0])}` };
    return { ok: true, message: "OK", data };
  } catch (error) {
    const reason = error instanceof Error ? (error.name === "AbortError" ? "tempo limite de 12s excedido" : error.message) : "falha de rede";
    return { ok: false, message: `Não foi possível conectar em ${normalized}: ${reason}` };
  } finally {
    clearTimeout(timer);
  }
}

export async function testProvider(provider: string, baseUrl: string, apiKey: string): Promise<ProviderResult> {
  const preset = presetFor(provider);
  const result = await providerFetch(provider, baseUrl, apiKey, preset.testPath, {}, { ttlMs: 0 });
  if (!result.ok) return result;
  const data = result.data as Record<string, unknown>;
  let message = `Conexão OK com ${preset.label}.`;
  if (preset.id === "api-football" || preset.id === "api-football-rapidapi") {
    const account = (data.response as { account?: { firstname?: string }; subscription?: { plan?: string; end?: string }; requests?: { current?: number; limit_day?: number } }) ?? {};
    message = `Conectado como ${account.account?.firstname ?? "conta"} · plano ${account.subscription?.plan ?? "?"} · ${account.requests?.current ?? 0}/${account.requests?.limit_day ?? "?"} requisições hoje.`;
  } else if (preset.id === "football-data") {
    const comps = Array.isArray(data.competitions) ? (data.competitions as { code?: string; name?: string; plan?: string }[]) : [];
    const free = comps.filter((c) => c.plan === "TIER_ONE");
    message = `Conexão OK · ${comps.length} competições na sua chave (${free.length} do plano gratuito: ${free.map((c) => c.code).filter(Boolean).join(", ")}). Veja tudo em /football-data.`;
  } else if (preset.id === "sportsdb") {
    const count = Array.isArray(data.leagues) ? data.leagues.length : 0;
    message = `Conexão OK · ${count} ligas listadas no TheSportsDB.`;
  } else if (preset.id === "bzzoiro") {
    const leagues = Array.isArray(data.leagues) ? data.leagues.length : Array.isArray(data.results) ? data.results.length : Array.isArray(data) ? (data as unknown[]).length : null;
    message = `Conexão OK com a Bzzoiro${leagues !== null ? ` · ${leagues} ligas cobertas` : ""}. Pronta para o Scouter Oracle (xG e previsões).`;
  } else if (preset.id === "sportmonks") {
    const count = Array.isArray(data.data) ? data.data.length : 0;
    message = `Conexão OK · ${count} ligas retornadas pelo Sportmonks.`;
  }
  return { ok: true, message, data };
}

function slugify(value: string) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

type NormalizedFixture = {
  externalId: string;
  leagueName: string;
  leagueCountry: string;
  homeName: string;
  homeShort: string;
  awayName: string;
  awayShort: string;
  kickoff: Date;
  status: "scheduled" | "live" | "finished";
  minute: number;
  homeScore: number;
  awayScore: number;
  venue: string;
  round: string;
};

async function upsertLeague(name: string, country: string) {
  const slug = slugify(name) || "liga";
  const [existing] = await db.select({ id: leagues.id }).from(leagues).where(eq(leagues.slug, slug)).limit(1);
  if (existing) return existing.id;
  const [created] = await db.insert(leagues).values({ slug, name, country, flag: "🌍", season: String(new Date().getFullYear()), sortOrder: 50 }).returning({ id: leagues.id });
  return created.id;
}

async function upsertTeam(name: string, short: string, leagueId: number, country: string) {
  const slug = slugify(name) || `time-${Date.now()}`;
  const [existing] = await db.select({ id: teams.id }).from(teams).where(eq(teams.slug, slug)).limit(1);
  if (existing) return existing.id;
  const palette = ["#0b8f4e", "#1d4ed8", "#b91c1c", "#7c3aed", "#0f766e", "#c2410c", "#334155"];
  const [created] = await db
    .insert(teams)
    .values({
      slug,
      name,
      shortName: (short || name.slice(0, 3)).toUpperCase().slice(0, 3),
      leagueId,
      country,
      badgeColor: palette[name.length % palette.length],
      description: `${name} — dados importados automaticamente da integração de API. Estatísticas detalhadas serão preenchidas conforme os jogos forem sincronizados.`,
    })
    .returning({ id: teams.id });
  return created.id;
}

async function persistFixtures(fixtures: NormalizedFixture[], source: string) {
  let created = 0;
  let updated = 0;
  for (const fixture of fixtures) {
    const leagueId = await upsertLeague(fixture.leagueName, fixture.leagueCountry);
    const homeId = await upsertTeam(fixture.homeName, fixture.homeShort, leagueId, fixture.leagueCountry);
    const awayId = await upsertTeam(fixture.awayName, fixture.awayShort, leagueId, fixture.leagueCountry);
    const values = {
      leagueId,
      homeTeamId: homeId,
      awayTeamId: awayId,
      kickoff: fixture.kickoff,
      status: fixture.status,
      minute: fixture.minute,
      round: fixture.round,
      venue: fixture.venue,
      homeScore: fixture.homeScore,
      awayScore: fixture.awayScore,
      externalId: fixture.externalId,
      source,
      updatedAt: new Date(),
    };
    const [existing] = await db
      .select({ id: matches.id })
      .from(matches)
      .where(and(eq(matches.externalId, fixture.externalId), eq(matches.source, source)))
      .limit(1);
    if (existing) {
      await db.update(matches).set(values).where(eq(matches.id, existing.id));
      updated += 1;
    } else {
      await db.insert(matches).values(values);
      created += 1;
    }
  }
  return { created, updated };
}

function isoDay(offsetDays = 0) {
  return new Date(Date.now() + offsetDays * 86400000).toISOString().slice(0, 10);
}

export async function syncProvider(provider: string, baseUrl: string, apiKey: string): Promise<ProviderResult> {
  const preset = presetFor(provider);
  if (!preset.supportsSync) return { ok: false, message: `${preset.label} ainda não possui importação automática de jogos. Use API-Football ou Football-Data.` };

  if (preset.id === "football-data") {
    const result = await providerFetch(provider, baseUrl, apiKey, "/matches", { dateFrom: isoDay(0), dateTo: isoDay(1) });
    if (!result.ok) return result;
    const payload = result.data as { matches?: Array<Record<string, unknown>> };
    const list = payload.matches ?? [];
    const fixtures: NormalizedFixture[] = list.map((m) => {
      const competition = (m.competition as { name?: string }) ?? {};
      const area = (m.area as { name?: string }) ?? {};
      const home = (m.homeTeam as { name?: string; shortName?: string; tla?: string }) ?? {};
      const away = (m.awayTeam as { name?: string; shortName?: string; tla?: string }) ?? {};
      const score = (m.score as { fullTime?: { home?: number | null; away?: number | null } }) ?? {};
      const statusRaw = String(m.status ?? "SCHEDULED");
      const status: NormalizedFixture["status"] = ["IN_PLAY", "PAUSED", "LIVE"].includes(statusRaw) ? "live" : ["FINISHED", "AWARDED"].includes(statusRaw) ? "finished" : "scheduled";
      return {
        externalId: String(m.id),
        leagueName: competition.name ?? "Competição",
        leagueCountry: area.name ?? "Internacional",
        homeName: home.name ?? "Mandante",
        homeShort: home.tla ?? home.shortName ?? "",
        awayName: away.name ?? "Visitante",
        awayShort: away.tla ?? away.shortName ?? "",
        kickoff: new Date(String(m.utcDate ?? new Date().toISOString())),
        status,
        minute: status === "live" ? Number(m.minute ?? 45) : status === "finished" ? 90 : 0,
        homeScore: Number(score.fullTime?.home ?? 0),
        awayScore: Number(score.fullTime?.away ?? 0),
        venue: String(m.venue ?? ""),
        round: m.matchday ? `Rodada ${m.matchday}` : String(m.stage ?? "Rodada"),
      };
    });
    const { created, updated } = await persistFixtures(fixtures, "football-data");
    return { ok: true, message: `Sincronizado: ${fixtures.length} jogo(s) de hoje/amanhã · ${created} novo(s), ${updated} atualizado(s).`, data: null };
  }

  // API-Football (direto ou RapidAPI)
  const live = await providerFetch(provider, baseUrl, apiKey, "/fixtures", { live: "all" });
  if (!live.ok) return live;
  const today = await providerFetch(provider, baseUrl, apiKey, "/fixtures", { date: isoDay(0) });
  const rows = [
    ...(((live.data as { response?: Array<Record<string, unknown>> }).response) ?? []),
    ...((today.ok ? ((today.data as { response?: Array<Record<string, unknown>> }).response ?? []) : [])),
  ];
  const seen = new Set<string>();
  const fixtures: NormalizedFixture[] = [];
  for (const row of rows) {
    const fixture = (row.fixture as { id?: number; date?: string; status?: { short?: string; elapsed?: number | null }; venue?: { name?: string } }) ?? {};
    const id = String(fixture.id ?? "");
    if (!id || seen.has(id)) continue;
    seen.add(id);
    const league = (row.league as { name?: string; country?: string; round?: string }) ?? {};
    const t = (row.teams as { home?: { name?: string }; away?: { name?: string } }) ?? {};
    const goals = (row.goals as { home?: number | null; away?: number | null }) ?? {};
    const short = fixture.status?.short ?? "NS";
    const status: NormalizedFixture["status"] = ["1H", "2H", "HT", "ET", "BT", "P", "LIVE", "INT"].includes(short) ? "live" : ["FT", "AET", "PEN", "AWD", "WO"].includes(short) ? "finished" : "scheduled";
    fixtures.push({
      externalId: id,
      leagueName: league.name ?? "Competição",
      leagueCountry: league.country ?? "Internacional",
      homeName: t.home?.name ?? "Mandante",
      homeShort: "",
      awayName: t.away?.name ?? "Visitante",
      awayShort: "",
      kickoff: new Date(fixture.date ?? new Date().toISOString()),
      status,
      minute: status === "live" ? Number(fixture.status?.elapsed ?? 1) : status === "finished" ? 90 : 0,
      homeScore: Number(goals.home ?? 0),
      awayScore: Number(goals.away ?? 0),
      venue: fixture.venue?.name ?? "",
      round: league.round ?? "Rodada",
    });
  }
  const limited = fixtures.slice(0, 120);
  const { created, updated } = await persistFixtures(limited, "api-football");
  return { ok: true, message: `Sincronizado: ${limited.length} jogo(s) (ao vivo + hoje) · ${created} novo(s), ${updated} atualizado(s).`, data: null };
}


/* ---------------------------------------------------------------------- */
/*  Acesso às integrações cadastradas no painel (reutilizado pelo Oracle)  */
/* ---------------------------------------------------------------------- */

import { apiIntegrations } from "@/db/schema";

export async function getIntegration(providerId: ProviderId) {
  const [row] = await db
    .select()
    .from(apiIntegrations)
    .where(and(eq(apiIntegrations.provider, providerId), eq(apiIntegrations.isActive, true), sql`length(${apiIntegrations.apiKey}) > 0`))
    .orderBy(apiIntegrations.id)
    .limit(1);
  return row ?? null;
}

/** Faz uma requisição usando a chave/URL cadastradas no painel para o provedor. */
export async function callIntegration(providerId: ProviderId, path: string, query: Record<string, string> = {}): Promise<ProviderResult & { configured: boolean }> {
  const integration = await getIntegration(providerId);
  if (!integration) return { ok: false, message: `${presetFor(providerId).label} não está cadastrada/ativa em Admin → APIs de dados.`, configured: false };
  const result = await providerFetch(integration.provider, normalizeBaseUrl(integration.provider, integration.baseUrl), integration.apiKey, path, query);
  await db
    .update(apiIntegrations)
    .set({ requestsToday: sql`${apiIntegrations.requestsToday} + 1`, lastSyncAt: result.ok ? new Date() : integration.lastSyncAt, status: result.ok ? "connected" : "error", lastError: result.ok ? "" : result.message })
    .where(eq(apiIntegrations.id, integration.id))
    .catch(() => undefined);
  return { ...result, configured: true };
}

import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { matchEvents, matches, teams } from "@/db/schema";
import { and as andOp, desc as descOp, eq as eqOp, or, sql } from "drizzle-orm";
import { getMatchById, type MatchRow } from "@/lib/data";
import { callIntegration } from "@/lib/providers";
import { getAnalysis } from "@/lib/analysis-cache";

/* ====================================================================== */
/*  SCOUTER ORACLE — veredito de intervalo/ao vivo                         */
/*  Fontes (nesta ordem): Sportmonks (xG oficial) → Bzzoiro (xG/prob.)    */
/*  → dados reais já sincronizados no site (xG estimado por finalizações). */
/* ====================================================================== */

export type Veredito = "MANTER" | "COBRIR" | "MUDAR" | "SAIR";
export type LadoPressao = "casa" | "fora" | "equilibrada";

export type Pressao = {
  lado: LadoPressao;
  /** 0–100: participação do mandante no volume ofensivo recente (50 = equilíbrio). */
  indice: number;
  /** true quando houve expulsão nos últimos 15 minutos de jogo. */
  vermelhoRecente: boolean;
  descricao: string;
};

export type Selo = "real" | "demo";
type Media10 = { n: number; xg: number | null; escanteios: number | null; cartoes: number | null; finalizacoes: number | null };
export type MetricaComparada = {
  chave: "xg" | "escanteios" | "cartoes" | "finalizacoes";
  label: string;
  aoVivo: { casa: number; fora: number };
  mediaUltimos10: { casa: number | null; fora: number | null; jogosCasa: number; jogosFora: number };
  /** ao vivo ÷ média (já ajustado ao minuto) — >1 = acima do ritmo habitual */
  ritmo: { casa: number | null; fora: number | null };
  selo: Selo;
  fonte: string;
};

export type OracleData = {
  matchId: number;
  xgCasa: number;
  xgFora: number;
  pressao: string;
  veredito: Veredito;
  explicacao: string;
  selo: Selo;
  metricas: MetricaComparada[];
  detalhes: {
    pressaoIndice: number;
    pressaoLado: LadoPressao;
    vermelhoRecente: boolean;
    minuto: number;
    placar: string;
    status: string;
    fonteXg: string;
    fonteProbabilidades: string;
    xgEstimado: boolean;
    probabilidades: { casa: number; empate: number; fora: number } | null;
    fontesTentadas: { fonte: string; ok: boolean; detalhe: string }[];
    atualizadoEm: string;
  };
};

/* --------------------------- Regra de negócio --------------------------- */

const XG_BAIXO = 0.5;
const DIFERENCA_TRUNCADA = 0.3;
const PRESSAO_ALTA = 60; // ≥60% do volume ofensivo recente
const PRESSAO_BAIXA = 40;

/**
 * Regra de negócio do Scouter Oracle.
 *  - SAIR   : xG de ambos < 0,5 OU cartão vermelho recente (prioridade máxima).
 *  - COBRIR : |xgCasa − xgFora| < 0,3 E pressão equilibrada (jogo truncado).
 *  - MANTER : xgCasa > xgFora E pressão alta do mandante.
 *  - MUDAR  : xgCasa < xgFora E visitante pressionando.
 *  Casos intermediários caem para COBRIR (sinais contraditórios).
 */
export function calcularVeredito(xgCasa: number, xgFora: number, pressao: Pressao | LadoPressao | string): { veredito: Veredito; explicacao: string } {
  const p = normalizarPressao(pressao);
  const diff = xgCasa - xgFora;
  const f = (v: number) => v.toFixed(2);

  if (p.vermelhoRecente) {
    return { veredito: "SAIR", explicacao: "Houve cartão vermelho recente: o jogo muda de dinâmica e as leituras anteriores de xG e pressão deixam de valer." };
  }
  if (xgCasa < XG_BAIXO && xgFora < XG_BAIXO) {
    return { veredito: "SAIR", explicacao: `Produção ofensiva muito baixa dos dois lados (xG ${f(xgCasa)} x ${f(xgFora)}, ambos abaixo de ${XG_BAIXO}). Sem sinal confiável para sustentar posição.` };
  }
  const equilibrada = p.lado === "equilibrada" || (p.indice > PRESSAO_BAIXA && p.indice < PRESSAO_ALTA);
  if (Math.abs(diff) < DIFERENCA_TRUNCADA && equilibrada) {
    return { veredito: "COBRIR", explicacao: `Jogo truncado: diferença de xG de apenas ${f(Math.abs(diff))} e pressão equilibrada (${p.indice}% casa / ${100 - p.indice}% fora). Proteger a posição é a leitura mais segura.` };
  }
  if (diff > 0 && (p.lado === "casa" || p.indice >= PRESSAO_ALTA)) {
    return { veredito: "MANTER", explicacao: `O mandante tem xG maior (${f(xgCasa)} contra ${f(xgFora)}) e concentra ${p.indice}% do volume ofensivo recente. O cenário favorece manter a posição.` };
  }
  if (diff < 0 && (p.lado === "fora" || p.indice <= PRESSAO_BAIXA)) {
    return { veredito: "MUDAR", explicacao: `O visitante produz mais (xG ${f(xgFora)} contra ${f(xgCasa)}) e está pressionando (${100 - p.indice}% do volume recente). A tendência aponta para o lado visitante.` };
  }
  // Sinais contraditórios (ex.: xG favorece um lado, pressão recente favorece o outro)
  return {
    veredito: "COBRIR",
    explicacao: `Sinais divergentes: o xG favorece ${diff > 0 ? "o mandante" : "o visitante"} (${f(xgCasa)} x ${f(xgFora)}), mas a pressão recente está ${p.lado === "equilibrada" ? "equilibrada" : `com o ${p.lado === "casa" ? "mandante" : "visitante"}`} (${p.indice}% casa). Cobrir reduz a exposição até o jogo se definir.`,
  };
}

function normalizarPressao(input: Pressao | LadoPressao | string): Pressao {
  if (typeof input === "object") return input;
  const txt = input.toLowerCase();
  if (txt.includes("casa") || txt.includes("mandante") || txt.includes("home")) return { lado: "casa", indice: 70, vermelhoRecente: txt.includes("vermelho"), descricao: input };
  if (txt.includes("fora") || txt.includes("visitante") || txt.includes("away")) return { lado: "fora", indice: 30, vermelhoRecente: txt.includes("vermelho"), descricao: input };
  return { lado: "equilibrada", indice: 50, vermelhoRecente: txt.includes("vermelho"), descricao: input };
}

export function descreverPressao(p: Pressao) {
  if (p.vermelhoRecente) return `${p.lado === "casa" ? "Alta para o Time da Casa" : p.lado === "fora" ? "Alta para o Visitante" : "Equilibrada"} · cartão vermelho recente`;
  if (p.lado === "casa") return p.indice >= 70 ? "Alta para o Time da Casa" : "Moderada para o Time da Casa";
  if (p.lado === "fora") return p.indice <= 30 ? "Alta para o Visitante" : "Moderada para o Visitante";
  return "Equilibrada";
}

/* --------------------------- Utilidades internas -------------------------- */

const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\b(fc|cf|sc|ec|afc|club|de|do|da|futebol|clube)\b/g, "").replace(/[^a-z0-9]+/g, " ").trim();
function sameTeam(a: string, b: string) {
  const x = norm(a), y = norm(b);
  if (!x || !y) return false;
  if (x === y || x.includes(y) || y.includes(x)) return true;
  const xs = new Set(x.split(" ").filter((w) => w.length > 2)), ys = y.split(" ").filter((w) => w.length > 2);
  return ys.some((w) => xs.has(w));
}
const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);
const day = (d: Date) => d.toISOString().slice(0, 10);

type Tentativa = { fonte: string; ok: boolean; detalhe: string };

/* ------------------------- Bzzoiro (xG + probabilidades) ------------------- */

async function bzzoiroEvent(match: MatchRow, tentativas: Tentativa[]): Promise<{ id: number } | null> {
  const from = day(match.kickoff), to = day(new Date(match.kickoff.getTime() + 86400000));
  const name = (t: { name?: string } | string | undefined) => (typeof t === "string" ? t : t?.name ?? "");
  type Ev = { id: number; home_team?: { name?: string } | string; away_team?: { name?: string } | string; home?: string; away?: string; home_team_id?: number; away_team_id?: number };
  const matchIt = (e: Ev) => sameTeam(name(e.home_team) || e.home || "", match.homeName) && sameTeam(name(e.away_team) || e.away || "", match.awayName);
  let page = 1;
  let lastError = "";
  while (page <= 5) {
    const list = await callIntegration("bzzoiro", "/events/", { date_from: from, date_to: to, page_size: "200", page: String(page) });
    if (!list.ok) { lastError = list.message; break; }
    const raw = list.data as { results?: Ev[]; data?: Ev[]; next?: string | null } | Ev[];
    const events = (Array.isArray(raw) ? raw : raw.results ?? raw.data ?? []) as Ev[];
    const found = events.find(matchIt);
    if (found) {
      if (found.home_team_id) bzTeamIds.set(norm(match.homeName), found.home_team_id);
      if (found.away_team_id) bzTeamIds.set(norm(match.awayName), found.away_team_id);
      return { id: found.id };
    }
    if (Array.isArray(raw) || !raw.next || events.length === 0) break;
    page += 1;
  }
  tentativas.push({ fonte: "Bzzoiro", ok: false, detalhe: lastError || "Partida não localizada na Bzzoiro para esta data." });
  return null;
}

async function statsBzzoiro(eventId: number, tentativas: Tentativa[]): Promise<LiveStats | null> {
  const res = await callIntegration("bzzoiro", `/events/${eventId}/stats/`);
  if (!res.ok) {
    tentativas.push({ fonte: "Bzzoiro stats", ok: false, detalhe: res.message });
    return null;
  }
  // Formato real da BSD: { stats: { home: { xg: { actual, estimated }, corner_kicks, yellow_cards, red_cards, total_shots, ... }, away: {...} }, xg_estimated }
  const payload = res.data as { stats?: { home?: Record<string, unknown>; away?: Record<string, unknown> }; xg_estimated?: boolean };
  const h = payload.stats?.home, a = payload.stats?.away;
  if (!h || !a) {
    tentativas.push({ fonte: "Bzzoiro stats", ok: false, detalhe: "Resposta sem bloco stats.home/away." });
    return null;
  }
  const xgOf = (side: Record<string, unknown>) => {
    const xg = side.xg as { actual?: unknown; estimated?: unknown } | number | undefined;
    if (typeof xg === "object" && xg) return num(xg.actual) ?? num(xg.estimated);
    return num(xg);
  };
  const pair = (key: string) => { const hv = num(h[key]), av = num(a[key]); return hv === null && av === null ? null : { casa: hv ?? 0, fora: av ?? 0 }; };
  const yellow = pair("yellow_cards"), red = pair("red_cards");
  const out: LiveStats = {
    xgCasa: xgOf(h), xgFora: xgOf(a),
    escanteios: pair("corner_kicks"),
    cartoes: yellow ? { casa: yellow.casa + (red?.casa ?? 0), fora: yellow.fora + (red?.fora ?? 0) } : null,
    finalizacoes: pair("total_shots"),
  };
  const any = out.xgCasa !== null || out.escanteios || out.cartoes || out.finalizacoes;
  tentativas.push({ fonte: "Bzzoiro stats", ok: Boolean(any), detalhe: any ? `evento ${eventId}${out.xgCasa !== null ? (payload.xg_estimated ? " · xG estimado pelo provedor" : " · xG real") : " · sem xG ainda"}` : "estatísticas ainda vazias para o evento" });
  return any ? out : null;
}

async function probBzzoiro(eventId: number, kickoff: Date, tentativas: Tentativa[]): Promise<{ casa: number; empate: number; fora: number } | null> {
  const res = await callIntegration("bzzoiro", "/predictions/", { date_from: day(kickoff), date_to: day(new Date(kickoff.getTime() + 86400000)), page_size: "200" });
  if (!res.ok) {
    tentativas.push({ fonte: "Bzzoiro previsões", ok: false, detalhe: res.message });
    return null;
  }
  const raw = res.data as { results?: Record<string, unknown>[] } | Record<string, unknown>[];
  const list = (Array.isArray(raw) ? raw : raw.results ?? []) as Record<string, unknown>[];
  const row = list.find((r) => Number(r.event_id ?? r.event ?? r.match_id) === eventId);
  if (!row) {
    tentativas.push({ fonte: "Bzzoiro previsões", ok: false, detalhe: list.length ? "Sem previsão publicada para este evento (modelo pré-jogo)." : "Sem previsões para a data (o provedor publica apenas pré-jogo)." });
    return null;
  }
  const nested = (row.probabilities ?? row.prediction ?? row) as Record<string, unknown>;
  const pick = (...keys: string[]) => { for (const k of keys) { const v = num(nested[k] ?? row[k]); if (v !== null) return v > 1 ? v / 100 : v; } return null; };
  const casa = pick("home_win", "home_win_prob", "prob_home", "home", "p_home"), empate = pick("draw", "draw_prob", "prob_draw", "p_draw"), fora = pick("away_win", "away_win_prob", "prob_away", "away", "p_away");
  if (casa === null || empate === null || fora === null) {
    tentativas.push({ fonte: "Bzzoiro previsões", ok: false, detalhe: "Previsão sem campos de probabilidade reconhecíveis." });
    return null;
  }
  tentativas.push({ fonte: "Bzzoiro previsões", ok: true, detalhe: "probabilidades 1X2 (modelo ML do provedor, pré-jogo)" });
  return { casa, empate, fora };
}

/** Média dos últimos 10 jogos do time via Bzzoiro (team_id + stats por evento) — usada quando o site ainda não tem amostra. */
async function mediaBzzoiro(teamName: string, kickoff: Date, tentativas: Tentativa[]): Promise<Media10 | null> {
  const ext = bzTeamIds.get(norm(teamName));
  if (!ext) return null;
  const cacheKey = `${ext}-${day(kickoff)}`;
  const hit = bzMediaCache.get(cacheKey);
  if (hit && Date.now() - hit.at < BZ_MEDIA_TTL) {
    if (hit.value) tentativas.push({ fonte: "Bzzoiro histórico", ok: true, detalhe: `${teamName}: média real dos últimos ${hit.value.n} jogos (cache)` });
    return hit.value;
  }
  const value = await mediaBzzoiroUncached(ext, teamName, kickoff, tentativas);
  bzMediaCache.set(cacheKey, { at: Date.now(), value });
  return value;
}

async function mediaBzzoiroUncached(ext: number, teamName: string, kickoff: Date, tentativas: Tentativa[]): Promise<Media10 | null> {
  const to = day(new Date(kickoff.getTime() - 1)), from = day(new Date(kickoff.getTime() - 120 * 86400000));
  const list = await callIntegration("bzzoiro", "/events/", { team_id: String(ext), date_from: from, date_to: to, status: "finished", page_size: "30" });
  if (!list.ok) return null;
  const raw = list.data as { results?: { id: number; event_date?: string; status?: string; home_team_id?: number }[] };
  const events = (raw.results ?? []).filter((e) => !e.status || /finish/i.test(e.status)).sort((a, b) => String(b.event_date).localeCompare(String(a.event_date))).slice(0, 10);
  if (!events.length) return null;
  const acc = { n: 0, xg: 0, esc: 0, cart: 0, fin: 0 };
  await Promise.all(events.map(async (e) => {
    const st = await callIntegration("bzzoiro", `/events/${e.id}/stats/`);
    if (!st.ok) return;
    const payload = st.data as { stats?: { home?: Record<string, unknown>; away?: Record<string, unknown> } };
    const side = (e.home_team_id === ext ? payload.stats?.home : payload.stats?.away) ?? null;
    if (!side) return;
    const xg = side.xg as { actual?: unknown; estimated?: unknown } | undefined;
    const xgv = num(xg?.actual) ?? num(xg?.estimated);
    const esc = num(side.corner_kicks), cart = (num(side.yellow_cards) ?? 0) + (num(side.red_cards) ?? 0), fin = num(side.total_shots);
    if (esc === null && fin === null && xgv === null) return;
    acc.n += 1; acc.xg += xgv ?? 0; acc.esc += esc ?? 0; acc.cart += cart; acc.fin += fin ?? 0;
  }));
  if (!acc.n) return null;
  tentativas.push({ fonte: "Bzzoiro histórico", ok: true, detalhe: `${teamName}: média real dos últimos ${acc.n} jogos` });
  const r2 = (v: number) => Math.round((v / acc.n) * 100) / 100;
  return { n: acc.n, xg: r2(acc.xg), escanteios: r2(acc.esc), cartoes: r2(acc.cart), finalizacoes: r2(acc.fin) };
}

const bzTeamIds = new Map<string, number>();
const bzMediaCache = new Map<string, { at: number; value: Media10 | null }>();
const BZ_MEDIA_TTL = 60 * 60 * 1000; // média dos últimos 10 muda só quando o time joga: 1h

/* -------------------------- API-Football (xG + stats) -------------------------- */

type LiveStats = { xgCasa: number | null; xgFora: number | null; escanteios: { casa: number; fora: number } | null; cartoes: { casa: number; fora: number } | null; finalizacoes: { casa: number; fora: number } | null };

async function statsApiFootball(match: MatchRow, tentativas: Tentativa[]): Promise<LiveStats | null> {
  const list = await callIntegration("api-football", "/fixtures", { date: day(match.kickoff), timezone: "UTC" });
  if (!list.ok) {
    tentativas.push({ fonte: "API-Football", ok: false, detalhe: list.message });
    return null;
  }
  const fixtures = ((list.data as { response?: Record<string, unknown>[] }).response ?? []) as { fixture: { id: number }; teams: { home: { name: string }; away: { name: string } } }[];
  const found = fixtures.find((f) => sameTeam(f.teams.home.name, match.homeName) && sameTeam(f.teams.away.name, match.awayName));
  if (!found) {
    tentativas.push({ fonte: "API-Football", ok: false, detalhe: "Partida não localizada na cobertura da sua chave." });
    return null;
  }
  const st = await callIntegration("api-football", "/fixtures/statistics", { fixture: String(found.fixture.id) });
  if (!st.ok) {
    tentativas.push({ fonte: "API-Football", ok: false, detalhe: st.message });
    return null;
  }
  const resp = ((st.data as { response?: { team: { name: string }; statistics: { type: string; value: unknown }[] }[] }).response ?? []);
  const pick = (team: { statistics: { type: string; value: unknown }[] } | undefined, type: RegExp) => {
    const row = team?.statistics.find((r) => type.test(r.type));
    const raw = row?.value;
    return num(typeof raw === "string" ? raw.replace("%", "") : raw);
  };
  const home = resp.find((r) => sameTeam(r.team.name, match.homeName)), away = resp.find((r) => sameTeam(r.team.name, match.awayName));
  if (!home || !away) {
    tentativas.push({ fonte: "API-Football", ok: false, detalhe: "Estatísticas ainda não publicadas para esta partida." });
    return null;
  }
  const out: LiveStats = {
    xgCasa: pick(home, /expected_goals/i), xgFora: pick(away, /expected_goals/i),
    escanteios: { casa: pick(home, /Corner/i) ?? 0, fora: pick(away, /Corner/i) ?? 0 },
    cartoes: { casa: (pick(home, /Yellow/i) ?? 0) + (pick(home, /Red/i) ?? 0), fora: (pick(away, /Yellow/i) ?? 0) + (pick(away, /Red/i) ?? 0) },
    finalizacoes: { casa: pick(home, /Total Shots/i) ?? 0, fora: pick(away, /Total Shots/i) ?? 0 },
  };
  tentativas.push({ fonte: "API-Football", ok: true, detalhe: `estatísticas da fixture ${found.fixture.id}${out.xgCasa !== null ? " (com xG)" : " (sem xG)"}` });
  return out;
}

async function statsSportmonks(match: MatchRow, tentativas: Tentativa[]): Promise<LiveStats | null> {
  const list = await callIntegration("sportmonks", `/fixtures/date/${day(match.kickoff)}`, { include: "participants" });
  if (!list.ok) {
    tentativas.push({ fonte: "Sportmonks", ok: false, detalhe: list.message });
    return null;
  }
  const fixtures = ((list.data as { data?: Record<string, unknown>[] }).data ?? []) as { id: number; participants?: { id: number; name: string; meta?: { location?: string } }[] }[];
  const found = fixtures.find((f) => sameTeam(f.participants?.find((p) => p.meta?.location === "home")?.name ?? "", match.homeName) && sameTeam(f.participants?.find((p) => p.meta?.location === "away")?.name ?? "", match.awayName));
  if (!found) {
    tentativas.push({ fonte: "Sportmonks", ok: false, detalhe: "Partida não localizada na cobertura da sua assinatura." });
    return null;
  }
  const fx = await callIntegration("sportmonks", `/fixtures/${found.id}`, { include: "xGFixture;statistics.type;participants" });
  if (!fx.ok) {
    tentativas.push({ fonte: "Sportmonks", ok: false, detalhe: fx.message });
    return null;
  }
  const data = (fx.data as { data?: { xgfixture?: { participant_id?: number; location?: string; data?: { value?: number } }[]; statistics?: { participant_id: number; location?: string; type?: { code?: string; name?: string }; type_id?: number; data?: { value?: number } }[]; participants?: { id: number; meta?: { location?: string } }[] } }).data;
  const homeId = data?.participants?.find((p) => p.meta?.location === "home")?.id;
  let xgCasa: number | null = null, xgFora: number | null = null;
  for (const row of data?.xgfixture ?? []) {
    const v = num(row.data?.value);
    if (v === null) continue;
    if (row.location === "home" || row.participant_id === homeId) xgCasa = v; else xgFora = v;
  }
  const stat = (code: RegExp, typeId: number) => {
    const pickSide = (side: "home" | "away") => {
      const row = (data?.statistics ?? []).find((r) => (r.location ? r.location === side : (r.participant_id === homeId) === (side === "home")) && (code.test(r.type?.code ?? r.type?.name ?? "") || r.type_id === typeId));
      return num(row?.data?.value);
    };
    const h = pickSide("home"), a = pickSide("away");
    return h === null && a === null ? null : { casa: h ?? 0, fora: a ?? 0 };
  };
  const out: LiveStats = { xgCasa, xgFora, escanteios: stat(/corner/i, 34), cartoes: stat(/yellowcard|cards/i, 84), finalizacoes: stat(/shots-total|shots_total/i, 42) };
  tentativas.push({ fonte: "Sportmonks", ok: true, detalhe: `fixture ${found.id}${xgCasa !== null ? " · xG oficial" : " · sem xG no plano"}` });
  return out;
}

/** Média real dos últimos 10 jogos encerrados COM estatísticas (ESPN) de um time. */
async function mediaUltimos10(teamId: number, excludeMatchId?: number): Promise<Media10> {
  const rows = await db
    .select({ home: matches.homeTeamId, hc: matches.homeCorners, ac: matches.awayCorners, hcd: matches.homeCards, acd: matches.awayCards, hs: matches.homeShots, as: matches.awayShots, hsot: matches.homeShotsOnTarget, asot: matches.awayShotsOnTarget })
    .from(matches)
    .where(andOp(eqOp(matches.source, "espn"), eqOp(matches.status, "finished"), or(eqOp(matches.homeTeamId, teamId), eqOp(matches.awayTeamId, teamId)), sql`${matches.homeShots} + ${matches.awayShots} > 0`, excludeMatchId ? sql`${matches.id} <> ${excludeMatchId}` : undefined))
    .orderBy(descOp(matches.kickoff))
    .limit(10);
  const n = rows.length;
  if (!n) return { n: 0, escanteios: null, cartoes: null, finalizacoes: null, xg: null };
  const mine = (r: typeof rows[number], h: number, a: number) => (r.home === teamId ? h : a);
  const avg = (f: (r: typeof rows[number]) => number) => Math.round((rows.reduce((s, r) => s + f(r), 0) / n) * 100) / 100;
  return {
    n,
    escanteios: avg((r) => mine(r, r.hc, r.ac)),
    cartoes: avg((r) => mine(r, r.hcd, r.acd)),
    finalizacoes: avg((r) => mine(r, r.hs, r.as)),
    xg: avg((r) => mine(r, r.hsot, r.asot) * 0.3 + Math.max(0, mine(r, r.hs, r.as) - mine(r, r.hsot, r.asot)) * 0.06),
  };
}

/* ------------------- Fallback: dados reais já sincronizados ------------------- */

/**
 * xG estimado a partir das finalizações oficiais da partida (ESPN):
 * chute no alvo ≈ 0,30 xG · chute fora do alvo ≈ 0,06 xG (médias de referência de modelos públicos).
 * É uma APROXIMAÇÃO e é rotulada como "estimado" na resposta.
 */
function xgEstimado(match: MatchRow) {
  const est = (shots: number, onTarget: number) => Math.round((onTarget * 0.3 + Math.max(0, shots - onTarget) * 0.06) * 100) / 100;
  return { xgCasa: est(match.homeShots, match.homeShotsOnTarget), xgFora: est(match.awayShots, match.awayShotsOnTarget) };
}

async function pressaoAtual(match: MatchRow): Promise<Pressao> {
  const since = Math.max(0, match.minute - 15);
  const recent = await db
    .select({ type: matchEvents.type, side: matchEvents.side, minute: matchEvents.minute })
    .from(matchEvents)
    .where(and(eq(matchEvents.matchId, match.id), gte(matchEvents.minute, since)))
    .orderBy(desc(matchEvents.minute));
  const weight: Record<string, number> = { goal: 3, penalty: 3, corner: 1, var: 0.5 };
  let home = 0, away = 0;
  for (const e of recent) {
    const w = weight[e.type] ?? 0;
    if (e.side === "home") home += w; else if (e.side === "away") away += w;
  }
  // Volume ofensivo acumulado como base (finalizações + escanteios), eventos recentes como reforço
  home += match.homeShots + match.homeCorners * 0.5;
  away += match.awayShots + match.awayCorners * 0.5;
  const total = home + away;
  const indice = total > 0 ? Math.round((home / total) * 100) : 50;
  const vermelhoRecente = recent.some((e) => e.type === "red");
  const lado: LadoPressao = indice >= PRESSAO_ALTA ? "casa" : indice <= PRESSAO_BAIXA ? "fora" : "equilibrada";
  const p: Pressao = { lado, indice, vermelhoRecente, descricao: "" };
  p.descricao = descreverPressao(p);
  return p;
}

/* -------------------------------- Serviço -------------------------------- */

export async function getOracleData(matchId: number): Promise<OracleData | { error: string; status: number }> {
  const data = await getMatchById(matchId);
  if (!data) return { error: "Partida não encontrada.", status: 404 };
  const { match } = data;
  if (match.status === "scheduled") return { error: "O Scouter Oracle só analisa partidas em andamento ou encerradas (sem xG antes da bola rolar).", status: 409 };

  const tentativas: Tentativa[] = [];
  let live: LiveStats | null = null;
  let fonteLive = "";
  // 1) Sportmonks → 2) API-Football → 3) Bzzoiro (xG) → 4) estatísticas oficiais já sincronizadas (ESPN)
  live = await statsSportmonks(match, tentativas);
  if (live) fonteLive = "Sportmonks";
  if (!live || live.xgCasa === null) {
    const af = await statsApiFootball(match, tentativas);
    if (af) { live = live ? { ...af, ...Object.fromEntries(Object.entries(live).filter(([, v]) => v !== null)) } as LiveStats : af; fonteLive = fonteLive ? `${fonteLive} + API-Football` : "API-Football"; }
  }
  let probabilidades: { casa: number; empate: number; fora: number } | null = null;
  let fonteProb = "";
  const bz = await bzzoiroEvent(match, tentativas);
  if (bz) {
    if (!live || live.xgCasa === null || !live.escanteios) {
      const bzs = await statsBzzoiro(bz.id, tentativas);
      if (bzs) {
        const base = live ?? { xgCasa: null, xgFora: null, escanteios: null, cartoes: null, finalizacoes: null };
        live = { xgCasa: base.xgCasa ?? bzs.xgCasa, xgFora: base.xgFora ?? bzs.xgFora, escanteios: base.escanteios ?? bzs.escanteios, cartoes: base.cartoes ?? bzs.cartoes, finalizacoes: base.finalizacoes ?? bzs.finalizacoes };
        fonteLive = fonteLive ? `${fonteLive} + Bzzoiro` : "Bzzoiro";
      }
    }
    probabilidades = await probBzzoiro(bz.id, match.kickoff, tentativas);
    if (probabilidades) fonteProb = "Bzzoiro Sports Data (modelo ML)";
  }

  // xG final
  let xgCasa: number, xgFora: number, estimado = false, fonteXg: string;
  if (live && live.xgCasa !== null && live.xgFora !== null) {
    xgCasa = live.xgCasa; xgFora = live.xgFora; fonteXg = `${fonteLive} (xG oficial)`;
  } else {
    const est = xgEstimado(match); xgCasa = est.xgCasa; xgFora = est.xgFora; estimado = true;
    fonteXg = "Estimado pelas finalizações oficiais (ESPN): 0,30 por chute no alvo + 0,06 por chute fora";
    tentativas.push({ fonte: "ESPN (site)", ok: true, detalhe: `xG estimado · ${match.homeShots}/${match.homeShotsOnTarget} x ${match.awayShots}/${match.awayShotsOnTarget} finalizações` });
  }
  if (!probabilidades) {
    try {
      const analysis = await getAnalysis(match, { record: false });
      const mk = analysis.live ?? analysis.pre;
      if (mk) { probabilidades = { casa: mk.home, empate: mk.draw, fora: mk.away }; fonteProb = `Modelo GreenScore ${analysis.version} (${analysis.live ? "ao vivo" : "pré-jogo"})`; }
    } catch { /* sem modelo */ }
  }

  // Comparação ao vivo × média dos últimos 10 (real) → selo
  let [m10h, m10a] = await Promise.all([mediaUltimos10(match.homeId, match.id), mediaUltimos10(match.awayId, match.id)]);
  if (bz && (m10h.n < 3 || m10a.n < 3)) {
    const [bh, ba] = await Promise.all([m10h.n < 3 ? mediaBzzoiro(match.homeName, match.kickoff, tentativas) : null, m10a.n < 3 ? mediaBzzoiro(match.awayName, match.kickoff, tentativas) : null]);
    if (bh) m10h = bh;
    if (ba) m10a = ba;
  }
  const fator = match.status === "finished" ? 1 : Math.max(0.1, Math.min(1, match.minute / 90));
  const ritmo = (v: number, media: number | null) => (media && media > 0 ? Math.round((v / (media * fator)) * 100) / 100 : null);
  const liveCorners = live?.escanteios ?? { casa: match.homeCorners, fora: match.awayCorners };
  const liveCards = live?.cartoes ?? { casa: match.homeCards, fora: match.awayCards };
  const liveShots = live?.finalizacoes ?? { casa: match.homeShots, fora: match.awayShots };
  const fonteStats = live?.escanteios ? fonteLive : "ESPN (estatísticas oficiais da partida)";
  const seloPara = (temAoVivo: boolean, temMedia: boolean): Selo => (temAoVivo && temMedia ? "real" : "demo");
  const metricas: MetricaComparada[] = [
    { chave: "xg", label: "xG", aoVivo: { casa: xgCasa, fora: xgFora }, mediaUltimos10: { casa: m10h.xg, fora: m10a.xg, jogosCasa: m10h.n, jogosFora: m10a.n }, ritmo: { casa: ritmo(xgCasa, m10h.xg), fora: ritmo(xgFora, m10a.xg) }, selo: seloPara(!estimado, m10h.n >= 3 && m10a.n >= 3), fonte: fonteXg },
    { chave: "escanteios", label: "Escanteios", aoVivo: liveCorners, mediaUltimos10: { casa: m10h.escanteios, fora: m10a.escanteios, jogosCasa: m10h.n, jogosFora: m10a.n }, ritmo: { casa: ritmo(liveCorners.casa, m10h.escanteios), fora: ritmo(liveCorners.fora, m10a.escanteios) }, selo: seloPara(match.homeShots + match.awayShots > 0 || Boolean(live?.escanteios), m10h.n >= 3 && m10a.n >= 3), fonte: fonteStats },
    { chave: "cartoes", label: "Cartões", aoVivo: liveCards, mediaUltimos10: { casa: m10h.cartoes, fora: m10a.cartoes, jogosCasa: m10h.n, jogosFora: m10a.n }, ritmo: { casa: ritmo(liveCards.casa, m10h.cartoes), fora: ritmo(liveCards.fora, m10a.cartoes) }, selo: seloPara(match.homeShots + match.awayShots > 0 || Boolean(live?.cartoes), m10h.n >= 3 && m10a.n >= 3), fonte: fonteStats },
    { chave: "finalizacoes", label: "Finalizações", aoVivo: liveShots, mediaUltimos10: { casa: m10h.finalizacoes, fora: m10a.finalizacoes, jogosCasa: m10h.n, jogosFora: m10a.n }, ritmo: { casa: ritmo(liveShots.casa, m10h.finalizacoes), fora: ritmo(liveShots.fora, m10a.finalizacoes) }, selo: seloPara(match.homeShots + match.awayShots > 0 || Boolean(live?.finalizacoes), m10h.n >= 3 && m10a.n >= 3), fonte: fonteStats },
  ];
  const seloGeral: Selo = metricas.every((m) => m.selo === "real") ? "real" : "demo";

  const pressao = await pressaoAtual(match);
  // reforça a leitura de pressão com o ritmo relativo (acima da média habitual = pressão)
  const rc = metricas.find((m) => m.chave === "finalizacoes")?.ritmo;
  if (rc?.casa !== null && rc?.casa !== undefined && rc.fora !== null && rc.fora !== undefined && Math.abs(rc.casa - rc.fora) >= 0.5) {
    const ajuste = rc.casa > rc.fora ? 8 : -8;
    pressao.indice = Math.max(0, Math.min(100, pressao.indice + ajuste));
    pressao.lado = pressao.indice >= PRESSAO_ALTA ? "casa" : pressao.indice <= PRESSAO_BAIXA ? "fora" : "equilibrada";
    pressao.descricao = descreverPressao(pressao);
  }
  const { veredito, explicacao } = calcularVeredito(xgCasa, xgFora, pressao);
  const compl = metricas.filter((m) => m.ritmo.casa !== null && m.chave !== "xg").map((m) => `${m.label}: ${m.aoVivo.casa}-${m.aoVivo.fora} (ritmo ${m.ritmo.casa}× / ${m.ritmo.fora}× da média dos últimos ${m.mediaUltimos10.jogosCasa}/${m.mediaUltimos10.jogosFora} jogos)`).join("; ");
  return {
    matchId: match.id,
    xgCasa, xgFora,
    pressao: pressao.descricao,
    veredito,
    explicacao: `${explicacao}${compl ? ` ${compl}.` : ""}${estimado ? " (xG estimado a partir das finalizações oficiais — ative Sportmonks ou API-Football para xG real.)" : ""}`,
    selo: seloGeral,
    metricas,
    detalhes: {
      pressaoIndice: pressao.indice, pressaoLado: pressao.lado, vermelhoRecente: pressao.vermelhoRecente,
      minuto: match.minute, placar: `${match.homeScore}-${match.awayScore}`, status: match.status,
      fonteXg, fonteProbabilidades: fonteProb || "indisponível", xgEstimado: estimado, probabilidades, fontesTentadas: tentativas,
      atualizadoEm: new Date(match.updatedAt).toISOString(),
    },
  };
}

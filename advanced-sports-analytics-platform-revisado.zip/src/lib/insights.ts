import type { MatchRow } from "@/lib/data";

export type LiveInsight = {
  id: number;
  category: string;
  title: string;
  body: string;
  market: string;
  confidence: number;
  odds: string;
  source: string;
  matchId: number | null;
  matchLabel?: string;
  kickoff?: Date;
};

type TeamAvg = { avgCorners: number; avgCards: number; avgFouls: number; avgOffsides: number; over25Rate: number; bttsRate: number; statsSample: number; form: string };

function pace(current: number, minute: number) {
  if (!minute) return current;
  return Math.round((current / minute) * 90 * 10) / 10;
}

function formScore(form: string) {
  return form.split("").reduce((sum, letter) => sum + (letter === "V" ? 3 : letter === "E" ? 1 : 0), 0);
}

/**
 * Gera análises a partir dos números reais da partida (ao vivo/encerrada) e das
 * médias reais acumuladas dos times. Nada aqui é inventado: toda frase cita o dado-base.
 */
export function buildMatchInsights(match: MatchRow, home?: TeamAvg | null, away?: TeamAvg | null): LiveInsight[] {
  const out: LiveInsight[] = [];
  const label = `${match.homeShort} x ${match.awayShort}`;
  const base = { matchId: match.id, matchLabel: label, kickoff: match.kickoff, source: "Dados oficiais ESPN · cálculo GreenScore" };
  let id = match.id * 100;

  if (match.status === "live" && match.minute >= 10) {
    const corners = match.homeCorners + match.awayCorners;
    const cornerPace = pace(corners, match.minute);
    out.push({
      ...base,
      id: id++,
      category: "escanteios",
      title: `Ritmo de ${cornerPace} escanteios projetados`,
      body: `${corners} escanteio(s) em ${match.minute} minutos (${match.homeShort} ${match.homeCorners} · ${match.awayShort} ${match.awayCorners}). Mantido o ritmo, a projeção para 90' é de ${cornerPace}.`,
      market: cornerPace >= 10 ? "Mais de 9.5 Escanteios" : cornerPace <= 7 ? "Menos de 9.5 Escanteios" : "Entre 8 e 10 Escanteios",
      confidence: Math.min(90, 55 + Math.round(match.minute / 3)),
      odds: "",
    });
    const cards = match.homeCards + match.awayCards;
    const fouls = match.homeFouls + match.awayFouls;
    out.push({
      ...base,
      id: id++,
      category: "cartoes",
      title: `${fouls} faltas e ${cards} cartão(ões) até agora`,
      body: `${match.homeShort} cometeu ${match.homeFouls} falta(s) e ${match.awayShort} ${match.awayFouls}. Projeção de faltas para 90': ${pace(fouls, match.minute)}. Jogo ${fouls / Math.max(1, match.minute) > 0.3 ? "truncado, com tendência de mais cartões" : "limpo, com poucos cartões"}.`,
      market: pace(cards, match.minute) >= 4.5 ? "Mais de 4.5 Cartões" : "Menos de 4.5 Cartões",
      confidence: Math.min(85, 50 + Math.round(match.minute / 3)),
      odds: "",
    });
    const shots = match.homeShots + match.awayShots;
    const goals = match.homeScore + match.awayScore;
    out.push({
      ...base,
      id: id++,
      category: "gols",
      title: `${shots} finalizações (${match.homeShotsOnTarget + match.awayShotsOnTarget} no alvo) para ${goals} gol(s)`,
      body: `Posse ${match.homePossession}% x ${match.awayPossession}%. ${match.homeShort} finalizou ${match.homeShots} (${match.homeShotsOnTarget} no alvo) e ${match.awayShort} ${match.awayShots} (${match.awayShotsOnTarget} no alvo). Projeção de finalizações: ${pace(shots, match.minute)}.`,
      market: goals + pace(shots, match.minute) / 12 > 2.5 ? "Mais de 2.5 Gols" : "Menos de 2.5 Gols",
      confidence: Math.min(80, 45 + Math.round(match.minute / 3)),
      odds: "",
    });
    const offsides = match.homeOffsides + match.awayOffsides;
    if (offsides > 0) {
      out.push({
        ...base,
        id: id++,
        category: "impedimentos",
        title: `${offsides} impedimento(s) marcados`,
        body: `${match.homeShort} ${match.homeOffsides} · ${match.awayShort} ${match.awayOffsides}. Linha defensiva ${offsides >= 3 ? "alta e eficiente" : "conservadora"} — projeção de ${pace(offsides, match.minute)} impedimentos no jogo.`,
        market: pace(offsides, match.minute) >= 3.5 ? "Mais de 3.5 Impedimentos" : "Menos de 3.5 Impedimentos",
        confidence: 60,
        odds: "",
      });
    }
  }

  if (match.status === "scheduled") {
    if (home && away && (home.statsSample > 0 || away.statsSample > 0)) {
      const corners = (home.avgCorners + away.avgCorners) || 0;
      if (corners > 0) {
        out.push({
          ...base,
          id: id++,
          category: "escanteios",
          title: `Média combinada de ${corners} escanteios`,
          body: `${match.homeShort} cobra em média ${home.avgCorners} escanteio(s) por jogo e ${match.awayShort} ${away.avgCorners} (amostra: ${home.statsSample + away.statsSample} partidas encerradas sincronizadas).`,
          market: corners >= 10 ? "Mais de 9.5 Escanteios" : "Menos de 9.5 Escanteios",
          confidence: Math.min(78, 50 + (home.statsSample + away.statsSample) * 4),
          odds: "",
        });
      }
      const cards = home.avgCards + away.avgCards;
      const fouls = home.avgFouls + away.avgFouls;
      if (fouls > 0) {
        out.push({
          ...base,
          id: id++,
          category: "faltas",
          title: `${fouls} faltas e ${cards} cartões por jogo (média)`,
          body: `${match.homeShort}: ${home.avgFouls} faltas / ${home.avgCards} cartões · ${match.awayShort}: ${away.avgFouls} faltas / ${away.avgCards} cartões.`,
          market: cards >= 4.5 ? "Mais de 4.5 Cartões" : "Menos de 4.5 Cartões",
          confidence: Math.min(72, 48 + (home.statsSample + away.statsSample) * 4),
          odds: "",
        });
      }
      const over = Math.round((home.over25Rate + away.over25Rate) / 2);
      out.push({
        ...base,
        id: id++,
        category: "gols",
        title: `${over}% dos jogos recentes passaram de 2,5 gols`,
        body: `${match.homeShort}: ${home.over25Rate}% over 2,5 e ${home.bttsRate}% ambas marcam · ${match.awayShort}: ${away.over25Rate}% over e ${away.bttsRate}% ambas marcam.`,
        market: over >= 55 ? "Mais de 2.5 Gols" : "Menos de 2.5 Gols",
        confidence: Math.min(70, 45 + (home.statsSample + away.statsSample) * 3),
        odds: "",
      });
    }
    if (home?.form && away?.form) {
      const hs = formScore(home.form);
      const as = formScore(away.form);
      out.push({
        ...base,
        id: id++,
        category: "mercados",
        title: `Forma recente: ${match.homeShort} ${home.form} · ${match.awayShort} ${away.form}`,
        body: `${match.homeShort} somou ${hs} ponto(s) nos últimos ${home.form.length} jogos; ${match.awayShort} somou ${as}. ${match.oddsDetails ? `Linha das casas: ${match.oddsDetails}${match.overUnder ? ` · total ${match.overUnder}` : ""}.` : ""}`,
        market: hs - as >= 4 ? `Vitória ${match.homeShort}` : as - hs >= 4 ? `Vitória ${match.awayShort}` : "Dupla chance / empate",
        confidence: 50 + Math.min(25, Math.abs(hs - as) * 3),
        odds: match.oddsDetails || "—",
      });
    }
  }

  if (match.status === "finished") {
    out.push({
      ...base,
      id: id++,
      category: "mercados",
      title: `Resumo: ${match.homeShort} ${match.homeScore} x ${match.awayScore} ${match.awayShort}`,
      body: `${match.homeCorners + match.awayCorners} escanteios · ${match.homeFouls + match.awayFouls} faltas · ${match.homeCards + match.awayCards} cartões · ${match.homeOffsides + match.awayOffsides} impedimentos · ${match.homeShots + match.awayShots} finalizações · posse ${match.homePossession}%/${match.awayPossession}%.`,
      market: match.homeScore + match.awayScore > 2 ? "Mais de 2.5 Gols ✓" : "Menos de 2.5 Gols ✓",
      confidence: 100,
      odds: match.oddsDetails || "—",
    });
  }
  return out;
}

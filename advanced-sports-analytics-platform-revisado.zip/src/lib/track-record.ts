import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { matches, predictions, teams } from "@/db/schema";

/* ====================================================================== */
/*  Track Record — lê as previsões já registradas/liquidadas (tabela       */
/*  predictions) sem alterar o motor. "Green" = o favorito do modelo (1X2) */
/*  venceu; "Red" = não venceu; "Pendente" = jogo ainda não terminou.      */
/* ====================================================================== */

export type TrackItem = { id: number; matchId: number | null; createdAt: Date; home: string; away: string; score: string; pick: "home" | "draw" | "away"; pickLabel: string; prob: number; result: "green" | "red" | "pending"; brier: string; league: string };

export async function getTrackRecord(days = 30) {
  const since = new Date(Date.now() - days * 86400000);
  const rows = await db
    .select({ p: predictions, home: matches.homeTeamId, away: matches.awayTeamId, hs: matches.homeScore, as: matches.awayScore, status: matches.status, leagueCode: matches.leagueCode })
    .from(predictions)
    .leftJoin(matches, eq(matches.id, predictions.matchId))
    .where(and(eq(predictions.kind, "pre"), gte(predictions.createdAt, since)))
    .orderBy(desc(predictions.createdAt));
  const teamIds = [...new Set(rows.flatMap((r) => [r.home, r.away]).filter((v): v is number => typeof v === "number"))];
  const names = new Map<number, string>();
  if (teamIds.length) for (const t of await db.select({ id: teams.id, name: teams.name }).from(teams)) names.set(t.id, t.name);
  // uma previsão por partida (a mais recente antes do jogo)
  const seen = new Set<number>();
  const items: TrackItem[] = [];
  for (const r of rows) {
    if (r.p.matchId && seen.has(r.p.matchId)) continue;
    if (r.p.matchId) seen.add(r.p.matchId);
    const ph = Number(r.p.probs.home ?? 0), pd = Number(r.p.probs.draw ?? 0), pa = Number(r.p.probs.away ?? 0);
    const pick: TrackItem["pick"] = ph >= pd && ph >= pa ? "home" : pa >= pd ? "away" : "draw";
    const prob = pick === "home" ? ph : pick === "away" ? pa : pd;
    let result: TrackItem["result"] = "pending";
    if (r.status === "finished" && r.hs !== null && r.as !== null) {
      const actual: TrackItem["pick"] = r.hs > r.as ? "home" : r.hs === r.as ? "draw" : "away";
      result = actual === pick ? "green" : "red";
    }
    items.push({ id: r.p.id, matchId: r.p.matchId, createdAt: r.p.createdAt, home: names.get(r.home ?? -1) ?? "Mandante", away: names.get(r.away ?? -1) ?? "Visitante", score: r.status === "finished" ? `${r.hs}-${r.as}` : "—", pick, pickLabel: pick === "home" ? names.get(r.home ?? -1) ?? "Casa" : pick === "away" ? names.get(r.away ?? -1) ?? "Fora" : "Empate", prob, result, brier: r.p.brier, league: r.leagueCode ?? r.p.leagueCode });
  }
  const greens = items.filter((i) => i.result === "green").length;
  const reds = items.filter((i) => i.result === "red").length;
  const pending = items.filter((i) => i.result === "pending").length;
  const settled = greens + reds;
  // série diária para o gráfico de evolução (acumulado)
  const byDay = new Map<string, { g: number; r: number }>();
  for (const i of items.filter((x) => x.result !== "pending")) { const k = i.createdAt.toISOString().slice(0, 10); const d = byDay.get(k) ?? { g: 0, r: 0 }; if (i.result === "green") d.g++; else d.r++; byDay.set(k, d); }
  const serie = [...byDay.entries()].sort(([a], [b]) => a.localeCompare(b)).reduce<{ dia: string; greens: number; reds: number; taxa: number }[]>((acc, [dia, v]) => { const prev = acc[acc.length - 1]; const g = (prev?.greens ?? 0) + v.g, r = (prev?.reds ?? 0) + v.r; acc.push({ dia: dia.slice(5).split("-").reverse().join("/"), greens: g, reds: r, taxa: Math.round((g / Math.max(1, g + r)) * 100) }); return acc; }, []);
  const byLeague = Object.entries(items.filter((i) => i.result !== "pending").reduce<Record<string, { g: number; r: number }>>((acc, i) => { acc[i.league] ??= { g: 0, r: 0 }; if (i.result === "green") acc[i.league].g++; else acc[i.league].r++; return acc; }, {})).map(([league, v]) => ({ league, ...v, taxa: Math.round((v.g / Math.max(1, v.g + v.r)) * 100) })).sort((a, b) => b.g + b.r - (a.g + a.r));
  return { days, greens, reds, pending, settled, taxa: settled ? Math.round((greens / settled) * 100) : 0, items: items.slice(0, 60), serie, byLeague, avgProbGreens: greens ? items.filter((i) => i.result === "green").reduce((s, i) => s + i.prob, 0) / greens : 0 };
}

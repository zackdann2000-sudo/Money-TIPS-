import { ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { teams } from "@/db/schema";
import { getMatches, type MatchRow } from "@/lib/data";
import { calcularOportunidades, type JogoStats, type Oportunidade } from "@/lib/opportunities";
import { dayKey, formatKickoff } from "@/lib/utils";

/* ====================================================================== */
/*  MONEY TIPS — Pick do Dia (estilo GreenScorer)                          */
/*  Reaproveita o motor de Oportunidades (últimos 10 jogos reais) e        */
/*  ranqueia: maior taxa de acerto → desempate pela maior odd estimada.    */
/* ====================================================================== */

export type PickJogo = { matchId: number; timeCasa: string; logoCasa: string; timeFora: string; logoFora: string; horario: string; liga: string; status: string };
export type PickHistorico = { valor: number; adversario: string; logoAdversario: string; emCasa: boolean; data: string; placar: string };

export type Pick = {
  jogo: PickJogo;
  analiseTexto: string;
  oportunidade: {
    time: string;
    logoTime: string;
    periodo: Oportunidade["periodo"];
    mercado: string;
    linha: string;
    acertos: number;
    totalJogos: number;
    media: number;
    oddEstimada: number;
    historicoGols: number[];
    historico: PickHistorico[];
    fonte: string;
  };
  rankingScore: number;
};

export type PickDoDia = { data: string; pick: Pick | null; melhores: Pick[]; jogosAnalisados: number; aviso?: string };

const MERCADOS_PICK = new Set(["Gols", "Escanteios", "Cartões"]);
const MIN_JOGOS = 7; // amostra mínima para um mercado entrar no ranking

const LABEL: Record<string, string> = { Gols: "Gols Marcados", Escanteios: "Escanteios", Cartões: "Cartões" };
const fmtLinha = (l: number) => `+${l.toFixed(1)}`;

const cache = new Map<string, { at: number; value: PickDoDia }>();
const TTL = 20 * 60 * 1000;
const logoCache = new Map<string, string>();

async function logoFor(name: string) {
  const key = name.toLowerCase();
  if (logoCache.has(key)) return logoCache.get(key)!;
  const short = name.split(" ").filter((w) => w.length > 3)[0] ?? name;
  const rows = await db.select({ name: teams.name, logo: teams.logo }).from(teams).where(or(ilike(teams.name, `%${name}%`), ilike(teams.name, `%${short}%`))).limit(5);
  const exact = rows.find((r) => r.name.toLowerCase() === key) ?? rows[0];
  const logo = exact?.logo ?? "";
  logoCache.set(key, logo);
  return logo;
}

function valorDoJogo(j: JogoStats, mercado: string, periodo: string): number | null {
  if (mercado === "Gols") return periodo === "Jogo todo" ? j.golsFT : periodo === "1º Tempo" ? j.golsHT : j.golsHT === null ? null : j.golsFT - j.golsHT;
  if (mercado === "Escanteios") return j.escanteios;
  if (mercado === "Cartões") return j.cartoes;
  return null;
}

function texto(match: MatchRow, time: string, isCasa: boolean, o: Oportunidade, hist: JogoStats[]) {
  const mando = isCasa ? "em casa" : "fora de casa";
  const ultimos = hist.slice(0, 3).map((h) => `${h.emCasa ? "vs" : "@"} ${h.adversario} (${h.placar})`).join(", ");
  const base = `${time} chega para enfrentar ${isCasa ? match.awayName : match.homeName} ${mando} pela ${match.leagueName ?? "competição"}.`;
  if (o.mercado === "Gols") {
    const where = o.periodo === "1º Tempo" ? "no primeiro tempo" : o.periodo === "2º Tempo" ? "no segundo tempo" : "no jogo";
    return `${base} O ataque tem sido consistente: marcou pelo menos ${Math.ceil(o.linha)} gol ${where} em ${o.acertos} dos últimos ${o.totalJogos} jogos (média ${o.media.toFixed(2)}). Últimos resultados: ${ultimos}.`;
  }
  if (o.mercado === "Escanteios") return `${base} O time pressiona pelos lados e acumula escanteios: superou ${o.linha} em ${o.acertos} de ${o.totalJogos} partidas (média ${o.media.toFixed(1)} por jogo). Últimos resultados: ${ultimos}.`;
  return `${base} O padrão disciplinar é recorrente: recebeu mais de ${o.linha} cartões em ${o.acertos} dos últimos ${o.totalJogos} jogos (média ${o.media.toFixed(1)}). Últimos resultados: ${ultimos}.`;
}

/** Motor de seleção: analisa todos os jogos do dia e devolve o melhor pick (e o ranking completo). */
export async function getPickDoDia(data = dayKey(new Date())): Promise<PickDoDia> {
  const hit = cache.get(data);
  if (hit && Date.now() - hit.at < TTL) return hit.value;

  const all = (await getMatches()).filter((m) => m.source === "espn" && dayKey(m.kickoff) === data);
  const candidatos: Pick[] = [];

  await Promise.all(
    all.slice(0, 40).map(async (match) => {
      const antes = new Date(match.kickoff); // só histórico anterior ao jogo (sem vazar resultado)
      const sides: { id: number; nome: string; logo: string; isCasa: boolean }[] = [
        { id: match.homeId, nome: match.homeName, logo: match.homeLogo, isCasa: true },
        { id: match.awayId, nome: match.awayName, logo: match.awayLogo, isCasa: false },
      ];
      for (const side of sides) {
        const r = await calcularOportunidades(side.id, side.isCasa, antes).catch(() => null);
        if (!r || r.jogosAnalisados < MIN_JOGOS) continue;
        for (const o of r.todosMercados) {
          if (!o.disponivel || !MERCADOS_PICK.has(o.mercado) || o.acertos < 7) continue;
          const histVals = r.jogosDetalhados.map((j) => valorDoJogo(j, o.mercado, o.periodo));
          if (histVals.some((v) => v === null)) continue;
          const historico: PickHistorico[] = await Promise.all(
            r.jogosDetalhados.map(async (j, i) => ({ valor: histVals[i] as number, adversario: j.adversario, logoAdversario: await logoFor(j.adversario), emCasa: j.emCasa, data: j.data, placar: j.placar })),
          );
          candidatos.push({
            jogo: { matchId: match.id, timeCasa: match.homeName, logoCasa: match.homeLogo, timeFora: match.awayName, logoFora: match.awayLogo, horario: formatKickoff(match.kickoff), liga: match.leagueName ?? "", status: match.status },
            analiseTexto: texto(match, side.nome, side.isCasa, o, r.jogosDetalhados),
            oportunidade: {
              time: side.nome, logoTime: side.logo, periodo: o.periodo, mercado: LABEL[o.mercado] ?? o.mercado, linha: fmtLinha(o.linha),
              acertos: o.acertos, totalJogos: o.totalJogos, media: o.media, oddEstimada: o.oddEstimada,
              historicoGols: histVals as number[], historico, fonte: r.fonte,
            },
            // ranking: taxa de acerto (desc) → odd estimada (desc)
            rankingScore: (o.acertos / o.totalJogos) * 1000 + Math.min(999, o.oddEstimada * 100) / 1000,
          });
        }
      }
    }),
  );

  candidatos.sort((a, b) => {
    const ta = a.oportunidade.acertos / a.oportunidade.totalJogos, tb = b.oportunidade.acertos / b.oportunidade.totalJogos;
    if (tb !== ta) return tb - ta;
    return b.oportunidade.oddEstimada - a.oportunidade.oddEstimada;
  });
  // "Melhores do dia": no máximo 1 por jogo, top 8
  const vistos = new Set<number>();
  const melhores = candidatos.filter((c) => (vistos.has(c.jogo.matchId) ? false : (vistos.add(c.jogo.matchId), true))).slice(0, 8);
  const value: PickDoDia = {
    data,
    pick: candidatos[0] ?? null,
    melhores,
    jogosAnalisados: all.length,
    aviso: all.length === 0 ? "Nenhum jogo nas competições monitoradas nesta data." : candidatos.length === 0 ? "Nenhum mercado atingiu 7 acertos em 10 jogos para os times do dia." : undefined,
  };
  cache.set(data, { at: Date.now(), value });
  return value;
}

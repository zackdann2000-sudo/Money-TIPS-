import { and, desc, eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { matches, teams } from "@/db/schema";
import { callIntegration, getIntegration } from "@/lib/providers";

/* ====================================================================== */
/*  Módulo OPORTUNIDADES (estilo GreenScorer)                              */
/*  Analisa os últimos 10 jogos de um time e destaca mercados com ≥7/10.   */
/*  Fontes (ordem): Sportmonks → Bzzoiro → jogos oficiais já no site.      */
/*  Nenhum valor é simulado: se a fonte não tem o dado, o mercado é        */
/*  marcado como indisponível (não entra no cálculo).                      */
/* ====================================================================== */

export type Oportunidade = {
  mercado: "Gols" | "Faltas" | "Chutes no Gol" | "Escanteios" | "Cartões";
  periodo: "Jogo todo" | "1º Tempo" | "2º Tempo";
  linha: number;
  media: number;
  acertos: number;
  totalJogos: number;
  oddEstimada: number;
  historico: number[]; // valor do time em cada jogo (mais recente primeiro)
};

export type OportunidadesResultado = {
  timeId: number;
  time: string;
  isMandante: boolean;
  fonte: "sportmonks" | "bzzoiro" | "espn" | "none";
  jogosAnalisados: number;
  jogos: { data: string; adversario: string; emCasa: boolean; placar: string }[];
  jogosDetalhados: JogoStats[];
  oportunidades: Oportunidade[]; // apenas ≥ 7/10
  todosMercados: (Oportunidade & { disponivel: boolean; motivo?: string })[];
  aviso?: string;
};

const MARGEM = 0.06;
export const LINHAS: { mercado: Oportunidade["mercado"]; periodo: Oportunidade["periodo"]; linha: number }[] = [
  { mercado: "Gols", periodo: "Jogo todo", linha: 0.5 },
  { mercado: "Gols", periodo: "1º Tempo", linha: 0.5 },
  { mercado: "Gols", periodo: "2º Tempo", linha: 0.5 },
  { mercado: "Faltas", periodo: "Jogo todo", linha: 10.5 },
  { mercado: "Chutes no Gol", periodo: "1º Tempo", linha: 2.5 },
  { mercado: "Escanteios", periodo: "Jogo todo", linha: 8.5 },
  { mercado: "Escanteios", periodo: "Jogo todo", linha: 4.5 },
  { mercado: "Cartões", periodo: "Jogo todo", linha: 1.5 },
  { mercado: "Gols", periodo: "Jogo todo", linha: 1.5 },
];

/** Odd = 1 / ((acertos/10) − 0,06), arredondada a 2 casas. Com 10/10 → 1,06. */
export function calcularOdd(acertos: number, total = 10) {
  const p = acertos / total - MARGEM;
  if (p <= 0) return null;
  return Math.round((1 / p) * 100) / 100;
}

/** Estatísticas de UM jogo, na perspectiva do time analisado. null = fonte não forneceu. */
export type JogoStats = {
  data: string;
  adversario: string;
  emCasa: boolean;
  golsFT: number;
  golsHT: number | null;
  faltas: number | null;
  chutesNoGolHT: number | null;
  escanteios: number | null;
  cartoes: number | null;
  golsSofridosFT: number;
  golsSofridosHT: number | null;
  finalizacoes: number | null;
  impedimentos: number | null;
  chutesNoGol: number | null; // jogo todo
  placar: string;
};

/** Núcleo puro do motor: recebe os jogos (já normalizados) e devolve os mercados. */
export function calcularMercados(jogos: JogoStats[]) {
  const total = jogos.length;
  const avaliar = (valores: (number | null)[], linha: number) => {
    const validos = valores.filter((v): v is number => v !== null);
    const disponivel = validos.length === total && total > 0;
    const acertos = validos.filter((v) => v > linha).length;
    const media = validos.length ? Math.round((validos.reduce((a, b) => a + b, 0) / validos.length) * 100) / 100 : 0;
    return { disponivel, acertos, media, historico: validos, faltando: total - validos.length };
  };
  const extrair = (mercado: Oportunidade["mercado"], periodo: Oportunidade["periodo"]) =>
    jogos.map((j) => {
      if (mercado === "Gols") return periodo === "Jogo todo" ? j.golsFT : periodo === "1º Tempo" ? j.golsHT : j.golsHT === null ? null : j.golsFT - j.golsHT;
      if (mercado === "Faltas") return j.faltas;
      if (mercado === "Chutes no Gol") return j.chutesNoGolHT;
      if (mercado === "Cartões") return j.cartoes;
      return j.escanteios;
    });
  return LINHAS.map((l) => {
    const r = avaliar(extrair(l.mercado, l.periodo), l.linha);
    return {
      mercado: l.mercado, periodo: l.periodo, linha: l.linha,
      media: r.media, acertos: r.acertos, totalJogos: total,
      oddEstimada: calcularOdd(r.acertos, total) ?? 0,
      historico: r.historico,
      disponivel: r.disponivel,
      motivo: r.disponivel ? undefined : total === 0 ? "sem jogos na fonte" : `fonte sem este dado em ${r.faltando} de ${total} jogos`,
    };
  });
}

/* ------------------------------ util --------------------------------- */
const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null);
const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\b(fc|cf|sc|ec|afc|club|de|do|da|futebol|clube)\b/g, "").replace(/[^a-z0-9]+/g, " ").trim();
function sameTeam(a: string, b: string) {
  const x = norm(a), y = norm(b);
  if (!x || !y) return false;
  if (x === y || x.includes(y) || y.includes(x)) return true;
  const xs = new Set(x.split(" ").filter((w) => w.length > 2));
  return y.split(" ").filter((w) => w.length > 2).some((w) => xs.has(w));
}
/** Correspondência estrita (usada em buscas por nome na fonte): exige o nome inteiro, não só uma palavra em comum. */
function strictTeam(a: string, b: string) {
  const x = norm(a), y = norm(b);
  if (!x || !y) return false;
  if (x === y) return true;
  const longer = x.length >= y.length ? x : y, shorter = x.length >= y.length ? y : x;
  return shorter.length >= 5 && (longer === shorter || longer.startsWith(`${shorter} `) || longer.endsWith(` ${shorter}`) || longer.includes(` ${shorter} `));
}
const iso = (d: Date) => d.toISOString().slice(0, 10);
const cache = new Map<string, { at: number; value: OportunidadesResultado }>();
const TTL = 30 * 60 * 1000;

/* ---------------------------- Sportmonks ----------------------------- */

async function viaSportmonks(teamName: string, before: Date): Promise<JogoStats[] | null> {
  if (!(await getIntegration("sportmonks"))) return null;
  const search = await callIntegration("sportmonks", `/teams/search/${encodeURIComponent(teamName)}`);
  const found = search.ok ? ((search.data as { data?: { id: number; name: string }[] }).data ?? []).find((t) => strictTeam(t.name, teamName)) : null;
  if (!found) return null;
  const from = iso(new Date(before.getTime() - 180 * 86400000)), to = iso(new Date(before.getTime() - 1));
  const fx = await callIntegration("sportmonks", `/fixtures/between/${from}/${to}/${found.id}`, { include: "scores;participants;state;statistics.type", per_page: "25", order: "desc" });
  if (!fx.ok) return null;
  type F = { starting_at: string; state?: { developer_name?: string }; participants?: { id: number; name: string; meta?: { location?: string } }[]; scores?: { description?: string; score?: { participant?: string; goals?: number } }[]; statistics?: { participant_id: number; type?: { developer_name?: string; code?: string }; data?: { value?: number } }[] };
  const list = ((fx.data as { data?: F[] }).data ?? []).filter((f) => ["FT", "AET", "FT_PEN"].includes(f.state?.developer_name ?? "")).sort((a, b) => b.starting_at.localeCompare(a.starting_at)).slice(0, 20);
  if (!list.length) return null;
  return list.map((f) => {
    const me = f.participants?.find((p) => p.id === found.id);
    const side = me?.meta?.location === "home" ? "home" : "away";
    const opp = f.participants?.find((p) => p.id !== found.id);
    const sc = (desc: string, part: string) => num(f.scores?.find((s) => s.description === desc && s.score?.participant === part)?.score?.goals);
    const stat = (re: RegExp) => num(f.statistics?.find((s) => s.participant_id === found.id && re.test((s.type?.developer_name ?? s.type?.code ?? "").toLowerCase()))?.data?.value);
    const ft = sc("CURRENT", side) ?? 0, oppFt = sc("CURRENT", side === "home" ? "away" : "home") ?? 0;
    return {
      data: f.starting_at.slice(0, 10), adversario: opp?.name ?? "Adversário", emCasa: side === "home",
      golsFT: ft, golsHT: sc("1ST_HALF", side), faltas: stat(/fouls/), chutesNoGolHT: null /* plano Sportmonks não detalha 1º tempo */, escanteios: stat(/corners/), cartoes: stat(/yellowcards/),
      golsSofridosFT: oppFt, golsSofridosHT: sc("1ST_HALF", side === "home" ? "away" : "home"), finalizacoes: stat(/shots[-_]?total/), impedimentos: stat(/offsides/), chutesNoGol: stat(/shots[-_]?on[-_]?target/),
      placar: side === "home" ? `${ft}-${oppFt}` : `${oppFt}-${ft}`,
    };
  });
}

/* ------------------------------ Bzzoiro ------------------------------ */

async function viaBzzoiro(teamName: string, before: Date): Promise<{ jogos: JogoStats[]; teamId: number } | null> {
  if (!(await getIntegration("bzzoiro"))) return null;
  // localiza o team_id pelo nome em eventos recentes (a busca de times exige id)
  const from = iso(new Date(before.getTime() - 150 * 86400000)), to = iso(new Date(before.getTime() - 1));
  const search = await callIntegration("bzzoiro", "/teams/", { search: teamName, page_size: "10" });
  type T = { id: number; name: string };
  let teamId = search.ok ? ((search.data as { results?: T[] }).results ?? []).find((t) => strictTeam(t.name, teamName))?.id : undefined;
  if (!teamId) {
    const ev = await callIntegration("bzzoiro", "/events/", { date_from: iso(new Date(before.getTime() - 20 * 86400000)), date_to: iso(new Date(before.getTime() + 2 * 86400000)), page_size: "200" });
    type E = { home_team: string; away_team: string; home_team_id: number; away_team_id: number };
    const evs = ev.ok ? ((ev.data as { results?: E[] }).results ?? []) : [];
    for (const e of evs) {
      if (strictTeam(e.home_team, teamName)) { teamId = e.home_team_id; break; }
      if (strictTeam(e.away_team, teamName)) { teamId = e.away_team_id; break; }
    }
    if (!teamId) for (const e of evs) {
      if (sameTeam(e.home_team, teamName)) { teamId = e.home_team_id; break; }
      if (sameTeam(e.away_team, teamName)) { teamId = e.away_team_id; break; }
    }
  }
  if (!teamId) return null;
  const list = await callIntegration("bzzoiro", "/events/", { team_id: String(teamId), date_from: from, date_to: to, status: "finished", page_size: "40" });
  if (!list.ok) return null;
  type Ev = { id: number; event_date: string; home_team: string; away_team: string; home_team_id: number; status: string; home_score: number | null; away_score: number | null; home_score_ht: number | null; away_score_ht: number | null };
  const events = ((list.data as { results?: Ev[] }).results ?? []).filter((e) => /finish/i.test(e.status) && e.home_score !== null).sort((a, b) => b.event_date.localeCompare(a.event_date)).slice(0, 20);
  if (!events.length) return null;
  const jogos = await Promise.all(events.map(async (e): Promise<JogoStats> => {
    const emCasa = e.home_team_id === teamId;
    const st = await callIntegration("bzzoiro", `/events/${e.id}/stats/`);
    const d = st.ok ? (st.data as { stats?: { home?: Record<string, unknown>; away?: Record<string, unknown> }; shotmap?: { min?: number; home?: boolean; type?: string; added?: number }[] }) : null;
    const mine = d?.stats?.[emCasa ? "home" : "away"];
    // Chutes no gol do 1º tempo: shotmap (gol + defesa + trave = no alvo) até o minuto 45 inclusive acréscimos
    let sotHT: number | null = null;
    if (d?.shotmap && d.shotmap.length) {
      sotHT = d.shotmap.filter((s) => s.home === emCasa && (s.min ?? 99) <= 45 && ["goal", "save", "post", "on_target", "saved"].includes(String(s.type))).length;
    }
    const ft = emCasa ? e.home_score! : e.away_score!;
    const ht = emCasa ? e.home_score_ht : e.away_score_ht;
    return {
      data: e.event_date.slice(0, 10), adversario: emCasa ? e.away_team : e.home_team, emCasa,
      golsFT: ft, golsHT: num(ht), faltas: num(mine?.fouls), chutesNoGolHT: sotHT, escanteios: num(mine?.corner_kicks), cartoes: mine ? (num(mine.yellow_cards) ?? 0) + (num(mine.red_cards) ?? 0) : null,
      golsSofridosFT: emCasa ? e.away_score! : e.home_score!, golsSofridosHT: num(emCasa ? e.away_score_ht : e.home_score_ht), finalizacoes: num(mine?.total_shots), impedimentos: num(mine?.offsides), chutesNoGol: num(mine?.shots_on_target),
      placar: `${e.home_score}-${e.away_score}`,
    };
  }));
  return { jogos, teamId };
}

/* ------------------------- ESPN (já no site) -------------------------- */

async function viaEspn(teamId: number, before: Date): Promise<JogoStats[]> {
  const rows = await db
    .select({ kickoff: matches.kickoff, home: matches.homeTeamId, hs: matches.homeScore, as: matches.awayScore, hf: matches.homeFouls, af: matches.awayFouls, hc: matches.homeCorners, ac: matches.awayCorners, hcd: matches.homeCards, acd: matches.awayCards, hsh: matches.homeShots, ash: matches.awayShots, ho: matches.homeOffsides, ao: matches.awayOffsides, hsot: matches.homeShotsOnTarget, asot: matches.awayShotsOnTarget, hname: sql<string>`(select name from teams t where t.id = ${matches.homeTeamId})`, aname: sql<string>`(select name from teams t where t.id = ${matches.awayTeamId})`, shots: sql<number>`${matches.homeShots} + ${matches.awayShots}` })
    .from(matches)
    .where(and(eq(matches.source, "espn"), eq(matches.status, "finished"), or(eq(matches.homeTeamId, teamId), eq(matches.awayTeamId, teamId)), sql`${matches.kickoff} < ${before}`))
    .orderBy(desc(matches.kickoff))
    .limit(20);
  return rows.map((r) => {
    const emCasa = r.home === teamId;
    const hasStats = Number(r.shots) > 0;
    return { data: new Date(r.kickoff).toISOString().slice(0, 10), adversario: emCasa ? r.aname : r.hname, emCasa, golsFT: emCasa ? r.hs : r.as, golsHT: null, faltas: hasStats ? (emCasa ? r.hf : r.af) : null, chutesNoGolHT: null, escanteios: hasStats ? (emCasa ? r.hc : r.ac) : null, cartoes: hasStats ? (emCasa ? r.hcd : r.acd) : null, golsSofridosFT: emCasa ? r.as : r.hs, golsSofridosHT: null, finalizacoes: hasStats ? (emCasa ? r.hsh : r.ash) : null, impedimentos: hasStats ? (emCasa ? r.ho : r.ao) : null, chutesNoGol: hasStats ? (emCasa ? r.hsot : r.asot) : null, placar: `${r.hs}-${r.as}` };
  });
}

/* -------------------- Coerência da amostra (anti falso positivo) -------------------- */

/**
 * Garante que o histórico vindo da fonte externa é realmente do time certo:
 * pelo menos 2 adversários (ou 1 quando a amostra é pequena) precisam ser times
 * conhecidos no site (mesma liga ou qualquer liga monitorada). Evita casar "Angers"
 * com um clube homônimo de outra divisão.
 */
async function amostraCoerente(teamId: number, jogos: JogoStats[]) {
  const [me] = await db.select({ leagueId: teams.leagueId }).from(teams).where(eq(teams.id, teamId)).limit(1);
  const known = await db.select({ name: teams.name, leagueId: teams.leagueId }).from(teams);
  const sameLeague = known.filter((k) => me?.leagueId && k.leagueId === me.leagueId).map((k) => k.name);
  const any = known.map((k) => k.name);
  const hitsLeague = jogos.filter((j) => sameLeague.some((n) => sameTeam(n, j.adversario))).length;
  const hitsAny = jogos.filter((j) => any.some((n) => strictTeam(n, j.adversario))).length;
  const need = jogos.length >= 8 ? 2 : 1;
  return hitsLeague >= need || hitsAny >= Math.max(need, Math.ceil(jogos.length * 0.4));
}

/* ------------------------------ Serviço ------------------------------- */

/**
 * calcularOportunidades(timeId, isMandante)
 *  - timeId: id do time na tabela `teams` do site
 *  - isMandante: contexto do confronto (exibido e usado para filtrar jogos em casa/fora quando houver amostra suficiente)
 */
const histCache = new Map<string, { at: number; value: { jogos: JogoStats[]; fonte: OportunidadesResultado["fonte"]; time: string } }>();

/** Histórico recente real do time (até 25 jogos), com validação de coerência. Reutilizado pelo Detector. */
export async function carregarHistorico(timeId: number, before = new Date()): Promise<{ jogos: JogoStats[]; fonte: OportunidadesResultado["fonte"]; time: string }> {
  const key = `${timeId}-${iso(before)}`;
  const hit = histCache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.value;
  const [team] = await db.select({ id: teams.id, name: teams.name }).from(teams).where(eq(teams.id, timeId)).limit(1);
  if (!team) return { jogos: [], fonte: "none", time: "?" };
  let jogos: JogoStats[] | null = null;
  let fonte: OportunidadesResultado["fonte"] = "none";
  const sm = await viaSportmonks(team.name, before).catch(() => null);
  if (sm && sm.length >= 5 && (await amostraCoerente(timeId, sm))) { jogos = sm; fonte = "sportmonks"; }
  if (!jogos) {
    const bz = await viaBzzoiro(team.name, before).catch(() => null);
    if (bz && bz.jogos.length >= 5 && (await amostraCoerente(timeId, bz.jogos))) { jogos = bz.jogos; fonte = "bzzoiro"; }
  }
  if (!jogos) {
    const es = await viaEspn(timeId, before);
    if (es.length) { jogos = es; fonte = "espn"; }
  }
  const value = { jogos: jogos ?? [], fonte, time: team.name };
  histCache.set(key, { at: Date.now(), value });
  return value;
}

export async function calcularOportunidades(timeId: number, isMandante: boolean, before = new Date()): Promise<OportunidadesResultado> {
  const key = `${timeId}-${isMandante}-${iso(before)}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.value;

  const [team] = await db.select({ id: teams.id, name: teams.name }).from(teams).where(eq(teams.id, timeId)).limit(1);
  if (!team) return { timeId, time: "?", isMandante, fonte: "none", jogosAnalisados: 0, jogos: [], jogosDetalhados: [], oportunidades: [], todosMercados: [], aviso: "Time não encontrado." };

  let jogos: JogoStats[] | null = null;
  let fonte: OportunidadesResultado["fonte"] = "none";
  const sm = await viaSportmonks(team.name, before).catch(() => null);
  if (sm && sm.length >= 5 && (await amostraCoerente(timeId, sm))) { jogos = sm; fonte = "sportmonks"; }
  if (!jogos) {
    const bz = await viaBzzoiro(team.name, before).catch(() => null);
    if (bz && bz.jogos.length >= 5 && (await amostraCoerente(timeId, bz.jogos))) { jogos = bz.jogos; fonte = "bzzoiro"; }
  }
  if (!jogos) {
    const es = await viaEspn(timeId, before);
    if (es.length) { jogos = es; fonte = "espn"; }
  }
  if (!jogos || !jogos.length) {
    const value: OportunidadesResultado = { timeId, time: team.name, isMandante, fonte: "none", jogosAnalisados: 0, jogos: [], jogosDetalhados: [], oportunidades: [], todosMercados: [], aviso: "Nenhuma fonte configurada retornou jogos deste time." };
    cache.set(key, { at: Date.now(), value });
    return value;
  }

  // Preferência por jogos no mesmo mando quando há amostra (≥7); senão usa os 10 últimos gerais
  const mesmoMando = jogos.filter((j) => j.emCasa === isMandante);
  const base = mesmoMando.length >= 7 ? mesmoMando.slice(0, 10) : jogos.slice(0, 10);
  const mercados = calcularMercados(base);
  const value: OportunidadesResultado = {
    timeId, time: team.name, isMandante, fonte,
    jogosAnalisados: base.length,
    jogos: base.map((j) => ({ data: j.data, adversario: j.adversario, emCasa: j.emCasa, placar: j.placar })),
    jogosDetalhados: base,
    oportunidades: mercados.filter((m) => m.disponivel && m.acertos >= 7).map(({ disponivel: _d, motivo: _m, ...o }) => o),
    todosMercados: mercados,
    aviso: base.length < 10 ? `Apenas ${base.length} jogos disponíveis na fonte — taxas calculadas sobre ${base.length}.` : mesmoMando.length >= 7 ? `Amostra: últimos ${base.length} jogos como ${isMandante ? "mandante" : "visitante"}.` : undefined,
  };
  cache.set(key, { at: Date.now(), value });
  return value;
}

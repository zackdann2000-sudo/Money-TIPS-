/**
 * Chaves VAPID (Web Push nativo) — fixas no código (o ambiente não carrega variáveis).
 * A PÚBLICA é enviada ao navegador (segura por definição).
 * A PRIVADA só é usada em src/lib/push.ts (servidor). NUNCA importe em componentes "use client".
 */
export const VAPID_PUBLIC_KEY = "BKhuZ7nBFVRlc05eRSMpZylx3OVimtudepf-5qLEHVIM83frLg50lyTz8qnHuMLA01BIw8DBAza5pONrM8sSh7M";
export const VAPID_PRIVATE_KEY = "AXFUwKc7qtno7Wa06svSP0NogFYqnRwnQ1T0gGfZrRE";
export const VAPID_SUBJECT = "mailto:zackdann2000@gmail.com";

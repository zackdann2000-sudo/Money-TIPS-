import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeed } from "@/db/seed";
import { notifications, users } from "@/db/schema";
import { hashPassword, isGmail, trialExpiryFor, verifyPassword } from "@/lib/auth";

export type RegisterResult =
  | { ok: true; userId: number; email: string; trialSource: string; accessExpiresAt: Date }
  | { ok: false; error: string };

export async function registerUser(input: { name: string; email: string; password: string }): Promise<RegisterResult> {
  await ensureSeed();
  const name = input.name.trim();
  const email = input.email.trim().toLowerCase();
  const password = input.password;

  if (!name || name.length < 3) return { ok: false, error: "Informe seu nome completo." };
  if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) return { ok: false, error: "Informe um e-mail válido." };
  if (password.length < 6) return { ok: false, error: "A senha precisa de pelo menos 6 caracteres." };

  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing) return { ok: false, error: "Este e-mail já possui conta. Faça login." };

  const trial = trialExpiryFor(email);
  const [created] = await db
    .insert(users)
    .values({
      name,
      email,
      passwordHash: hashPassword(password),
      plan: "free",
      accessExpiresAt: trial.expiresAt,
      trialSource: trial.source,
      avatarSeed: name.slice(0, 2).toUpperCase(),
      lastLoginAt: new Date(),
      lastSeenAt: new Date(),
    })
    .returning({ id: users.id });

  await db.insert(notifications).values({
    userId: created.id,
    type: "subscription",
    title: isGmail(email) ? "🎁 1 dia grátis liberado!" : "⏳ Teste de 6 horas liberado",
    body: isGmail(email)
      ? "Sua conta Gmail ganhou 24 horas de acesso completo. Aproveite os alertas ao vivo, escalações previstas e análises de mercados."
      : "Você tem 6 horas de acesso. Assine o plano VIP para continuar vendo estatísticas ao vivo depois do teste.",
  });

  return { ok: true, userId: created.id, email, trialSource: trial.source, accessExpiresAt: trial.expiresAt };
}

export async function authenticate(email: string, password: string) {
  await ensureSeed();
  const normalized = email.trim().toLowerCase();
  const [user] = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) return null;
  await db.update(users).set({ lastLoginAt: new Date(), lastSeenAt: new Date() }).where(eq(users.id, user.id));
  return user;
}

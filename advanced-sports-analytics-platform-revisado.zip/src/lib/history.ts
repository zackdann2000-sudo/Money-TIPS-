import { and, desc, eq, gte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { historicalMatches, syncState } from "@/db/schema";
import { ESPN_LEAGUES } from "@/lib/espn";
import { espnFetch } from "@/lib/espn-fetch";
import type { HistMatch } from "@/lib/model";

const SITE = "https://site.api.espn.com/apis/site/v2/sports/soccer";
const TTL_MS = 6 * 60 * 60 * 1000;
const MIN_MATCHES_PER_TEAM = 12; // abaixo disso, busca também a temporada anterior

async function fetchJson<T>(url: string): Promise<T | null> {
  // histórico de resultados: cache de 10 min
  return espnFetch<T>(url, { timeoutMs: 10000, ttlMs: 10 * 60_000 });
}

type Schedule = {
  season?: { year?: number };
  events?: {
    id: string;
    date: string;
    competitions: {
      neutralSite?: boolean;
      status: { type: { state: string; completed?: boolean } };
      competitors: { homeAway: string; team: { id: string; displayName: string }; score?: { value?: number } | string }[];
    }[];
  }[];
};

function scoreOf(score: { value?: number } | string | undefined) {
  if (typeof score === "string") return Number(score) || 0;
  return Number(score?.value ?? 0) || 0;
}

async function fetchTeamSchedule(code: string, teamId: string, season?: number) {
  const data = await fetchJson<Schedule>(`${SITE}/${code}/teams/${teamId}/schedule${season ? `?season=${season}` : ""}`);
  const year = Number(data?.season?.year ?? season ?? new Date().getFullYear());
  const rows: (typeof historicalMatches.$inferInsert)[] = [];
  for (const e of data?.events ?? []) {
    const c = e.competitions?.[0];
    if (!c || c.status?.type?.state !== "post") continue;
    const home = c.competitors.find((x) => x.homeAway === "home");
    const away = c.competitors.find((x) => x.homeAway === "away");
    if (!home || !away) continue;
    rows.push({
      source: "espn",
      externalId: e.id,
      leagueCode: code,
      season: season ?? year,
      date: new Date(e.date),
      homeExtId: home.team.id,
      awayExtId: away.team.id,
      homeName: home.team.displayName,
      awayName: away.team.displayName,
      homeScore: scoreOf(home.score),
      awayScore: scoreOf(away.score),
      neutral: Boolean(c.neutralSite),
    });
  }
  return rows;
}

type ScheduleAll = Schedule & { events?: (NonNullable<Schedule["events"]>[number] & { league?: { slug?: string } })[] };

/** Calendário do time em TODAS as competições (endpoint "all" da ESPN). */
async function fetchTeamScheduleAll(teamId: string, season?: number) {
  const data = await fetchJson<ScheduleAll>(`${SITE}/all/teams/${teamId}/schedule${season ? `?season=${season}` : ""}`);
  const year = Number(data?.season?.year ?? season ?? new Date().getFullYear());
  const rows: (typeof historicalMatches.$inferInsert)[] = [];
  for (const e of data?.events ?? []) {
    const c = e.competitions?.[0];
    if (!c || c.status?.type?.state !== "post") continue;
    const home = c.competitors.find((x) => x.homeAway === "home");
    const away = c.competitors.find((x) => x.homeAway === "away");
    if (!home || !away) continue;
    rows.push({ source: "espn", externalId: e.id, leagueCode: e.league?.slug ?? "all", season: season ?? year, date: new Date(e.date), homeExtId: home.team.id, awayExtId: away.team.id, homeName: home.team.displayName, awayName: away.team.displayName, homeScore: scoreOf(home.score), awayScore: scoreOf(away.score), neutral: Boolean(c.neutralSite) });
  }
  return rows;
}

async function runPool<T>(items: T[], limit: number, worker: (item: T) => Promise<unknown>) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const item = items[i++];
      try { await worker(item); } catch (error) { console.error("history pool", error); }
    }
  }));
}

const inflight = new Map<string, Promise<{ ok: boolean; message: string; count: number }>>();

export async function getHistoryState(code: string) {
  const [row] = await db.select().from(syncState).where(eq(syncState.key, `history:${code}`)).limit(1);
  return row ?? null;
}

/** Baixa o histórico de resultados de uma liga (todos os clubes; temporada anterior se a atual for curta). */
export async function syncHistory(code: string, force = false) {
  const key = `history:${code}`;
  const running = inflight.get(key);
  if (running) return running;
  const task = (async () => {
    const state = await getHistoryState(code);
    if (!force && state?.lastSuccessAt && Date.now() - new Date(state.lastSuccessAt).getTime() < TTL_MS) {
      return { ok: true, message: state.lastMessage, count: state.matchesSynced };
    }
    await db.insert(syncState).values({ key, lastRunAt: new Date() }).onConflictDoUpdate({ target: syncState.key, set: { lastRunAt: new Date() } });
    const teamsData = await fetchJson<{ sports?: { leagues?: { teams?: { team: { id: string } }[] }[] }[] }>(`${SITE}/${code}/teams?limit=60`);
    const teamIds = (teamsData?.sports?.[0]?.leagues?.[0]?.teams ?? []).map((t) => t.team.id);
    if (!teamIds.length) {
      const message = "Fonte indisponível para esta competição";
      await db.update(syncState).set({ lastMessage: message }).where(eq(syncState.key, key));
      return { ok: false, message, count: 0 };
    }
    const collected = new Map<string, typeof historicalMatches.$inferInsert>();
    const perTeam = new Map<string, number>();
    await runPool(teamIds, 6, async (teamId) => {
      const rows = await fetchTeamSchedule(code, teamId);
      perTeam.set(teamId, rows.length);
      rows.forEach((r) => collected.set(r.externalId, r));
    });
    const currentSeason = [...collected.values()][0]?.season ?? new Date().getFullYear();
    const short = [...perTeam.values()].filter((n) => n < MIN_MATCHES_PER_TEAM).length > teamIds.length / 2;
    if (short) {
      await runPool(teamIds, 6, async (teamId) => {
        const rows = await fetchTeamSchedule(code, teamId, currentSeason - 1);
        rows.forEach((r) => collected.set(r.externalId, r));
      });
    }
    const rows = [...collected.values()];
    for (let i = 0; i < rows.length; i += 200) {
      const chunk = rows.slice(i, i + 200);
      await db
        .insert(historicalMatches)
        .values(chunk)
        .onConflictDoUpdate({ target: [historicalMatches.source, historicalMatches.externalId], set: { homeScore: sql`excluded.home_score`, awayScore: sql`excluded.away_score`, date: sql`excluded.date` } });
    }
    const message = `${rows.length} resultados · ${teamIds.length} clubes · temporada ${currentSeason}${short ? ` + ${currentSeason - 1}` : ""}`;
    await db.update(syncState).set({ lastSuccessAt: new Date(), lastMessage: message, matchesSynced: rows.length }).where(eq(syncState.key, key));
    return { ok: true, message, count: rows.length };
  })().finally(() => inflight.delete(key));
  inflight.set(key, task);
  return task;
}

export async function loadHistory(code: string, before?: Date): Promise<HistMatch[]> {
  const rows = await db
    .select()
    .from(historicalMatches)
    .where(and(eq(historicalMatches.leagueCode, code), before ? sql`${historicalMatches.date} < ${before}` : undefined))
    .orderBy(historicalMatches.date);
  return rows.map((r) => ({ date: new Date(r.date), home: r.homeExtId, away: r.awayExtId, hg: r.homeScore, ag: r.awayScore, neutral: r.neutral }));
}

export type TeamForm = {
  played: number; wins: number; draws: number; losses: number; gf: number; ga: number;
  cleanSheets: number; scoredIn: number; sequence: string[];
  last: { date: Date; opponent: string; home: boolean; gf: number; ga: number; result: "V" | "E" | "D" }[];
};

export function teamForm(history: HistMatch[], team: string, names: Map<string, string>, limit: number, venue?: "home" | "away"): TeamForm {
  const games = history
    .filter((m) => (venue === "home" ? m.home === team : venue === "away" ? m.away === team : m.home === team || m.away === team))
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, limit);
  const form: TeamForm = { played: games.length, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, cleanSheets: 0, scoredIn: 0, sequence: [], last: [] };
  for (const m of games) {
    const home = m.home === team;
    const gf = home ? m.hg : m.ag, ga = home ? m.ag : m.hg;
    const result: "V" | "E" | "D" = gf > ga ? "V" : gf === ga ? "E" : "D";
    form.gf += gf; form.ga += ga;
    if (result === "V") form.wins++; else if (result === "E") form.draws++; else form.losses++;
    if (ga === 0) form.cleanSheets++;
    if (gf > 0) form.scoredIn++;
    form.sequence.push(result);
    form.last.push({ date: m.date, opponent: names.get(home ? m.away : m.home) ?? "Adversário", home, gf, ga, result });
  }
  return form;
}

export function headToHead(history: HistMatch[], a: string, b: string, names: Map<string, string>, limit = 10) {
  const games = history.filter((m) => (m.home === a && m.away === b) || (m.home === b && m.away === a)).sort((x, y) => y.date.getTime() - x.date.getTime()).slice(0, limit);
  let aWins = 0, bWins = 0, draws = 0, aGoals = 0, bGoals = 0;
  for (const m of games) {
    const ag = m.home === a ? m.hg : m.ag, bg = m.home === a ? m.ag : m.hg;
    aGoals += ag; bGoals += bg;
    if (ag > bg) aWins++; else if (ag === bg) draws++; else bWins++;
  }
  return {
    games: games.map((m) => ({ date: m.date, home: names.get(m.home) ?? m.home, away: names.get(m.away) ?? m.away, hg: m.hg, ag: m.ag })),
    aWins, bWins, draws, aGoals, bGoals, n: games.length,
    over25: games.filter((m) => m.hg + m.ag > 2).length, btts: games.filter((m) => m.hg > 0 && m.ag > 0).length,
  };
}

export type StandingRow = { team: string; name: string; played: number; wins: number; draws: number; losses: number; gf: number; ga: number; points: number; homePts: number; homePlayed: number; awayPts: number; awayPlayed: number; rank: number };

export function standings(history: HistMatch[], season: number | null, names: Map<string, string>, seasonOf: Map<string, number>): StandingRow[] {
  const table = new Map<string, StandingRow>();
  const get = (t: string) => {
    if (!table.has(t)) table.set(t, { team: t, name: names.get(t) ?? t, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, points: 0, homePts: 0, homePlayed: 0, awayPts: 0, awayPlayed: 0, rank: 0 });
    return table.get(t)!;
  };
  for (const m of history) {
    const key = `${m.home}-${m.away}-${m.date.getTime()}`;
    if (season !== null && seasonOf.get(key) !== season) continue;
    const h = get(m.home), a = get(m.away);
    h.played++; a.played++; h.gf += m.hg; h.ga += m.ag; a.gf += m.ag; a.ga += m.hg; h.homePlayed++; a.awayPlayed++;
    if (m.hg > m.ag) { h.wins++; a.losses++; h.points += 3; h.homePts += 3; }
    else if (m.hg === m.ag) { h.draws++; a.draws++; h.points++; a.points++; h.homePts++; a.awayPts++; }
    else { a.wins++; h.losses++; a.points += 3; a.awayPts += 3; }
  }
  const rows = [...table.values()].sort((x, y) => y.points - x.points || (y.gf - y.ga) - (x.gf - x.ga) || y.gf - x.gf);
  rows.forEach((r, i) => (r.rank = i + 1));
  return rows;
}

export async function historyMeta(code: string) {
  const rows = await db
    .select({ externalId: historicalMatches.externalId, home: historicalMatches.homeExtId, away: historicalMatches.awayExtId, homeName: historicalMatches.homeName, awayName: historicalMatches.awayName, season: historicalMatches.season, date: historicalMatches.date })
    .from(historicalMatches)
    .where(eq(historicalMatches.leagueCode, code));
  const names = new Map<string, string>();
  const seasonOf = new Map<string, number>();
  let latestSeason = 0;
  for (const r of rows) {
    names.set(r.home, r.homeName); names.set(r.away, r.awayName);
    seasonOf.set(`${r.home}-${r.away}-${new Date(r.date).getTime()}`, r.season);
    latestSeason = Math.max(latestSeason, r.season);
  }
  return { names, seasonOf, latestSeason: latestSeason || null };
}

export async function recentFor(team: string, days = 14) {
  const since = new Date(Date.now() - days * 86400000);
  return db
    .select({ date: historicalMatches.date })
    .from(historicalMatches)
    .where(and(or(eq(historicalMatches.homeExtId, team), eq(historicalMatches.awayExtId, team)), gte(historicalMatches.date, since)))
    .orderBy(desc(historicalMatches.date));
}

export const leagueDef = (code: string) => ESPN_LEAGUES.find((l) => l.code === code);

/* ------------------------------------------------------------------ */
/*  Fallback por TIME: últimos N jogos do clube em QUALQUER competição  */
/*  (temporada atual e, se faltar, a anterior). Usado quando a equipe   */
/*  tem < 5 jogos na competição analisada (ex.: estreante na Champions). */
/* ------------------------------------------------------------------ */

const teamFormCache = new Map<string, { at: number; value: HistMatch[] }>();
/** Nomes de clubes vistos no fallback (inclusive fora das ligas monitoradas), para rotular adversários. */
export const extraTeamNames = new Map<string, string>();

export async function teamRecentAnyCompetition(teamExtId: string, before: Date, limit = 10): Promise<HistMatch[]> {
  const key = `${teamExtId}-${before.toISOString().slice(0, 10)}`;
  const hit = teamFormCache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value;
  // 1) tudo que já está no banco sobre o time (todas as ligas sincronizadas)
  const rows = await db
    .select()
    .from(historicalMatches)
    .where(and(or(eq(historicalMatches.homeExtId, teamExtId), eq(historicalMatches.awayExtId, teamExtId)), sql`${historicalMatches.date} < ${before}`))
    .orderBy(desc(historicalMatches.date))
    .limit(limit);
  for (const r of rows) { extraTeamNames.set(r.homeExtId, r.homeName); extraTeamNames.set(r.awayExtId, r.awayName); }
  let games: HistMatch[] = rows.map((r) => ({ date: new Date(r.date), home: r.homeExtId, away: r.awayExtId, hg: r.homeScore, ag: r.awayScore, neutral: r.neutral }));
  // 2) se ainda falta amostra, consulta a ESPN: calendário geral do time ("all" = todas as competições,
  //    inclusive ligas fora da cobertura do site) na temporada atual e, se preciso, na anterior
  if (games.length < limit) {
    const seen = new Set(rows.map((r) => r.externalId));
    const collected: (typeof historicalMatches.$inferInsert)[] = [];
    const seasonYear = before.getUTCFullYear();
    for (const season of [undefined, seasonYear - 1]) {
      const found = await fetchTeamScheduleAll(teamExtId, season).catch(() => []);
      for (const f of found) if (!seen.has(f.externalId) && new Date(f.date).getTime() < before.getTime()) { seen.add(f.externalId); collected.push(f); }
      if (games.length + collected.length >= limit) break;
    }
    // 3) último recurso: ligas monitoradas uma a uma (temporada anterior)
    if (games.length + collected.length < limit) {
      for (const league of ESPN_LEAGUES) {
        const found = await fetchTeamSchedule(league.code, teamExtId, seasonYear - 1).catch(() => []);
        for (const f of found) if (!seen.has(f.externalId) && new Date(f.date).getTime() < before.getTime()) { seen.add(f.externalId); collected.push(f); }
        if (games.length + collected.length >= limit) break;
      }
    }
    for (const c of collected) { extraTeamNames.set(c.homeExtId, c.homeName); extraTeamNames.set(c.awayExtId, c.awayName); }
    if (collected.length) {
      for (let i = 0; i < collected.length; i += 200) {
        await db.insert(historicalMatches).values(collected.slice(i, i + 200)).onConflictDoNothing();
      }
      games = [...games, ...collected.map((r) => ({ date: new Date(r.date), home: r.homeExtId, away: r.awayExtId, hg: r.homeScore, ag: r.awayScore, neutral: Boolean(r.neutral) }))]
        .sort((a, b) => b.date.getTime() - a.date.getTime())
        .filter((g, i, arr) => arr.findIndex((x) => x.date.getTime() === g.date.getTime() && x.home === g.home && x.away === g.away) === i)
        .slice(0, limit);
    }
  }
  teamFormCache.set(key, { at: Date.now(), value: games });
  return games;
}

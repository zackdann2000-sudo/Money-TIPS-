import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { favorites, leagues, lineups, matchEvents, matches, notifications, syncState, teams, users } from "@/db/schema";
import { wantsAlert } from "@/lib/alerts";
import { enviarParaUsuarios } from "@/lib/push";
import { dispararEvento, type AlertEvent } from "@/lib/alert-engine";
import { espnFetch } from "@/lib/espn-fetch";

/** Competições reais acompanhadas (API pública da ESPN, sem chave). */
export const ESPN_LEAGUES = [
  { code: "bra.1", slug: "brasileirao", name: "Brasileirão Série A", country: "Brasil", flag: "🇧🇷", color: "#0b8f4e", sortOrder: 1 },
  { code: "bra.2", slug: "brasileirao-serie-b", name: "Brasileirão Série B", country: "Brasil", flag: "🇧🇷", color: "#1f6f43", sortOrder: 2 },
  { code: "bra.copa_do_brazil", slug: "copa-do-brasil", name: "Copa do Brasil", country: "Brasil", flag: "🇧🇷", color: "#14532d", sortOrder: 3 },
  { code: "eng.1", slug: "premier-league", name: "Premier League", country: "Inglaterra", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", color: "#3d195b", sortOrder: 4 },
  { code: "esp.1", slug: "laliga", name: "LaLiga", country: "Espanha", flag: "🇪🇸", color: "#ee8707", sortOrder: 5 },
  { code: "ita.1", slug: "serie-a", name: "Serie A", country: "Itália", flag: "🇮🇹", color: "#1a78cf", sortOrder: 6 },
  { code: "ger.1", slug: "bundesliga", name: "Bundesliga", country: "Alemanha", flag: "🇩🇪", color: "#d20515", sortOrder: 7 },
  { code: "fra.1", slug: "ligue-1", name: "Ligue 1", country: "França", flag: "🇫🇷", color: "#091c3e", sortOrder: 8 },
  { code: "por.1", slug: "liga-portugal", name: "Liga Portugal", country: "Portugal", flag: "🇵🇹", color: "#0f766e", sortOrder: 9 },
  { code: "uefa.champions", slug: "champions", name: "UEFA Champions League", country: "Europa", flag: "🇪🇺", color: "#0e1e5b", sortOrder: 10 },
  { code: "uefa.europa", slug: "europa-league", name: "UEFA Europa League", country: "Europa", flag: "🇪🇺", color: "#f97316", sortOrder: 11 },
  { code: "conmebol.libertadores", slug: "libertadores", name: "Copa Libertadores", country: "América do Sul", flag: "🌎", color: "#0f7a3d", sortOrder: 12 },
  { code: "conmebol.sudamericana", slug: "sul-americana", name: "Copa Sul-Americana", country: "América do Sul", flag: "🌎", color: "#b45309", sortOrder: 13 },
  { code: "arg.1", slug: "liga-argentina", name: "Liga Profissional Argentina", country: "Argentina", flag: "🇦🇷", color: "#38bdf8", sortOrder: 14 },
  { code: "usa.1", slug: "mls", name: "MLS", country: "Estados Unidos", flag: "🇺🇸", color: "#1d4ed8", sortOrder: 15 },
  { code: "ned.1", slug: "eredivisie", name: "Eredivisie", country: "Holanda", flag: "🇳🇱", color: "#ea580c", sortOrder: 16 },
];

export const TZ = "America/Sao_Paulo";
const BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer";
const SYNC_KEY = "espn";
const MIN_INTERVAL_MS = 45_000;

type EspnCompetitor = {
  homeAway: "home" | "away";
  score?: string;
  form?: string;
  records?: { summary?: string }[];
  statistics?: { name: string; displayValue: string }[];
  team: { id: string; displayName: string; shortDisplayName?: string; abbreviation?: string; color?: string; alternateColor?: string; logo?: string; location?: string };
};
type EspnEvent = {
  id: string;
  date: string;
  name: string;
  season?: { year?: number };
  week?: { number?: number };
  status: { clock?: number; displayClock?: string; type: { state: "pre" | "in" | "post"; completed?: boolean; shortDetail?: string; detail?: string; name?: string } };
  competitions: {
    venue?: { fullName?: string };
    competitors: EspnCompetitor[];
    odds?: { details?: string; overUnder?: number | string }[];
    notes?: { headline?: string }[];
    details?: { type: { text: string }; clock: { displayValue: string }; team?: { id: string }; scoringPlay?: boolean; redCard?: boolean; yellowCard?: boolean; penaltyKick?: boolean; ownGoal?: boolean; athletesInvolved?: { displayName?: string }[] }[];
  }[];
};
type EspnSummary = {
  lastFiveGames?: { team: { id: string }; events?: { gameDate?: string; opponent?: { displayName?: string }; score?: string; gameResult?: string; atVs?: string; leagueName?: string }[] }[];
  boxscore?: { teams?: { team: { id: string }; statistics?: { name: string; displayValue: string }[] }[] };
  rosters?: { homeAway: string; team: { id: string }; formation?: string; roster?: { jersey?: string; starter?: boolean; formationPlace?: string; athlete?: { displayName?: string; shortName?: string }; position?: { abbreviation?: string } }[] }[];
  keyEvents?: { clock?: { displayValue?: string }; type?: { text?: string }; team?: { id?: string; displayName?: string }; participants?: { athlete?: { displayName?: string }; displayName?: string }[]; text?: string; scoringPlay?: boolean; penaltyKick?: boolean; ownGoal?: boolean }[];
  header?: { competitions?: { status?: { type?: { state?: string } } }[] };
};

const globalCache = globalThis as typeof globalThis & { __gsSync?: { inFlight: Promise<SyncReport> | null; lastRun: number } };
const state = (globalCache.__gsSync ??= { inFlight: null, lastRun: 0 });

export type SyncReport = { ok: boolean; message: string; matches: number; live: number; at: number };

function dayCode(offsetDays: number) {
  const now = new Date(Date.now() + offsetDays * 86400000);
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  return `${get("year")}${get("month")}${get("day")}`;
}

/** Requisições à ESPN passam pelo cliente com cache de 30 s + deduplicação (src/lib/espn-fetch.ts). */
async function fetchJson<T>(url: string, timeoutMs = 9000): Promise<T | null> {
  return espnFetch<T>(url, { timeoutMs });
}

export function slugify(value: string) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function statNumber(stats: { name: string; displayValue: string }[] | undefined, name: string) {
  const row = stats?.find((s) => s.name === name);
  if (!row) return null;
  const value = Number.parseFloat(row.displayValue.replace(",", "."));
  return Number.isFinite(value) ? value : null;
}

function mapStatus(event: EspnEvent): { status: string; minute: number } {
  const type = event.status.type;
  if (type.state === "in") {
    // "45'+2" → 45 (+2 acréscimos) · "67'" → 67 · "HT" → 45
    const display = event.status.displayClock ?? "";
    const parsed = display.match(/(\d+)(?:'?\s*\+\s*(\d+))?/);
    const base = parsed ? Number(parsed[1]) : Math.round(Number(event.status.clock ?? 0) / 60) || 0;
    const extra = parsed?.[2] ? Number(parsed[2]) : 0;
    const isHalftime = /HT|intervalo/i.test(event.status.type.shortDetail ?? "") || /HT/i.test(display);
    const clock = isHalftime ? 45 : base + extra;
    return { status: "live", minute: Math.min(120, Math.max(1, clock || 1)) };
  }
  if (type.state === "post") return { status: "finished", minute: 90 };
  return { status: "scheduled", minute: 0 };
}

function eventType(text: string, flags: { scoringPlay?: boolean; penaltyKick?: boolean; ownGoal?: boolean }): string | null {
  const t = text.toLowerCase();
  if (flags.penaltyKick && flags.scoringPlay) return "penalty";
  if (t.includes("penalty") && t.includes("goal")) return "penalty";
  if (t.includes("own goal")) return "goal";
  if (t === "goal" || flags.scoringPlay) return "goal";
  if (t.includes("red card")) return "red";
  if (t.includes("yellow card")) return "yellow";
  if (t.includes("substitution")) return "sub";
  if (t.includes("kickoff")) return "kickoff";
  if (t.includes("end regular") || t.includes("full time") || t.includes("end extra")) return "end";
  if (t.includes("halftime") || t.includes("half time")) return "var";
  if (t.includes("var") || t.includes("video review")) return "var";
  if (t.includes("penalty - missed") || t.includes("penalty missed") || t.includes("saved")) return "penalty";
  return null;
}

function translateEvent(type: string, text: string, player: string, teamName: string) {
  const who = player || teamName;
  switch (type) {
    case "goal": return text.toLowerCase().includes("own goal") ? `Gol contra — ${who} (${teamName})` : `Gol de ${who} (${teamName})`;
    case "penalty": return text.toLowerCase().includes("missed") || text.toLowerCase().includes("saved") ? `Pênalti perdido — ${who} (${teamName})` : `Pênalti convertido por ${who} (${teamName})`;
    case "red": return `Cartão vermelho para ${who} (${teamName})`;
    case "yellow": return `Cartão amarelo para ${who} (${teamName})`;
    case "sub": return `Substituição no ${teamName}`;
    case "kickoff": return "Bola rolando";
    case "end": return "Fim de jogo";
    default: return text || "Lance revisado";
  }
}

async function upsertLeague(code: string) {
  const def = ESPN_LEAGUES.find((l) => l.code === code)!;
  const [existing] = await db.select({ id: leagues.id }).from(leagues).where(eq(leagues.slug, def.slug)).limit(1);
  if (existing) return existing.id;
  const [created] = await db
    .insert(leagues)
    .values({ slug: def.slug, name: def.name, country: def.country, flag: def.flag, color: def.color, sortOrder: def.sortOrder, season: String(new Date().getFullYear()) })
    .returning({ id: leagues.id });
  return created.id;
}

const teamIdCache = new Map<string, number>();

async function upsertTeam(c: EspnCompetitor, leagueId: number, country: string) {
  const ext = c.team.id;
  const cached = teamIdCache.get(ext);
  const name = c.team.displayName;
  const slug = slugify(name) || `time-${ext}`;
  const color = c.team.color ? `#${c.team.color}` : "#16a34a";
  const colorAlt = c.team.alternateColor ? `#${c.team.alternateColor}` : "#0f172a";
  const record = c.records?.[0]?.summary ?? "";
  const [w, d, l] = record.split("-").map((n) => Number(n) || 0);
  const played = w + d + l;
  const formRaw = (c.form ?? "").toUpperCase().replace(/W/g, "V").replace(/D/g, "E").replace(/L/g, "N");
  const form = formRaw ? formRaw.split("").reverse().join("").slice(0, 5) : "";
  const patch = {
    name,
    shortName: (c.team.abbreviation ?? name.slice(0, 3)).toUpperCase().slice(0, 4),
    logo: c.team.logo ?? "",
    badgeColor: color,
    badgeColorAlt: colorAlt,
    leagueId,
    country,
    externalId: ext,
    source: "espn",
    description: `${name} · dados oficiais da temporada sincronizados em tempo real (ESPN). Campanha: ${w}V ${d}E ${l}D em ${played} jogos.`,
    ...(played ? { played, wins: w, draws: d, losses: l } : {}),
    ...(form ? { form } : {}),
  };
  if (cached) {
    await db.update(teams).set(patch).where(eq(teams.id, cached));
    return cached;
  }
  const [byExt] = await db.select({ id: teams.id }).from(teams).where(eq(teams.externalId, ext)).limit(1);
  const [bySlug] = byExt ? [byExt] : await db.select({ id: teams.id }).from(teams).where(eq(teams.slug, slug)).limit(1);
  if (bySlug) {
    await db.update(teams).set(patch).where(eq(teams.id, bySlug.id));
    teamIdCache.set(ext, bySlug.id);
    return bySlug.id;
  }
  const [created] = await db
    .insert(teams)
    .values({ slug, ...patch, position: 0 })
    .onConflictDoUpdate({ target: teams.slug, set: patch })
    .returning({ id: teams.id });
  teamIdCache.set(ext, created.id);
  return created.id;
}

type Snapshot = { id: number; status: string; homeScore: number; awayScore: number; homeCorners: number; awayCorners: number; homeCards: number; awayCards: number; homeOffsides: number; awayOffsides: number; homeFouls: number; awayFouls: number; lineupNotified: boolean };

/** Notifica apenas os usuários que favoritaram o time E ativaram esse tipo de alerta. */
/** Encaminha o evento ao Alert Engine (preferências por time/partida, agrupamento, push). Nunca interrompe a sincronização. */
function emitirEvento(ev: AlertEvent) {
  dispararEvento(ev).catch((error) => console.error("alert engine", error));
}

async function notifyFavorites(teamId: number, matchId: number, type: string, title: string, body: string) {
  const favs = await db
    .select({ userId: favorites.userId, prefs: users.alertPrefs })
    .from(favorites)
    .innerJoin(users, eq(favorites.userId, users.id))
    .where(eq(favorites.teamId, teamId));
  const targets = favs.filter((f) => wantsAlert(f.prefs, type));
  if (!targets.length) return;
  await db.insert(notifications).values(targets.map((f) => ({ userId: f.userId, matchId, teamId, type, title, body })));
  // Web Push: chega ao celular mesmo com o site fechado (inscrições VAPID salvas por usuário)
  enviarParaUsuarios(targets.map((f) => f.userId), title, body, { url: `/jogos/${matchId}`, tag: `match-${matchId}`, type });
}

async function syncSummary(event: EspnEvent, code: string, matchId: number, homeExt: string, awayExt: string, homeId: number, awayId: number, homeName: string, awayName: string) {
  const summary = await fetchJson<EspnSummary>(`${BASE}/${code}/summary?event=${event.id}`);
  if (!summary) return;

  // Últimos 5 jogos reais de cada equipe
  for (const block of summary.lastFiveGames ?? []) {
    const teamId = block.team.id === homeExt ? homeId : block.team.id === awayExt ? awayId : null;
    if (!teamId || !block.events?.length) continue;
    const recent = [...block.events]
      .reverse()
      .slice(0, 6)
      .map((g) => ({
        date: g.gameDate ?? "",
        opponent: g.opponent?.displayName ?? "Adversário",
        score: g.score ?? "",
        result: g.gameResult === "W" ? "V" : g.gameResult === "L" ? "N" : "E",
        home: g.atVs !== "@",
        competition: g.leagueName ?? "",
      }));
    const form = recent.map((g) => g.result).join("").slice(0, 5);
    await db.update(teams).set({ recentGames: recent, ...(form ? { form } : {}) }).where(eq(teams.id, teamId));
  }

  const box = summary.boxscore?.teams ?? [];
  const homeStats = box.find((t) => t.team.id === homeExt)?.statistics;
  const awayStats = box.find((t) => t.team.id === awayExt)?.statistics;
  if (homeStats || awayStats) {
    const hp = statNumber(homeStats, "possessionPct");
    const ap = statNumber(awayStats, "possessionPct");
    await db
      .update(matches)
      .set({
        homePossession: hp !== null ? Math.round(hp) : 50,
        awayPossession: ap !== null ? Math.round(ap) : hp !== null ? 100 - Math.round(hp) : 50,
        homeShots: statNumber(homeStats, "totalShots") ?? 0,
        awayShots: statNumber(awayStats, "totalShots") ?? 0,
        homeShotsOnTarget: statNumber(homeStats, "shotsOnTarget") ?? 0,
        awayShotsOnTarget: statNumber(awayStats, "shotsOnTarget") ?? 0,
        homeCorners: statNumber(homeStats, "wonCorners") ?? 0,
        awayCorners: statNumber(awayStats, "wonCorners") ?? 0,
        homeFouls: statNumber(homeStats, "foulsCommitted") ?? 0,
        awayFouls: statNumber(awayStats, "foulsCommitted") ?? 0,
        homeOffsides: statNumber(homeStats, "offsides") ?? 0,
        awayOffsides: statNumber(awayStats, "offsides") ?? 0,
        homeCards: (statNumber(homeStats, "yellowCards") ?? 0) + (statNumber(homeStats, "redCards") ?? 0),
        awayCards: (statNumber(awayStats, "yellowCards") ?? 0) + (statNumber(awayStats, "redCards") ?? 0),
      })
      .where(eq(matches.id, matchId));
  }

  // Lances reais do jogo
  const keyEvents = summary.keyEvents ?? [];
  if (keyEvents.length) {
    const rows = keyEvents
      .map((k) => {
        const text = k.type?.text ?? "";
        const type = eventType(text, { scoringPlay: k.scoringPlay, penaltyKick: k.penaltyKick, ownGoal: k.ownGoal });
        if (!type) return null;
        const side = k.team?.id === homeExt ? "home" : k.team?.id === awayExt ? "away" : "neutral";
        const teamName = side === "home" ? homeName : side === "away" ? awayName : "";
        const names = (k.participants ?? []).map((p) => p.athlete?.displayName ?? p.displayName ?? "").filter(Boolean);
        const player = names[0] ?? (k.text?.match(/^([^()]+?)\s\(/)?.[1] ?? "");
        // "90'+2'" → 90 + 2 acréscimos
        const clockMatch = (k.clock?.displayValue ?? "0").match(/(\d+)'?(?:\s*\+\s*(\d+))?/);
        const baseMin = clockMatch ? Number(clockMatch[1]) : 0;
        const extraMin = clockMatch?.[2] ? Number(clockMatch[2]) : 0;
        const minute = baseMin + extraMin;
        let detail = translateEvent(type, text, player.trim(), teamName);
        let scoreAfter = "";
        if (type === "sub") {
          const out = names[1] ?? (k.text?.match(/replaces\s+([^.]+?)(?:\s+because|\.|$)/)?.[1] ?? "");
          detail = out ? `Substituição: sai ${out}, entra ${player}` : `Substituição: entra ${player}`;
          if (/injury/i.test(k.text ?? "")) detail += " (lesão)";
        }
        if (type === "goal" || type === "penalty") {
          const assist = k.text?.match(/[Aa]ssisted by ([^.]+?)(?:\s+(?:with|following|after)\b|\.)/)?.[1];
          if (assist) detail += ` · assistência: ${assist.trim()}`;
          if (/own goal/i.test(k.text ?? "")) detail = `Gol contra — ${player} (${teamName})`;
          const sc = k.text?.match(/Goal!\s+.+?\s(\d+),\s+.+?\s(\d+)\./);
          if (sc) scoreAfter = `${sc[1]}-${sc[2]}`;
        }
        return { matchId, minute, half: baseMin > 45 ? 2 : 1, type, side, player: player.trim(), detail, scoreAfter, extra: extraMin };
      })
      .filter((r): r is NonNullable<typeof r> => Boolean(r));
    const [prevSubs] = await db.select({ n: sql<number>`count(*)` }).from(matchEvents).where(and(eq(matchEvents.matchId, matchId), eq(matchEvents.type, "sub")));
    const newSubs = rows.filter((r) => r.type === "sub");
    if (Number(prevSubs?.n ?? 0) > 0 && newSubs.length > Number(prevSubs.n)) {
      for (const sub of newSubs.slice(Number(prevSubs.n))) emitirEvento({ type: "substitution", teamId: sub.side === "home" ? homeId : awayId, matchId, minute: sub.minute, detail: sub.detail });
    }
    await db.delete(matchEvents).where(eq(matchEvents.matchId, matchId));
    if (rows.length) {
      let hs = 0;
      let as = 0;
      const ordered = [...rows].sort((a, b) => a.minute - b.minute || a.half - b.half);
      for (const row of ordered) {
        if ((row.type === "goal" || row.type === "penalty") && !row.detail.startsWith("Pênalti perdido")) {
          if (row.side === "home") hs += 1;
          if (row.side === "away") as += 1;
          if (!row.scoreAfter) row.scoreAfter = `${hs}-${as}`;
        }
      }
      await db.insert(matchEvents).values(ordered.map(({ extra: _extra, ...row }) => row));
    }
  }

  // Escalações reais (e última escalação conhecida de cada time para a "prevista")
  for (const roster of summary.rosters ?? []) {
    const starters = (roster.roster ?? []).filter((p) => p.starter);
    if (starters.length < 7) continue;
    const teamId = roster.team.id === homeExt ? homeId : awayId;
    const players = starters
      .sort((a, b) => Number(a.formationPlace ?? 99) - Number(b.formationPlace ?? 99))
      .map((p) => ({
        name: p.athlete?.displayName ?? p.athlete?.shortName ?? "Jogador",
        number: Number(p.jersey) || 0,
        pos: (p.position?.abbreviation ?? "").replace(/-.*/, "") || "MEI",
        rating: "",
        status: "Titular",
      }));
    const formation = roster.formation ?? "4-3-3";
    const [existingMatchLineup] = await db.select({ id: lineups.id }).from(lineups).where(and(eq(lineups.matchId, matchId), eq(lineups.teamId, teamId))).limit(1);
    const payload = { formation, players, confidence: 100, source: "Escalação oficial · ESPN", updatedAt: new Date() };
    if (existingMatchLineup) await db.update(lineups).set(payload).where(eq(lineups.id, existingMatchLineup.id));
    else {
      await db.insert(lineups).values({ matchId, teamId, ...payload });
      const teamName = teamId === homeId ? homeName : awayName;
      emitirEvento({ type: "lineup", teamId, matchId, detail: `${formation} · ${players.slice(0, 11).map((p) => p.name.split(" ").slice(-1)[0]).join(", ")}` });
    }

    const [teamLineup] = await db.select({ id: lineups.id }).from(lineups).where(and(eq(lineups.teamId, teamId), sql`${lineups.matchId} is null`)).limit(1);
    const predicted = { formation, players, confidence: 82, source: `Escalação prevista · baseada na última escalação oficial (${homeName} x ${awayName})`, updatedAt: new Date() };
    if (teamLineup) await db.update(lineups).set(predicted).where(eq(lineups.id, teamLineup.id));
    else await db.insert(lineups).values({ teamId, matchId: null, ...predicted });
    await db.update(teams).set({ formation }).where(eq(teams.id, teamId));
  }
}

/** Recalcula médias reais do time a partir das partidas encerradas sincronizadas. */
async function refreshTeamAverages(teamId: number) {
  const [row] = await db
    .select({
      sample: sql<number>`count(*)`,
      possession: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homePossession} else ${matches.awayPossession} end)`,
      shots: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeShots} else ${matches.awayShots} end)`,
      sot: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeShotsOnTarget} else ${matches.awayShotsOnTarget} end)`,
      corners: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeCorners} else ${matches.awayCorners} end)`,
      cards: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeCards} else ${matches.awayCards} end)`,
      fouls: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeFouls} else ${matches.awayFouls} end)`,
      offsides: sql<number>`avg(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeOffsides} else ${matches.awayOffsides} end)`,
      over25: sql<number>`avg(case when ${matches.homeScore} + ${matches.awayScore} > 2 then 100 else 0 end)`,
      btts: sql<number>`avg(case when ${matches.homeScore} > 0 and ${matches.awayScore} > 0 then 100 else 0 end)`,
      cleanSheets: sql<number>`sum(case when (${matches.homeTeamId} = ${teamId} and ${matches.awayScore} = 0) or (${matches.awayTeamId} = ${teamId} and ${matches.homeScore} = 0) then 1 else 0 end)`,
      goalsFor: sql<number>`sum(case when ${matches.homeTeamId} = ${teamId} then ${matches.homeScore} else ${matches.awayScore} end)`,
      goalsAgainst: sql<number>`sum(case when ${matches.homeTeamId} = ${teamId} then ${matches.awayScore} else ${matches.homeScore} end)`,
    })
    .from(matches)
    .where(and(eq(matches.source, "espn"), eq(matches.status, "finished"), sql`(${matches.homeTeamId} = ${teamId} or ${matches.awayTeamId} = ${teamId})`, sql`${matches.homeShots} + ${matches.awayShots} > 0`));
  const sample = Number(row?.sample ?? 0);
  if (!sample) return;
  const r = (v: unknown) => Math.round(Number(v ?? 0));
  await db
    .update(teams)
    .set({
      statsSample: sample,
      avgPossession: r(row.possession),
      avgShots: r(row.shots),
      avgShotsOnTarget: r(row.sot),
      avgCorners: r(row.corners),
      avgCards: r(row.cards),
      avgFouls: r(row.fouls),
      avgOffsides: r(row.offsides),
      over25Rate: r(row.over25),
      bttsRate: r(row.btts),
      cleanSheets: r(row.cleanSheets),
    })
    .where(eq(teams.id, teamId));
}

const prevShotsMap = new Map<string, { home: number; away: number }>();

async function processEvent(event: EspnEvent, code: string, previous: Map<string, Snapshot>) {
  const def = ESPN_LEAGUES.find((l) => l.code === code)!;
  const comp = event.competitions[0];
  const home = comp.competitors.find((c) => c.homeAway === "home");
  const away = comp.competitors.find((c) => c.homeAway === "away");
  if (!home || !away) return null;
  const leagueId = await upsertLeague(code);
  const homeId = await upsertTeam(home, leagueId, def.country);
  const awayId = await upsertTeam(away, leagueId, def.country);
  const { status, minute } = mapStatus(event);
  const homeScore = Number(home.score ?? 0) || 0;
  const awayScore = Number(away.score ?? 0) || 0;
  const odds = comp.odds?.[0];
  const round = comp.notes?.[0]?.headline ?? (event.week?.number ? `Rodada ${event.week.number}` : def.name);
  const values = {
    leagueId,
    leagueCode: code,
    homeTeamId: homeId,
    awayTeamId: awayId,
    kickoff: new Date(event.date),
    status,
    minute,
    round,
    venue: comp.venue?.fullName ?? "",
    homeScore,
    awayScore,
    externalId: event.id,
    source: "espn",
    oddsDetails: odds?.details ?? "",
    overUnder: odds?.overUnder ? String(odds.overUnder) : "",
    statusDetail: event.status.type.shortDetail ?? "",
    updatedAt: new Date(),
  };
  const prev = previous.get(event.id);
  const prevShots = { home: prev ? prevShotsMap.get(event.id)?.home ?? 0 : 0, away: prev ? prevShotsMap.get(event.id)?.away ?? 0 : 0 };
  let matchId: number;
  if (prev) {
    await db.update(matches).set(values).where(eq(matches.id, prev.id));
    matchId = prev.id;
  } else {
    const [created] = await db.insert(matches).values(values).returning({ id: matches.id });
    matchId = created.id;
  }

  // Estatísticas rápidas do placar (sem summary) para jogos ao vivo/encerrados
  const hs = home.statistics;
  const as = away.statistics;
  if (status !== "scheduled" && (hs?.length || as?.length)) {
    await db
      .update(matches)
      .set({
        homeCorners: statNumber(hs, "wonCorners") ?? 0,
        awayCorners: statNumber(as, "wonCorners") ?? 0,
        homeFouls: statNumber(hs, "foulsCommitted") ?? 0,
        awayFouls: statNumber(as, "foulsCommitted") ?? 0,
        homeShots: statNumber(hs, "totalShots") ?? 0,
        awayShots: statNumber(as, "totalShots") ?? 0,
        homeShotsOnTarget: statNumber(hs, "shotsOnTarget") ?? 0,
        awayShotsOnTarget: statNumber(as, "shotsOnTarget") ?? 0,
        homePossession: Math.round(statNumber(hs, "possessionPct") ?? 50),
        awayPossession: Math.round(statNumber(as, "possessionPct") ?? 50),
      })
      .where(eq(matches.id, matchId));
  }

  const kickoffMs = new Date(event.date).getTime();
  const soon = status === "scheduled" && kickoffMs - Date.now() < 75 * 60 * 1000;
  const recentlyFinished = status === "finished" && Date.now() - kickoffMs < 6 * 60 * 60 * 1000;
  if (status === "live" || soon || recentlyFinished || (status === "finished" && !prev)) {
    await syncSummary(event, code, matchId, home.team.id, away.team.id, homeId, awayId, home.team.displayName, away.team.displayName);
  }
  if (status === "finished" && (!prev || prev.status !== "finished")) {
    await refreshTeamAverages(homeId);
    await refreshTeamAverages(awayId);
  }

  // Notificações para quem favoritou os times
  const [fresh] = await db.select({ homeCorners: matches.homeCorners, awayCorners: matches.awayCorners, homeCards: matches.homeCards, awayCards: matches.awayCards, homeOffsides: matches.homeOffsides, awayOffsides: matches.awayOffsides, homeFouls: matches.homeFouls, awayFouls: matches.awayFouls, homeShots: matches.homeShots, awayShots: matches.awayShots }).from(matches).where(eq(matches.id, matchId));
  if (prev && fresh) {
    const label = `${home.team.abbreviation ?? home.team.displayName} ${homeScore} x ${awayScore} ${away.team.abbreviation ?? away.team.displayName}`;
    const sides: { teamId: number; name: string; side: "home" | "away" }[] = [
      { teamId: homeId, name: home.team.displayName, side: "home" },
      { teamId: awayId, name: away.team.displayName, side: "away" },
    ];
    for (const s of sides) {
      const score = { home: homeScore, away: awayScore, homeName: home.team.displayName, awayName: away.team.displayName, homeShort: home.team.abbreviation, awayShort: away.team.abbreviation };
      const base = { teamId: s.teamId, matchId, minute, score };
      const scoreNow = s.side === "home" ? homeScore : awayScore;
      const scorePrev = s.side === "home" ? prev.homeScore : prev.awayScore;
      if (scoreNow > scorePrev) {
        const lastGoal = await db.select({ player: matchEvents.player, type: matchEvents.type }).from(matchEvents).where(and(eq(matchEvents.matchId, matchId), eq(matchEvents.side, s.side), inArray(matchEvents.type, ["goal", "penalty"]))).orderBy(desc(matchEvents.minute), desc(matchEvents.id)).limit(1);
        emitirEvento({ ...base, type: lastGoal[0]?.type === "penalty" ? "penalty" : "goal", player: lastGoal[0]?.player || undefined });
      }
      const cornersNow = s.side === "home" ? fresh.homeCorners : fresh.awayCorners;
      const cornersPrev = s.side === "home" ? prev.homeCorners : prev.awayCorners;
      for (let i = cornersPrev; i < cornersNow; i++) emitirEvento({ ...base, type: "corner" });
      const cardsNow = s.side === "home" ? fresh.homeCards : fresh.awayCards;
      const cardsPrev = s.side === "home" ? prev.homeCards : prev.awayCards;
      if (cardsNow > cardsPrev) {
        const lastCard = await db.select({ player: matchEvents.player, type: matchEvents.type }).from(matchEvents).where(and(eq(matchEvents.matchId, matchId), eq(matchEvents.side, s.side), inArray(matchEvents.type, ["yellow", "red"]))).orderBy(desc(matchEvents.minute), desc(matchEvents.id)).limit(1);
        emitirEvento({ ...base, type: lastCard[0]?.type === "red" ? "redCard" : "yellowCard", player: lastCard[0]?.player || undefined });
      }
      const foulsNow = s.side === "home" ? fresh.homeFouls : fresh.awayFouls;
      const foulsPrev = s.side === "home" ? prev.homeFouls : prev.awayFouls;
      for (let i = foulsPrev; i < foulsNow; i++) emitirEvento({ ...base, type: "foul" });
      const shotsNow = s.side === "home" ? fresh.homeShots : fresh.awayShots;
      const shotsPrev = s.side === "home" ? prevShots.home : prevShots.away;
      for (let i = shotsPrev; i < shotsNow; i++) emitirEvento({ ...base, type: "shot" });
      const offNow = s.side === "home" ? fresh.homeOffsides : fresh.awayOffsides;
      const offPrev = s.side === "home" ? prev.homeOffsides : prev.awayOffsides;
      if (offNow > offPrev) await notifyFavorites(s.teamId, matchId, "offside", `🚫 Impedimento do ${s.name}`, `${label} · ${minute}'`);
      if (prev.status !== "live" && status === "live") emitirEvento({ ...base, type: "matchStart" });
      if (prev.status !== "finished" && status === "finished") emitirEvento({ ...base, type: "matchEnd" });
    }
  }
  if (fresh) prevShotsMap.set(event.id, { home: fresh.homeShots, away: fresh.awayShots });
  return { matchId, status };
}

/** Sincroniza ontem/hoje/amanhã de todas as competições (com trava de 45s). */
export async function syncEspn(force = false): Promise<SyncReport> {
  if (state.inFlight) return state.inFlight;
  if (!force && Date.now() - state.lastRun < MIN_INTERVAL_MS) {
    return { ok: true, message: "cache", matches: 0, live: 0, at: state.lastRun };
  }
  state.inFlight = (async () => {
    state.lastRun = Date.now();
    await db
      .insert(syncState)
      .values({ key: SYNC_KEY, lastRunAt: new Date() })
      .onConflictDoUpdate({ target: syncState.key, set: { lastRunAt: new Date() } });
    try {
      const days = [dayCode(-1), dayCode(0), dayCode(1)];
      const requests = ESPN_LEAGUES.flatMap((l) => days.map((d) => ({ code: l.code, url: `${BASE}/${l.code}/scoreboard?dates=${d}` })));
      const results = await Promise.all(requests.map(async (r) => ({ code: r.code, data: await fetchJson<{ events?: EspnEvent[] }>(r.url) })));
      const seen = new Set<string>();
      const events: { code: string; event: EspnEvent }[] = [];
      for (const r of results) {
        for (const event of r.data?.events ?? []) {
          if (seen.has(event.id)) continue;
          seen.add(event.id);
          events.push({ code: r.code, event });
        }
      }
      if (events.length === 0) {
        const message = "ESPN não retornou jogos (sem conexão ou indisponível)";
        await db.update(syncState).set({ lastMessage: message }).where(eq(syncState.key, SYNC_KEY));
        return { ok: false, message, matches: 0, live: 0, at: Date.now() };
      }
      const ids = [...seen];
      const existing = ids.length
        ? await db
            .select({ id: matches.id, externalId: matches.externalId, status: matches.status, homeScore: matches.homeScore, awayScore: matches.awayScore, homeCorners: matches.homeCorners, awayCorners: matches.awayCorners, homeCards: matches.homeCards, awayCards: matches.awayCards, homeOffsides: matches.homeOffsides, awayOffsides: matches.awayOffsides, homeFouls: matches.homeFouls, awayFouls: matches.awayFouls })
            .from(matches)
            .where(and(eq(matches.source, "espn"), inArray(matches.externalId, ids)))
        : [];
      const previous = new Map<string, Snapshot>(existing.map((m) => [m.externalId ?? "", { ...m, lineupNotified: false }]));

      let live = 0;
      // Processa sequencialmente em pequenos lotes para não sobrecarregar o banco/ESPN
      const batchSize = 6;
      for (let i = 0; i < events.length; i += batchSize) {
        const batch = events.slice(i, i + batchSize);
        const outcomes = await Promise.all(batch.map((item) => processEvent(item.event, item.code, previous).catch((error) => { console.error("espn event error", item.event.id, error); return null; })));
        live += outcomes.filter((o) => o?.status === "live").length;
      }

      // Remove dados de demonstração assim que existem jogos reais
      await db.delete(matches).where(eq(matches.source, "demo"));

      try {
        const { settlePredictions } = await import("@/lib/predict");
        await settlePredictions();
      } catch (error) {
        console.error("settle predictions", error);
      }
      const message = `${events.length} jogos sincronizados · ${live} ao vivo`;
      await db
        .update(syncState)
        .set({ lastSuccessAt: new Date(), lastMessage: message, matchesSynced: events.length })
        .where(eq(syncState.key, SYNC_KEY));
      return { ok: true, message, matches: events.length, live, at: Date.now() };
    } catch (error) {
      console.error("espn sync failed", error);
      const message = error instanceof Error ? error.message : "falha desconhecida";
      await db.update(syncState).set({ lastMessage: `Erro: ${message}` }).where(eq(syncState.key, SYNC_KEY)).catch(() => undefined);
      return { ok: false, message, matches: 0, live: 0, at: Date.now() };
    } finally {
      state.inFlight = null;
    }
  })();
  return state.inFlight;
}

export async function getSyncStatus() {
  const [row] = await db.select().from(syncState).where(eq(syncState.key, SYNC_KEY)).limit(1);
  return row ?? null;
}

/** Garante dados recentes sem bloquear a página por mais de alguns segundos. */
export async function ensureFreshData() {
  const status = await getSyncStatus().catch(() => null);
  const stale = !status?.lastSuccessAt || Date.now() - new Date(status.lastSuccessAt).getTime() > MIN_INTERVAL_MS;
  if (!stale) return;
  if (!status?.lastSuccessAt) {
    await syncEspn(true);
    return;
  }
  const timeout = new Promise<void>((resolve) => setTimeout(resolve, 2500));
  await Promise.race([syncEspn().then(() => undefined), timeout]);
}

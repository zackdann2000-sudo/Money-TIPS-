export function brl(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export const EVENT_META: Record<string, { label: string; icon: string; tone: string }> = {
  goal: { label: "Gol", icon: "⚽", tone: "text-emerald-500" },
  penalty: { label: "Pênalti", icon: "🥅", tone: "text-amber-500" },
  corner: { label: "Escanteio", icon: "🚩", tone: "text-sky-500" },
  yellow: { label: "Cartão amarelo", icon: "🟨", tone: "text-yellow-500" },
  red: { label: "Cartão vermelho", icon: "🟥", tone: "text-red-500" },
  card: { label: "Cartão", icon: "🟨", tone: "text-yellow-500" },
  favorite: { label: "Favorito", icon: "⭐", tone: "text-amber-500" },
  subscription: { label: "Conta", icon: "💎", tone: "text-emerald-500" },
  foul: { label: "Falta", icon: "✋", tone: "text-orange-500" },
  offside: { label: "Impedimento", icon: "🚫", tone: "text-violet-500" },
  sub: { label: "Substituição", icon: "🔁", tone: "text-slate-500" },
  var: { label: "VAR", icon: "📺", tone: "text-blue-500" },
  kickoff: { label: "Bola rolando", icon: "▶️", tone: "text-emerald-500" },
  end: { label: "Fim de jogo", icon: "⏱️", tone: "text-rose-500" },
  lineup: { label: "Escalação", icon: "📋", tone: "text-teal-500" },
};

export function eventMeta(type: string) {
  return EVENT_META[type] ?? { label: type, icon: "•", tone: "text-slate-500" };
}

export function statusLabel(status: string, minute: number) {
  if (status === "live") return minute > 45 && minute < 60 ? `INT ${minute}'` : `${minute}'`;
  if (status === "finished") return "ENC";
  return "AGENDADO";
}

export function statusTone(status: string) {
  if (status === "live") return "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400";
  if (status === "finished") return "bg-slate-500/10 text-slate-500 dark:text-slate-400";
  return "bg-sky-500/10 text-sky-600 dark:text-sky-400";
}

export function formLetters(form: string) {
  return form
    .toUpperCase()
    .split("")
    .slice(0, 5)
    .map((letter) => ({
      letter,
      label: letter === "V" ? "Vitória" : letter === "E" ? "Empate" : "Derrota",
      tone:
        letter === "V"
          ? "bg-emerald-500 text-white"
          : letter === "E"
            ? "bg-slate-400 text-white"
            : "bg-rose-500 text-white",
    }));
}

export const APP_TZ = "America/Sao_Paulo";

export function formatKickoff(date: Date | string, withDate = false) {
  const d = new Date(date);
  const time = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: APP_TZ });
  if (withDate) {
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", timeZone: APP_TZ }) + " · " + time;
  }
  return time;
}

export function dayKey(date: Date | string) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: APP_TZ, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date(date));
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function dayLabel(iso: string) {
  const date = new Date(`${iso}T12:00:00`);
  const now = Date.now();
  const todayKey = dayKey(new Date(now));
  const tomorrow = dayKey(new Date(now + 86400000));
  const yesterday = dayKey(new Date(now - 86400000));
  if (iso === todayKey) return "Hoje";
  if (iso === tomorrow) return "Amanhã";
  if (iso === yesterday) return "Ontem";
  return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

export function pct(part: number, total: number) {
  if (!total) return 0;
  return Math.round((part / total) * 100);
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

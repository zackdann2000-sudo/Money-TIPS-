/**
 * Configuração do OneSignal com proxy anti-bloqueador.
 *
 * ONESIGNAL_PROXY_BASE define de onde o SDK é servido:
 *  - ""  (padrão)  → proxy embutido no próprio site em /osproxy (mesmo domínio: bloqueadores não distinguem)
 *  - "https://onesignal-proxy.SEU-USUARIO.workers.dev" → Worker do Cloudflare (código em /cloudflare/onesignal-proxy)
 *
 * Em ambos os casos os arquivos são renomeados de OneSignalSDK* para TwoSignalSDK* (padrão do repo verificatorrus/onesignal-proxy).
 */
export const ONESIGNAL_APP_ID = "f06a705d-ebd0-4390-9a11-207fe769b81d";

/**
 * URL FIXA do site (a mesma que você cadastra em "Site URL" no painel do OneSignal).
 * Deixe vazio enquanto estiver no preview do E2B (o domínio muda); preencha com a URL do túnel/hospedagem
 * definitiva, ex.: "https://greenscore.seudominio.com" ou "https://app.greenscore.com.br".
 */
export const SITE_URL = "";

/** Seu Worker no Cloudflare (proxy passthrough de cdn.onesignal.com / onesignal.com). */
export const ONESIGNAL_WORKER = "https://frosty-disk-8a68.moneyiosates.workers.dev";

/**
 * De onde o NAVEGADOR carrega o SDK. Mantemos /osproxy (mesmo domínio do site) porque o Worker
 * entrega os arquivos sem reescrever as URLs internas (o loader ainda apontaria para cdn.onesignal.com).
 * O /osproxy busca os arquivos NO SEU WORKER (não no CDN) e faz a reescrita + renomeação TwoSignalSDK*.
 * Se um dia o Worker rodar o script completo do repo (com MYSUBDOMAIN), basta trocar para ONESIGNAL_WORKER.
 */
export const ONESIGNAL_PROXY_BASE = "";

export const proxyBase = (origin = "") => ONESIGNAL_PROXY_BASE || `${origin}/osproxy`;
export const SDK_PAGE_PATH = "/sdks/web/v16/TwoSignalSDK.page.js";
export const SDK_SW_PATH = "/sdks/web/v16/TwoSignalSDK.sw.js";
export const SERVICE_WORKER_FILE = "TwoSignalSDKWorker.js";

import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { apiIntegrations } from "@/db/schema";

/**
 * Football-Data.org v4 — camada de acesso segura (chave somente no servidor).
 * A chave é lida da tabela `api_integrations` (colada pelo dono no painel) ou de FOOTBALL_DATA_KEY.
 * Plano gratuito: 10 requisições/minuto · 12 competições (TIER_ONE).
 */
export const FD_BASE = "https://api.football-data.org/v4";
const TTL = { competitions: 6 * 60 * 60 * 1000, matches: 90 * 1000, standings: 15 * 60 * 1000, scorers: 30 * 60 * 1000, team: 6 * 60 * 60 * 1000 };

type CacheEntry = { at: number; ttl: number; data: unknown };
const cache = new Map<string, CacheEntry>();
const inflight = new Map<string, Promise<FdResult<unknown>>>();
const recent: number[] = []; // timestamps das últimas requisições (janela de 60s)
const MAX_PER_MINUTE = 9;

export type FdResult<T> = { ok: true; data: T; cached: boolean; remaining: number | null } | { ok: false; error: string; status?: number; retryAfter?: number };

export async function getFdKey(): Promise<{ key: string; integrationId: number | null; active: boolean } | null> {
  const [row] = await db
    .select({ id: apiIntegrations.id, apiKey: apiIntegrations.apiKey, isActive: apiIntegrations.isActive })
    .from(apiIntegrations)
    .where(and(eq(apiIntegrations.provider, "football-data"), sql`length(${apiIntegrations.apiKey}) > 0`))
    .orderBy(sql`${apiIntegrations.isActive} desc, ${apiIntegrations.id} asc`)
    .limit(1);
  if (row?.apiKey) return { key: row.apiKey, integrationId: row.id, active: row.isActive };
  const env = process.env.FOOTBALL_DATA_KEY;
  if (env) return { key: env, integrationId: null, active: true };
  return null;
}

function throttled() {
  const now = Date.now();
  while (recent.length && now - recent[0] > 60_000) recent.shift();
  return recent.length >= MAX_PER_MINUTE;
}

export async function fdFetch<T>(path: string, kind: keyof typeof TTL = "matches", opts: { force?: boolean } = {}): Promise<FdResult<T>> {
  const cached = cache.get(path);
  if (cached && !opts.force && Date.now() - cached.at < cached.ttl) return { ok: true, data: cached.data as T, cached: true, remaining: null };
  const running = inflight.get(path);
  if (running) return (await running) as FdResult<T>;
  const task = (async (): Promise<FdResult<T>> => {
    const cred = await getFdKey();
    if (!cred) return { ok: false, error: "Chave da Football-Data.org não configurada. Cole sua chave em Admin → APIs de dados." };
    if (!cred.active) return { ok: false, error: "Integração Football-Data.org está desativada no painel." };
    if (throttled()) {
      if (cached) return { ok: true, data: cached.data as T, cached: true, remaining: 0 };
      return { ok: false, error: "Limite do plano gratuito (10 req/min) atingido. Aguarde alguns segundos.", status: 429, retryAfter: 20 };
    }
    recent.push(Date.now());
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(`${FD_BASE}${path}`, { headers: { "X-Auth-Token": cred.key, Accept: "application/json" }, signal: controller.signal, cache: "no-store" });
      const remaining = Number(response.headers.get("x-requests-available-minute") ?? "") || null;
      const text = await response.text();
      if (!response.ok) {
        let message = `HTTP ${response.status}`;
        try { message = (JSON.parse(text) as { message?: string }).message ?? message; } catch { /* html */ }
        if (response.status === 403 && /restricted|subscription/i.test(message)) message = "Recurso fora do seu plano na Football-Data.org (TIER gratuito cobre 12 competições).";
        if (response.status === 429) message = "Limite de requisições da Football-Data atingido (10/min no plano gratuito).";
        if (response.status === 400 && /token/i.test(message)) message = "Chave da API inválida. Confira em Admin → APIs de dados.";
        if (cred.integrationId) await db.update(apiIntegrations).set({ status: response.status === 429 ? "connected" : "error", lastError: message, lastTestedAt: new Date(), requestsToday: sql`${apiIntegrations.requestsToday} + 1` }).where(eq(apiIntegrations.id, cred.integrationId)).catch(() => undefined);
        return { ok: false, error: message, status: response.status, retryAfter: Number(response.headers.get("x-requestcounter-reset") ?? "") || undefined };
      }
      const data = JSON.parse(text) as T;
      cache.set(path, { at: Date.now(), ttl: TTL[kind], data });
      if (cred.integrationId) await db.update(apiIntegrations).set({ status: "connected", lastError: "", lastSyncAt: new Date(), requestsToday: sql`${apiIntegrations.requestsToday} + 1` }).where(eq(apiIntegrations.id, cred.integrationId)).catch(() => undefined);
      return { ok: true, data, cached: false, remaining };
    } catch (error) {
      return { ok: false, error: error instanceof Error && error.name === "AbortError" ? "Tempo limite ao contatar a Football-Data (12s)." : "Falha de rede ao contatar a Football-Data." };
    } finally {
      clearTimeout(timer);
      inflight.delete(path);
    }
  })();
  inflight.set(path, task as Promise<FdResult<unknown>>);
  return task;
}

/* ------------------------------ Tipos públicos ------------------------------ */

export type FdCompetition = { id: number; code: string; name: string; type: string; emblem?: string; plan?: string; area: { name: string; code?: string; flag?: string }; currentSeason?: { id: number; startDate: string; endDate: string; currentMatchday?: number | null; winner?: { name: string } | null } | null; numberOfAvailableSeasons?: number; lastUpdated?: string };
export type FdMatch = {
  id: number; utcDate: string; status: string; matchday?: number | null; stage?: string; group?: string | null; minute?: number | null; venue?: string | null; lastUpdated?: string;
  competition: { id: number; code: string; name: string; emblem?: string };
  area?: { name: string; flag?: string };
  homeTeam: { id: number; name: string; shortName?: string; tla?: string; crest?: string };
  awayTeam: { id: number; name: string; shortName?: string; tla?: string; crest?: string };
  score: { winner?: string | null; duration?: string; fullTime: { home: number | null; away: number | null }; halfTime: { home: number | null; away: number | null } };
  referees?: { name: string; type?: string; nationality?: string }[];
};
export type FdStanding = { stage: string; type: string; group?: string | null; table: { position: number; team: { id: number; name: string; shortName?: string; tla?: string; crest?: string }; playedGames: number; form?: string | null; won: number; draw: number; lost: number; points: number; goalsFor: number; goalsAgainst: number; goalDifference: number }[] };
export type FdScorer = { player: { id: number; name: string; nationality?: string; position?: string | null; dateOfBirth?: string }; team: { id: number; name: string; shortName?: string; crest?: string }; playedMatches?: number; goals: number; assists?: number | null; penalties?: number | null };

export const FD_STATUS_PT: Record<string, string> = { SCHEDULED: "Agendado", TIMED: "Agendado", IN_PLAY: "Ao vivo", PAUSED: "Intervalo", FINISHED: "Encerrado", SUSPENDED: "Suspenso", POSTPONED: "Adiado", CANCELLED: "Cancelado", AWARDED: "W.O." };

export async function fdCompetitions() {
  return fdFetch<{ count: number; competitions: FdCompetition[] }>("/competitions?plan=TIER_ONE", "competitions");
}
export async function fdCompetition(code: string) {
  return fdFetch<FdCompetition & { seasons?: { id: number; startDate: string; endDate: string; currentMatchday?: number | null; winner?: { name: string } | null }[] }>(`/competitions/${encodeURIComponent(code)}`, "competitions");
}
export async function fdMatches(params: { dateFrom: string; dateTo: string; competitions?: string; status?: string }) {
  const q = new URLSearchParams({ dateFrom: params.dateFrom, dateTo: params.dateTo });
  if (params.competitions) q.set("competitions", params.competitions);
  if (params.status) q.set("status", params.status);
  return fdFetch<{ resultSet?: { count: number; played?: number; competitions?: string }; matches: FdMatch[] }>(`/matches?${q.toString()}`, "matches");
}
export async function fdCompetitionMatches(code: string, params: { matchday?: number; status?: string; season?: number; dateFrom?: string; dateTo?: string } = {}) {
  const q = new URLSearchParams();
  if (params.matchday) q.set("matchday", String(params.matchday));
  if (params.status) q.set("status", params.status);
  if (params.season) q.set("season", String(params.season));
  if (params.dateFrom) q.set("dateFrom", params.dateFrom);
  if (params.dateTo) q.set("dateTo", params.dateTo);
  const qs = q.toString();
  return fdFetch<{ resultSet?: { count: number }; matches: FdMatch[] }>(`/competitions/${encodeURIComponent(code)}/matches${qs ? `?${qs}` : ""}`, "matches");
}
export async function fdStandings(code: string, season?: number) {
  return fdFetch<{ season?: { currentMatchday?: number | null }; standings: FdStanding[] }>(`/competitions/${encodeURIComponent(code)}/standings${season ? `?season=${season}` : ""}`, "standings");
}
export async function fdScorers(code: string, limit = 20, season?: number) {
  const q = new URLSearchParams({ limit: String(limit) });
  if (season) q.set("season", String(season));
  return fdFetch<{ season?: { currentMatchday?: number | null }; scorers: FdScorer[] }>(`/competitions/${encodeURIComponent(code)}/scorers?${q.toString()}`, "scorers");
}
export async function fdMatch(id: number) {
  return fdFetch<FdMatch & { head2head?: { numberOfMatches: number; totalGoals: number; homeTeam: { wins: number; draws: number; losses: number }; awayTeam: { wins: number; draws: number; losses: number } } }>(`/matches/${id}`, "matches");
}

/** Testa a chave e devolve as competições liberadas para ela (usado em "Salvar e testar"). */
export async function fdProbe(key: string) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(`${FD_BASE}/competitions?plan=TIER_ONE`, { headers: { "X-Auth-Token": key, Accept: "application/json" }, signal: controller.signal, cache: "no-store" });
    const text = await response.text();
    if (!response.ok) {
      let message = `HTTP ${response.status}`;
      try { message = (JSON.parse(text) as { message?: string }).message ?? message; } catch { /* noop */ }
      return { ok: false as const, message };
    }
    const data = JSON.parse(text) as { count: number; competitions: FdCompetition[] };
    const remaining = response.headers.get("x-requests-available-minute");
    return { ok: true as const, message: `Chave válida · ${data.count} competições liberadas · ${remaining ?? "?"} requisições restantes neste minuto`, competitions: data.competitions };
  } catch {
    return { ok: false as const, message: "Não foi possível contatar a Football-Data.org." };
  } finally {
    clearTimeout(timer);
  }
}

export function fdDay(offset = 0) {
  const d = new Date(Date.now() + offset * 86400000);
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

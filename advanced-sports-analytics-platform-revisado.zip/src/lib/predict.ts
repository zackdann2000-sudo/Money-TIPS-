import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { matches, modelEvaluations, predictions, teams } from "@/db/schema";
import type { MatchRow } from "@/lib/data";
import { getHistoryState, headToHead, historyMeta, leagueDef, loadHistory, recentFor, standings, syncHistory, teamForm, teamRecentAnyCompetition, extraTeamNames, type TeamForm } from "@/lib/history";
import { backtest, brierMulti, FALLBACK_MODEL_VERSION, fitModel, lambdas, liveMarkets, logLoss, markets, MODEL_VERSION, outcomeOf, simpleLambdas, type FittedModel, type Markets } from "@/lib/model";

const modelCache = new Map<string, { model: FittedModel | null; at: number }>();
const MODEL_TTL = 10 * 60 * 1000;
const PRE_TTL = 6 * 60 * 60 * 1000;

async function fittedModel(code: string) {
  const cached = modelCache.get(code);
  if (cached && Date.now() - cached.at < MODEL_TTL) return cached.model;
  await syncHistory(code).catch(() => undefined);
  const history = await loadHistory(code);
  const model = fitModel(history);
  modelCache.set(code, { model, at: Date.now() });
  return model;
}

export type DataQuality = "alta" | "media" | "baixa" | "insuficiente";

/** Critérios objetivos de suficiência (não é "confiança" subjetiva). */
export function qualityFor(sampleHome: number, sampleAway: number, matchesUsed: number): DataQuality {
  const min = Math.min(sampleHome, sampleAway);
  if (min < 5 || matchesUsed < 40) return "insuficiente";
  if (min >= 15 && matchesUsed >= 150) return "alta";
  if (min >= 8) return "media";
  return "baixa";
}

export type Projection = { label: string; icon: string; home: number | null; away: number | null; total: number | null; range: [number, number] | null; sample: number; note: string };

/** Projeções de estatísticas a partir das médias REAIS acumuladas (tabela teams), sem estimativa quando não há amostra. */
async function statProjections(match: MatchRow): Promise<{ items: Projection[]; sampleNote: string }> {
  const rows = await db.select().from(teams).where(sql`${teams.id} in (${match.homeId}, ${match.awayId})`);
  const home = rows.find((t) => t.id === match.homeId);
  const away = rows.find((t) => t.id === match.awayId);
  const [leagueAvg] = await db
    .select({
      n: sql<number>`count(*)`,
      corners: sql<number>`avg(${matches.homeCorners} + ${matches.awayCorners})`,
      cards: sql<number>`avg(${matches.homeCards} + ${matches.awayCards})`,
      fouls: sql<number>`avg(${matches.homeFouls} + ${matches.awayFouls})`,
      shots: sql<number>`avg(${matches.homeShots} + ${matches.awayShots})`,
      sot: sql<number>`avg(${matches.homeShotsOnTarget} + ${matches.awayShotsOnTarget})`,
      offsides: sql<number>`avg(${matches.homeOffsides} + ${matches.awayOffsides})`,
    })
    .from(matches)
    .where(and(eq(matches.source, "espn"), eq(matches.status, "finished"), match.leagueId ? eq(matches.leagueId, match.leagueId) : undefined, sql`${matches.homeShots} + ${matches.awayShots} > 0`));
  const hs = home?.statsSample ?? 0, as = away?.statsSample ?? 0;
  const ln = Number(leagueAvg?.n ?? 0);
  const build = (label: string, icon: string, hv: number | undefined, av: number | undefined, lgTotal: number | null): Projection => {
    const sample = Math.min(hs, as);
    if (!home || !away || sample < 3) {
      return { label, icon, home: null, away: null, total: null, range: null, sample, note: sample ? `amostra insuficiente (${sample} jogo(s) com estatísticas)` : "sem jogos com estatísticas sincronizados para um dos times" };
    }
    // mistura: 70% média dos próprios times, 30% média da liga (quando existe), para reduzir ruído de amostras pequenas
    const h = hv ?? 0, a = av ?? 0;
    const own = h + a;
    const total = lgTotal && ln >= 10 ? 0.7 * own + 0.3 * lgTotal : own;
    const spread = Math.max(1, total * (sample >= 8 ? 0.22 : 0.35));
    return { label, icon, home: Math.round((total * (h / Math.max(0.01, own))) * 10) / 10, away: Math.round((total * (a / Math.max(0.01, own))) * 10) / 10, total: Math.round(total * 10) / 10, range: [Math.max(0, Math.round((total - spread) * 10) / 10), Math.round((total + spread) * 10) / 10], sample, note: `${sample} jogo(s) por time · incerteza ${sample >= 8 ? "moderada" : "alta"}` };
  };
  const items = [
    build("Escanteios", "🚩", home?.avgCorners, away?.avgCorners, Number(leagueAvg?.corners) || null),
    build("Cartões", "🟨", home?.avgCards, away?.avgCards, Number(leagueAvg?.cards) || null),
    build("Faltas", "✋", home?.avgFouls, away?.avgFouls, Number(leagueAvg?.fouls) || null),
    build("Finalizações", "🎯", home?.avgShots, away?.avgShots, Number(leagueAvg?.shots) || null),
    build("No alvo", "🥅", home?.avgShotsOnTarget, away?.avgShotsOnTarget, Number(leagueAvg?.sot) || null),
    build("Impedimentos", "🚫", home?.avgOffsides, away?.avgOffsides, Number(leagueAvg?.offsides) || null),
  ];
  const poss = home && away && Math.min(hs, as) >= 3 ? { label: "Posse de bola", icon: "⏱️", home: Math.round((home.avgPossession + (100 - away.avgPossession)) / 2), away: 100 - Math.round((home.avgPossession + (100 - away.avgPossession)) / 2), total: 100, range: null, sample: Math.min(hs, as), note: "média dos próprios jogos com estatísticas" } : { label: "Posse de bola", icon: "⏱️", home: null, away: null, total: null, range: null, sample: Math.min(hs, as), note: "amostra insuficiente" };
  items.push(poss);
  return { items, sampleNote: `Base: jogos reais com estatísticas sincronizados (${home?.name ?? "mandante"}: ${hs} · ${away?.name ?? "visitante"}: ${as} · liga: ${ln}). Cartões vermelhos: sem modelo (amostra insuficiente).` };
}

export type ModelType = "poisson_completo" | "fallback_simples" | "sem_dados";
type HistMatchLite = { date: Date; home: string; away: string; hg: number; ag: number; neutral?: boolean };

export type Analysis = {
  version: string;
  modelType: ModelType;
  modelLabel: string;
  quality: DataQuality;
  matchesUsed: number;
  asOf: Date;
  sampleHome: number;
  sampleAway: number;
  pre: Markets | null;
  live: Markets | null;
  ratings: { home: { attack: number; defense: number }; away: { attack: number; defense: number }; homeAdv: number; rho: number; leagueAvg: number } | null;
  form: { home5: TeamForm; home10: TeamForm; away5: TeamForm; away10: TeamForm; homeAtHome: TeamForm; awayAtAway: TeamForm } | null;
  h2h: ReturnType<typeof headToHead> | null;
  table: { home: ReturnType<typeof standings>[number] | null; away: ReturnType<typeof standings>[number] | null; size: number } | null;
  rest: { home: number | null; away: number | null };
  projections: { items: Projection[]; sampleNote: string };
  explanation: {
    resumo: string;
    mediasComparadas: { metrica: string; casa: string; fora: string; leitura: string }[];
    mercadosDestaque: { mercado: string; time: string; texto: string; acertos: number; total: number }[];
    alertasIncerteza: string[];
    mandante: string[];
    visitante: string[];
    fatores: { fator: string; impacto: string }[];
    cenarios: { titulo: string; p: number; texto: string }[];
    conclusao: string;
    indisponivel: string[];
    motor: string;
  };
  liveNote: string | null;
};

const pct = (v: number) => `${Math.round(v * 100)}%`;
const f1 = (v: number) => v.toFixed(2);

function describeForm(name: string, f: TeamForm, venueLabel: string) {
  if (!f.played) return `${name}: sem jogos ${venueLabel} na base.`;
  return `${name} ${venueLabel}: ${f.wins}V ${f.draws}E ${f.losses}D em ${f.played} jogos, ${f1(f.gf / f.played)} gol(s) marcado(s) e ${f1(f.ga / f.played)} sofrido(s) por jogo; marcou em ${f.scoredIn} e não sofreu gol em ${f.cleanSheets}.`;
}

type ExplainExtra = {
  mercados: { mercado: string; time: string; acertos: number; total: number; linha: number; periodo: string }[];
  teamStats: { home: { avgCorners: number; avgCards: number; avgFouls: number; avgShots: number; statsSample: number } | null; away: { avgCorners: number; avgCards: number; avgFouls: number; avgShots: number; statsSample: number } | null };
};

function buildExplanation(match: MatchRow, a: Omit<Analysis, "explanation">, extra: ExplainExtra = { mercados: [], teamStats: { home: null, away: null } }): Analysis["explanation"] {
  const indisponivel: string[] = [];
  const motor = process.env.OPENAI_API_KEY ? "Explicação redigida por IA de linguagem a partir dos números do modelo (sem alterar probabilidades)" : "Explicação gerada pelo motor de regras GreenScore a partir dos números calculados (sem modelo de linguagem configurado)";
  if (!a.pre || !a.form || !a.ratings) {
    return { resumo: `Análise em processamento. O histórico recente de ${match.homeName} x ${match.awayName} ainda está sendo indexado pelo modelo.`, mediasComparadas: [], mercadosDestaque: [], alertasIncerteza: ["Amostra insuficiente para projetar este confronto."], mandante: [], visitante: [], fatores: [], cenarios: [], conclusao: "As probabilidades aparecem automaticamente assim que houver partidas recentes dos dois times na base.", indisponivel: ["probabilidades", "placares", "projeções"], motor };
  }
  const { pre, form, ratings, h2h, table } = a;
  const hn = match.homeName, an = match.awayName;
  const fav = pre.home > pre.away ? "home" : "away";
  const favName = fav === "home" ? hn : an;
  const favP = Math.max(pre.home, pre.away);
  const edge = Math.abs(pre.home - pre.away);
  const resumo = `${hn} recebe ${an} ${table?.home && table?.away ? `(${table.home.rank}º x ${table.away.rank}º na tabela calculada de ${table.size} equipes)` : ""}. ${a.modelType === "fallback_simples" ? `Como uma das equipes tem poucos jogos nesta competição, o modelo simplificado usa a média de gols das últimas ${Math.max(a.sampleHome, a.sampleAway)} partidas gerais de cada time (todas as competições) e` : `O modelo, ajustado com ${a.matchesUsed} partidas ponderadas pelo tempo,`} projeta ${f1(pre.lambdaHome)} gol(s) esperado(s) para o mandante e ${f1(pre.lambdaAway)} para o visitante. ${edge < 0.1 ? "É um confronto equilibrado" : `${favName} aparece como favorito com ${pct(favP)}`}; o empate tem ${pct(pre.draw)}.`;

  const mandante: string[] = [describeForm(hn, form.home5, "nos últimos 5"), describeForm(hn, form.homeAtHome, "como mandante")];
  if (ratings.home.attack > 1.1) mandante.push(`Ataque ${Math.round((ratings.home.attack - 1) * 100)}% acima da média da liga segundo o rating do modelo.`);
  if (ratings.home.defense < 0.9) mandante.push(`Defesa sofre ${Math.round((1 - ratings.home.defense) * 100)}% menos gols do que a média (rating defensivo ${f1(ratings.home.defense)}).`);
  if (ratings.home.defense > 1.15) mandante.push(`Ponto fraco: defesa cede ${Math.round((ratings.home.defense - 1) * 100)}% mais gols que a média da liga.`);
  mandante.push(`Vantagem de mando estimada na competição: +${Math.round((ratings.homeAdv - 1) * 100)}% de gols para quem joga em casa.`);

  const visitante: string[] = [describeForm(an, form.away5, "nos últimos 5"), describeForm(an, form.awayAtAway, "como visitante")];
  if (ratings.away.attack > 1.1) visitante.push(`Ataque ${Math.round((ratings.away.attack - 1) * 100)}% acima da média da liga.`);
  if (ratings.away.defense < 0.9) visitante.push(`Defesa ${Math.round((1 - ratings.away.defense) * 100)}% melhor que a média — tende a segurar o placar baixo.`);
  if (ratings.away.defense > 1.15) visitante.push(`Fragilidade: defesa cede ${Math.round((ratings.away.defense - 1) * 100)}% mais gols que a média.`);

  const fatores: { fator: string; impacto: string }[] = [
    { fator: "Gols esperados (λ)", impacto: `${hn} ${f1(pre.lambdaHome)} · ${an} ${f1(pre.lambdaAway)} → base de todas as probabilidades` },
    ...(a.modelType === "fallback_simples"
      ? [{ fator: "Modelo simplificado", impacto: `média de gols marcados/sofridos nas últimas ${a.sampleHome}/${a.sampleAway} partidas gerais, com encolhimento para a média da liga` }]
      : [{ fator: "Ratings ataque/defesa", impacto: `${hn} ${f1(ratings.home.attack)}/${f1(ratings.home.defense)} · ${an} ${f1(ratings.away.attack)}/${f1(ratings.away.defense)} (1,00 = média da liga)` }]),
    { fator: "Mando de campo", impacto: `fator ${f1(ratings.homeAdv)} estimado nos jogos da competição` },
    { fator: "Forma recente (peso temporal)", impacto: `${hn} ${form.home5.sequence.join("")} · ${an} ${form.away5.sequence.join("")} — jogos recentes pesam mais (meia-vida 120 dias)` },
  ];
  if (h2h && h2h.n >= 3) fatores.push({ fator: "Confronto direto", impacto: `${h2h.n} jogos: ${h2h.aWins}V ${h2h.draws}E ${h2h.bWins}D para ${hn}; over 2,5 em ${h2h.over25}, ambos marcaram em ${h2h.btts}. Usado como contexto, não como regra.` });
  else indisponivel.push("histórico de confronto direto recente (menos de 3 jogos na base)");
  if (a.rest.home !== null && a.rest.away !== null && Math.abs(a.rest.home - a.rest.away) >= 2) fatores.push({ fator: "Descanso", impacto: `${hn} ${a.rest.home} dia(s) desde o último jogo · ${an} ${a.rest.away} dia(s)` });
  indisponivel.push("lesões e suspensões confirmadas (fonte não fornece)", "condições meteorológicas", "importância competitiva declarada");
  if (!a.projections.items.some((p) => p.total !== null)) indisponivel.push("projeções de escanteios/cartões/faltas (sem jogos com estatísticas para os dois times)");

  const top = pre.scorelines[0];
  const cenarios = [
    { titulo: `Vitória do ${hn}`, p: pre.home, texto: `Mais provável se o mandante confirmar a média ofensiva de ${f1(pre.lambdaHome)} gol(s). Placar mais provável nesse cenário: ${pre.scorelines.find((s) => Number(s.score.split("-")[0]) > Number(s.score.split("-")[1]))?.score ?? "1-0"}.` },
    { titulo: "Empate", p: pre.draw, texto: `Cenário sustentado por ${pre.under25 >= 0.5 ? "a tendência de poucos gols (under 2,5 em " + pct(pre.under25) + ")" : "o equilíbrio entre os ataques"}; ${pre.scorelines.find((s) => s.score.split("-")[0] === s.score.split("-")[1])?.score ?? "1-1"} é o empate mais provável.` },
    { titulo: `Vitória do ${an}`, p: pre.away, texto: `Depende de o visitante superar o fator casa (${f1(ratings.homeAdv)}); placar mais provável: ${pre.scorelines.find((s) => Number(s.score.split("-")[0]) < Number(s.score.split("-")[1]))?.score ?? "0-1"}.` },
  ].sort((x, y) => y.p - x.p);

  // --- Médias comparadas (Time A vs Time B) ---
  const g = (f: TeamForm) => (f.played ? f.gf / f.played : 0), c = (f: TeamForm) => (f.played ? f.ga / f.played : 0);
  const mediasComparadas: Analysis["explanation"]["mediasComparadas"] = [
    { metrica: "Gols marcados/jogo (últimos 10)", casa: f1(g(form.home10)), fora: f1(g(form.away10)), leitura: g(form.home10) > g(form.away10) + 0.3 ? `${hn} produz mais` : g(form.away10) > g(form.home10) + 0.3 ? `${an} produz mais` : "ataques parecidos" },
    { metrica: "Gols sofridos/jogo (últimos 10)", casa: f1(c(form.home10)), fora: f1(c(form.away10)), leitura: c(form.home10) < c(form.away10) - 0.3 ? `${hn} defende melhor` : c(form.away10) < c(form.home10) - 0.3 ? `${an} defende melhor` : "defesas parecidas" },
    { metrica: "Jogos sem sofrer gol (últimos 10)", casa: `${form.home10.cleanSheets}/${form.home10.played}`, fora: `${form.away10.cleanSheets}/${form.away10.played}`, leitura: form.home10.cleanSheets > form.away10.cleanSheets ? `${hn} mais sólido` : form.away10.cleanSheets > form.home10.cleanSheets ? `${an} mais sólido` : "equilíbrio" },
    { metrica: "Marcou em (últimos 10)", casa: `${form.home10.scoredIn}/${form.home10.played}`, fora: `${form.away10.scoredIn}/${form.away10.played}`, leitura: "frequência com que balança a rede" },
  ];
  const ts = extra.teamStats;
  if (ts.home && ts.away && ts.home.statsSample >= 3 && ts.away.statsSample >= 3) {
    mediasComparadas.push(
      { metrica: "Escanteios/jogo", casa: String(ts.home.avgCorners), fora: String(ts.away.avgCorners), leitura: `amostra ${ts.home.statsSample}/${ts.away.statsSample} jogos com estatísticas` },
      { metrica: "Cartões/jogo", casa: String(ts.home.avgCards), fora: String(ts.away.avgCards), leitura: ts.home.avgCards + ts.away.avgCards >= 5 ? "jogo com tendência disciplinar alta" : "disciplina dentro da média" },
      { metrica: "Faltas/jogo", casa: String(ts.home.avgFouls), fora: String(ts.away.avgFouls), leitura: "" },
    );
  }
  // --- Mercados em destaque (≥7/10 nos últimos jogos reais) ---
  const mercadosDestaque: Analysis["explanation"]["mercadosDestaque"] = extra.mercados
    .filter((m) => m.total >= 5 && m.acertos / m.total >= 0.7)
    .sort((x, y) => y.acertos / y.total - x.acertos / x.total)
    .slice(0, 5)
    .map((m) => ({ mercado: `${m.mercado} +${m.linha}${m.periodo !== "Jogo todo" ? ` (${m.periodo})` : ""}`, time: m.time, acertos: m.acertos, total: m.total, texto: `A linha de ${m.linha} ${m.mercado.toLowerCase()}${m.periodo !== "Jogo todo" ? ` no ${m.periodo.toLowerCase()}` : ""} do ${m.time} ocorreu em ${m.acertos} de ${m.total} jogos.` }));
  // --- Alertas de incerteza ---
  const alertasIncerteza: string[] = [];
  const compName = match.leagueName ?? "competição";
  if (a.modelType === "fallback_simples") alertasIncerteza.push(`Atenção: pelo menos uma equipe tem poucos jogos registrados na ${compName}; o modelo usou as últimas partidas gerais (todas as competições), o que reduz a confiabilidade.`);
  if (a.sampleHome < 5) alertasIncerteza.push(`Atenção: ${hn} tem apenas ${a.sampleHome} jogo(s) registrado(s) na base usada, o que reduz a confiabilidade.`);
  if (a.sampleAway < 5) alertasIncerteza.push(`Atenção: ${an} tem apenas ${a.sampleAway} jogo(s) registrado(s) na base usada, o que reduz a confiabilidade.`);
  if (a.matchesUsed < 80 && a.modelType === "poisson_completo") alertasIncerteza.push(`A competição tem só ${a.matchesUsed} partidas na base — ratings ainda instáveis no início de temporada.`);
  if (!h2h || h2h.n < 3) alertasIncerteza.push("Pouco confronto direto recente: o histórico entre as equipes não pesou na projeção.");
  if (!ts.home || !ts.away || ts.home.statsSample < 3 || ts.away.statsSample < 3) alertasIncerteza.push("Médias de escanteios/cartões/faltas ainda não têm amostra mínima (3 jogos com estatísticas) para um dos times.");
  if (match.status === "live") alertasIncerteza.push("Jogo em andamento: as probabilidades ao vivo não consideram expulsões, lesões ou substituições.");

  const conclusao = `Cenário mais provável: ${cenarios[0].titulo} (${pct(cenarios[0].p)}), placar mais frequente ${top.score} (${pct(top.p)}). Over 2,5 em ${pct(pre.over25)} e ambos marcam em ${pct(pre.btts)}. Qualidade dos dados: ${a.quality} (${a.sampleHome}/${a.sampleAway} jogos por equipe). ${a.quality === "baixa" || a.quality === "insuficiente" ? "Amostra pequena: trate as probabilidades como indicativas." : "Nenhuma probabilidade é garantia — a incerteza é parte do futebol."}`;
  return { resumo, mediasComparadas, mercadosDestaque, alertasIncerteza, mandante, visitante, fatores, cenarios, conclusao, indisponivel, motor };
}

export async function analyzeMatch(match: MatchRow): Promise<Analysis> {
  const code = match.leagueCode;
  const def = leagueDef(code);
  const projections = await statProjections(match);
  const base: Omit<Analysis, "explanation"> = { version: MODEL_VERSION, modelType: "sem_dados", modelLabel: "Sem dados", quality: "insuficiente", matchesUsed: 0, asOf: new Date(), sampleHome: 0, sampleAway: 0, pre: null, live: null, ratings: null, form: null, h2h: null, table: null, rest: { home: null, away: null }, projections, liveNote: null };
  if (!def) return { ...base, explanation: buildExplanation(match, base) };

  const [homeTeam, awayTeam] = await Promise.all([
    db.select({ ext: teams.externalId }).from(teams).where(eq(teams.id, match.homeId)).limit(1),
    db.select({ ext: teams.externalId }).from(teams).where(eq(teams.id, match.awayId)).limit(1),
  ]);
  const homeExt = homeTeam[0]?.ext, awayExt = awayTeam[0]?.ext;
  const model = await fittedModel(code);
  const history = await loadHistory(code);
  const meta = await historyMeta(code);
  const state = await getHistoryState(code);
  if (!homeExt || !awayExt) return { ...base, matchesUsed: history.length, explanation: buildExplanation(match, base) };

  const rh = model?.teams.get(homeExt), ra = model?.teams.get(awayExt);
  const leagueSamples = { home: rh?.n ?? 0, away: ra?.n ?? 0 };
  const poissonOk = Boolean(model) && leagueSamples.home >= 5 && leagueSamples.away >= 5 && (model?.matchesUsed ?? 0) >= 40;

  let modelType: ModelType = "poisson_completo";
  let version = MODEL_VERSION;
  let sampleHome = leagueSamples.home, sampleAway = leagueSamples.away;
  let lh: number, la: number;
  let ratings: Analysis["ratings"] = null;
  let fallbackGames: { home: HistMatchLite[]; away: HistMatchLite[] } | null = null;

  if (poissonOk && model) {
    ({ lh, la } = lambdas(model, homeExt, awayExt));
    ratings = { home: { attack: rh?.attack ?? 1, defense: rh?.defense ?? 1 }, away: { attack: ra?.attack ?? 1, defense: ra?.defense ?? 1 }, homeAdv: model.homeAdv, rho: model.rho, leagueAvg: model.leagueAvgHome + model.leagueAvgAway };
  } else {
    // FALLBACK: média simples das últimas 10 partidas gerais de cada time (qualquer competição, temporada atual + anterior)
    modelType = "fallback_simples";
    version = FALLBACK_MODEL_VERSION;
    const before = new Date(match.kickoff.getTime() - 1);
    const [hg, ag] = await Promise.all([teamRecentAnyCompetition(homeExt, before, 10), teamRecentAnyCompetition(awayExt, before, 10)]);
    fallbackGames = { home: hg, away: ag };
    const simple = simpleLambdas({ homeGames: hg, awayGames: ag, homeExt, awayExt, leagueAvgGoals: model ? model.leagueAvgHome + model.leagueAvgAway : undefined, homeAdv: model?.homeAdv });
    lh = simple.lh; la = simple.la; sampleHome = simple.sampleHome; sampleAway = simple.sampleAway;
    ratings = { home: { attack: 1, defense: 1 }, away: { attack: 1, defense: 1 }, homeAdv: model?.homeAdv ?? 1.2, rho: 0, leagueAvg: model ? model.leagueAvgHome + model.leagueAvgAway : 2.7 };
    if (sampleHome < 3 || sampleAway < 3) modelType = "sem_dados";
  }
  const rho = modelType === "poisson_completo" && model ? model.rho : 0;
  const quality: DataQuality = modelType === "sem_dados" ? "insuficiente" : modelType === "fallback_simples" ? (Math.min(sampleHome, sampleAway) >= 8 ? "media" : "baixa") : qualityFor(sampleHome, sampleAway, model!.matchesUsed);
  const pre = modelType === "sem_dados" ? null : markets(lh!, la!, rho);
  const live = pre && match.status === "live" ? liveMarkets(lh!, la!, rho, match.minute, match.homeScore, match.awayScore) : null;
  const modelLabel = modelType === "poisson_completo" ? "Poisson/Dixon-Coles completo" : modelType === "fallback_simples" ? "Modelo Simplificado (média das últimas 10 partidas gerais)" : "Sem dados suficientes";
  const form = {
    home5: teamForm(history, homeExt, meta.names, 5), home10: teamForm(history, homeExt, meta.names, 10),
    away5: teamForm(history, awayExt, meta.names, 5), away10: teamForm(history, awayExt, meta.names, 10),
    homeAtHome: teamForm(history, homeExt, meta.names, 10, "home"), awayAtAway: teamForm(history, awayExt, meta.names, 10, "away"),
  };
  const h2h = headToHead(history, homeExt, awayExt, meta.names);
  const tableRows = standings(history, meta.latestSeason, meta.names, meta.seasonOf);
  const table = { home: tableRows.find((r) => r.team === homeExt) ?? null, away: tableRows.find((r) => r.team === awayExt) ?? null, size: tableRows.length };
  const [restH, restA] = await Promise.all([recentFor(homeExt, 30), recentFor(awayExt, 30)]);
  const days = (d?: Date) => (d ? Math.round((match.kickoff.getTime() - new Date(d).getTime()) / 86400000) : null);
  // No fallback, a forma exibida usa os jogos gerais (qualquer competição) para não mostrar "0 jogos"
  if (fallbackGames) {
    const names = new Map([...extraTeamNames, ...meta.names]);
    const all = [...fallbackGames.home, ...fallbackGames.away];
    const mk = (team: string, limit: number, venue?: "home" | "away") => teamForm(all, team, names, limit, venue);
    form.home5 = mk(homeExt, 5); form.home10 = mk(homeExt, 10); form.homeAtHome = mk(homeExt, 10, "home");
    form.away5 = mk(awayExt, 5); form.away10 = mk(awayExt, 10); form.awayAtAway = mk(awayExt, 10, "away");
  }
  const analysis: Omit<Analysis, "explanation"> = {
    ...base,
    version, modelType, modelLabel,
    quality, matchesUsed: model?.matchesUsed ?? history.length, asOf: state?.lastSuccessAt ? new Date(state.lastSuccessAt) : new Date(), sampleHome, sampleAway, pre, live,
    ratings,
    form, h2h, table,
    rest: { home: days(restH[0]?.date), away: days(restA[0]?.date) },
    liveNote: live ? `Probabilidades recalculadas com placar ${match.homeScore}-${match.awayScore} aos ${match.minute}′ (último dado recebido ${new Date(match.updatedAt ?? Date.now()).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" })}). Expulsões e substituições não entram no cálculo (a fonte não as fornece de forma estruturada em tempo real).` : null,
  };
  const extra = await buildExplainExtra(match).catch(() => ({ mercados: [], teamStats: { home: null, away: null } } as ExplainExtra));
  return { ...analysis, explanation: buildExplanation(match, analysis, extra) };
}

/** Mercados reais (últimos 10 jogos de cada time) e médias por time, para a narrativa. */
async function buildExplainExtra(match: MatchRow): Promise<ExplainExtra> {
  const { calcularOportunidades } = await import("@/lib/opportunities");
  const before = new Date(match.kickoff.getTime() - 1);
  const [oh, oa, rows] = await Promise.all([
    calcularOportunidades(match.homeId, true, before).catch(() => null),
    calcularOportunidades(match.awayId, false, before).catch(() => null),
    db.select({ id: teams.id, avgCorners: teams.avgCorners, avgCards: teams.avgCards, avgFouls: teams.avgFouls, avgShots: teams.avgShots, statsSample: teams.statsSample }).from(teams).where(sql`${teams.id} in (${match.homeId}, ${match.awayId})`),
  ]);
  const toM = (r: NonNullable<typeof oh>, time: string) => r.todosMercados.filter((m) => m.disponivel).map((m) => ({ mercado: m.mercado, time, acertos: m.acertos, total: m.totalJogos, linha: m.linha, periodo: m.periodo }));
  return {
    mercados: [...(oh ? toM(oh, match.homeName) : []), ...(oa ? toM(oa, match.awayName) : [])],
    teamStats: { home: rows.find((r) => r.id === match.homeId) ?? null, away: rows.find((r) => r.id === match.awayId) ?? null },
  };
}

/** Registra a previsão (pré-jogo: no máximo 1 a cada 6h antes do início; ao vivo: quando o minuto muda). */
export async function recordPrediction(match: MatchRow, analysis: Analysis) {
  if (!analysis.pre) return;
  const kind = match.status === "live" ? "live" : "pre";
  if (match.status === "finished") return;
  const mk = kind === "live" ? analysis.live! : analysis.pre;
  const [last] = await db
    .select({ id: predictions.id, createdAt: predictions.createdAt, minute: predictions.minute })
    .from(predictions)
    .where(and(eq(predictions.matchId, match.id), eq(predictions.kind, kind)))
    .orderBy(desc(predictions.createdAt))
    .limit(1);
  if (kind === "pre" && last && Date.now() - new Date(last.createdAt).getTime() < PRE_TTL) return;
  if (kind === "live" && last && last.minute === match.minute) return;
  await db.insert(predictions).values({
    matchId: match.id, matchExternalId: match.id ? String(match.id) : "", leagueCode: match.leagueCode, kind, modelVersion: analysis.version,
    dataAsOf: analysis.asOf, minute: match.minute, scoreAtPrediction: kind === "live" ? `${match.homeScore}-${match.awayScore}` : "",
    dataQuality: analysis.quality, sampleHome: analysis.sampleHome, sampleAway: analysis.sampleAway,
    probs: { home: mk.home, draw: mk.draw, away: mk.away, over05: mk.over05, over15: mk.over15, over25: mk.over25, under25: mk.under25, btts: mk.btts, homeScores: mk.homeScores, awayScores: mk.awayScores, lambdaHome: mk.lambdaHome, lambdaAway: mk.lambdaAway },
    scorelines: mk.scorelines,
    inputs: { ratings: analysis.ratings, matchesUsed: analysis.matchesUsed, rest: analysis.rest, h2hN: analysis.h2h?.n ?? 0, modelType: analysis.modelType },
    projections: { items: analysis.projections.items },
    explanation: { conclusao: analysis.explanation.conclusao },
  });
}

/** Liquida previsões de jogos encerrados calculando Brier e log loss por previsão. */
export async function settlePredictions() {
  const rows = await db
    .select({ p: predictions, hs: matches.homeScore, as: matches.awayScore, status: matches.status })
    .from(predictions)
    .innerJoin(matches, eq(matches.id, predictions.matchId))
    .where(and(eq(predictions.settled, false), eq(matches.status, "finished")))
    .limit(500);
  for (const row of rows) {
    const o = outcomeOf(row.hs, row.as);
    const p: [number, number, number] = [Number(row.p.probs.home ?? 0), Number(row.p.probs.draw ?? 0), Number(row.p.probs.away ?? 0)];
    await db.update(predictions).set({ settled: true, actualHome: row.hs, actualAway: row.as, brier: brierMulti(p, o).toFixed(4), logLoss: logLoss(p[o]).toFixed(4) }).where(eq(predictions.id, row.p.id));
  }
  return rows.length;
}

export async function predictionHistory(matchId: number) {
  return db.select().from(predictions).where(eq(predictions.matchId, matchId)).orderBy(desc(predictions.createdAt)).limit(12);
}

export async function runBacktest(code: string) {
  await syncHistory(code).catch(() => undefined);
  const history = await loadHistory(code);
  const result = backtest(history, { minPrior: Math.min(80, Math.floor(history.length * 0.3)) });
  if (!result) return null;
  await db.insert(modelEvaluations).values({ leagueCode: code, modelVersion: MODEL_VERSION, sampleSize: result.n, metrics: result });
  return result;
}

export async function latestEvaluations() {
  const rows = await db.select().from(modelEvaluations).orderBy(desc(modelEvaluations.runAt)).limit(200);
  const byLeague = new Map<string, typeof rows[number]>();
  for (const r of rows) if (!byLeague.has(r.leagueCode)) byLeague.set(r.leagueCode, r);
  return [...byLeague.values()];
}

/** Desempenho das previsões reais já liquidadas (fora do backtest). */
export async function livePerformance() {
  const rows = await db.select({ brier: predictions.brier, logLoss: predictions.logLoss, kind: predictions.kind, leagueCode: predictions.leagueCode, probs: predictions.probs, actualHome: predictions.actualHome, actualAway: predictions.actualAway }).from(predictions).where(eq(predictions.settled, true));
  const pre = rows.filter((r) => r.kind === "pre");
  const avg = (list: typeof rows, f: (r: typeof rows[number]) => number) => (list.length ? list.reduce((s, r) => s + f(r), 0) / list.length : null);
  let over = 0;
  for (const r of pre) {
    const o = (r.actualHome ?? 0) + (r.actualAway ?? 0) > 2 ? 1 : 0;
    over += Math.pow(Number(r.probs.over25 ?? 0) - o, 2);
  }
  return { n: pre.length, brier: avg(pre, (r) => Number(r.brier)), logLoss: avg(pre, (r) => Number(r.logLoss)), brierOver25: pre.length ? over / pre.length : null, liveN: rows.length - pre.length };
}

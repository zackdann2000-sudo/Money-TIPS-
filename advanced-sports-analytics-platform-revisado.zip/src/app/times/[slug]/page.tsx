import Link from "next/link";
import { notFound } from "next/navigation";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getTeamBySlug } from "@/lib/data";
import { FormPills, InsightCard, MatchRow, PremiumLock, SectionHeader, StatBar, TeamBadge } from "@/components/ui";
import { Collapse, LineupBoard } from "@/components/client";
import { FavoriteButton } from "@/components/favorites-context";
import { AlertBell } from "@/components/alert-bell";
import { formatKickoff } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function TeamPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getTeamBySlug(slug);
  if (!data) notFound();
  const { team, leagueName, leagueFlag, leagueSlug, recent, upcoming, lineup, insights, leagueTeams } = data;
  const isReal = team.source === "espn";
  const session = await getSessionUser();
  const info = session ? accessInfo(session) : null;
  const hasAccess = info?.active ?? false;
  const history = (team.recentGames ?? []).map((game, index) => {
    const [a, b] = game.score.split("-").map((n) => Number(n.trim()) || 0);
    return {
      id: `${team.slug}-${index}`,
      opponent: game.opponent,
      home: game.home,
      scored: a,
      conceded: b,
      result: game.result,
      date: game.date ? new Date(game.date) : null,
      competition: game.competition,
    };
  });
  const goalDiff = team.goalsFor - team.goalsAgainst;
  const winRate = team.played ? Math.round((team.wins / team.played) * 100) : 0;
  const cleanSheetRate = team.played ? Math.round((team.cleanSheets / team.played) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href="/times" className="chip">← Times</Link>
        <Link href={`/ligas/${leagueSlug ?? ""}`} className="chip">{leagueFlag} {leagueName}</Link>
      </div>

      <section className="card overflow-hidden">
        <div className="relative px-3 py-3.5 text-white" style={{ background: `linear-gradient(135deg, ${team.badgeColorAlt} 0%, ${team.badgeColor} 130%)` }}>
          <div className="pointer-events-none absolute inset-0 pitch opacity-20" />
          <div className="relative flex items-center gap-3">
            <TeamBadge name={team.name} color={team.badgeColor} colorAlt={team.badgeColorAlt} size={52} rounded="xl" logo={team.logo} />
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-lg font-black leading-tight">{team.name}</h1>
              <p className="text-[0.62rem] text-white/80">{[team.city, team.stadium].filter(Boolean).join(" · ") || team.country}</p>
              <p className="text-[0.6rem] text-white/70">{[team.coach ? `Téc. ${team.coach}` : null, `Formação ${team.formation}`, isReal ? "dados oficiais ESPN" : null].filter(Boolean).join(" · ")}</p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <FavoriteButton team={{ id: team.id, name: team.name, slug: team.slug, logo: team.logo, color: team.badgeColor }} className="!border-white/30 !bg-white/15 !text-white" />
              <AlertBell teamId={team.id} teamName={team.name} loggedIn={Boolean(session)} className="!border-white/30 !bg-white/15 !text-white" />
            </div>
          </div>
          <div className="relative mt-2.5 flex items-center gap-2 text-[0.6rem] font-semibold text-white/85">
            <FormPills form={team.form} />
            <span>{team.position ? `${team.position}º colocado · ` : ""}{team.played} jogos{team.statsSample ? ` · saldo ${goalDiff > 0 ? `+${goalDiff}` : goalDiff}` : ""}</span>
          </div>
        </div>
        <div className="grid grid-cols-4 divide-x divide-[var(--line)] text-center">
          {[
            { value: `${winRate}%`, label: "vitórias" },
            { value: team.draws, label: "empates" },
            { value: team.losses, label: "derrotas" },
            { value: team.statsSample ? `${cleanSheetRate}%` : "—", label: "sem sofrer" },
          ].map((item) => (
            <div key={item.label} className="px-1 py-2">
              <p className="text-[0.92rem] font-black tabular-nums leading-none">{item.value}</p>
              <p className="mt-0.5 text-[0.52rem] muted">{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card px-3 py-2.5">
        <p className="text-[0.78rem] leading-relaxed">{team.description}</p>
        {team.statsSample >= 3 ? (
          <div className="mt-2 flex flex-wrap gap-1.5">
            <span className="chip">⚽ {team.over25Rate}% over 2,5</span>
            <span className="chip">🤝 {team.bttsRate}% ambas marcam</span>
            <span className="chip">🚩 {team.avgCorners} escanteios</span>
            <span className="chip">🟨 {team.avgCards} cartões</span>
            <span className="chip">✋ {team.avgFouls} faltas</span>
            <span className="chip">🚫 {team.avgOffsides} impedimentos</span>
            <span className="chip">amostra: {team.statsSample} jogo(s)</span>
          </div>
        ) : (
          <p className="mt-2 text-[0.62rem] muted">As médias de escanteios, faltas, cartões e impedimentos são calculadas só com partidas reais sincronizadas e aparecem a partir de 3 jogos com estatísticas ({team.statsSample}/3 até agora).</p>
        )}
      </section>

      <section>
        <SectionHeader title="Desempenho médio" subtitle={team.statsSample >= 3 ? `Médias reais por partida · ${team.statsSample} jogos com estatísticas` : `Aguardando 3 partidas com estatísticas (${team.statsSample}/3)`} icon={<span>📊</span>} />
        {team.statsSample >= 3 ? <div className="card px-3 py-2">
          {[
            { label: "Posse de bola", home: team.avgPossession, away: 100 - team.avgPossession, suffix: "%", icon: "⏱️" },
            { label: "Finalizações", home: team.avgShots, away: 0, icon: "🎯" },
            { label: "No alvo", home: team.avgShotsOnTarget, away: 0, icon: "🥅" },
            { label: "Escanteios", home: team.avgCorners, away: 0, icon: "🚩" },
            { label: "Faltas", home: team.avgFouls, away: 0, icon: "✋" },
            { label: "Cartões", home: team.avgCards, away: 0, icon: "🟨" },
            { label: "Impedimentos", home: team.avgOffsides, away: 0, icon: "🚫" },
          ].map((stat) => <StatBar key={stat.label} {...stat} />)}
        </div> : <div className="card px-3 py-4 text-center text-[0.72rem] muted">Sem amostra suficiente ainda.</div>}
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section>
          <SectionHeader title="Últimos jogos" subtitle="Resultados oficiais recentes" icon={<span>🗓️</span>} />
          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {!history.length ? <div className="px-3 py-4 text-center text-[0.72rem] muted">Histórico disponível após a próxima partida do time ser sincronizada.</div> : null}
            {history.map((game) => (
              <div key={game.id} className="flex items-center gap-2 px-2.5 py-2">
                <span className={`flex h-5 w-5 items-center justify-center rounded-md text-[0.6rem] font-black text-white ${game.result === "V" ? "bg-emerald-500" : game.result === "E" ? "bg-slate-400" : "bg-rose-500"}`}>{game.result}</span>
                <span className="w-9 shrink-0 text-[0.55rem] muted">{game.home ? "casa" : "fora"}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.74rem] font-semibold">{game.opponent}</p>
                  <p className="text-[0.52rem] muted">{game.competition}{game.date ? ` · ${game.date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}` : ""}</p>
                </div>
                <span className="rounded-md bg-[var(--surface-3)] px-1.5 py-0.5 text-[0.7rem] font-black tabular-nums">{game.scored} - {game.conceded}</span>
              </div>
            ))}
          </div>
          {recent.length ? (
            <div className="mt-2 space-y-1.5">
              <p className="px-1 text-[0.6rem] font-bold uppercase tracking-wide muted">Partidas com estatísticas completas</p>
              {recent.map((match) => <MatchRow key={match.id} match={match} showStats={false} />)}
            </div>
          ) : null}
        </section>

        <section>
          <SectionHeader title="Próximos jogos" subtitle="Agenda do time" icon={<span>⏰</span>} />
          <div className="space-y-1.5">
            {upcoming.length ? upcoming.map((match) => <MatchRow key={match.id} match={match} showStats={false} />) : (
              <div className="card px-3 py-4 text-center text-[0.75rem] muted">Nenhum jogo agendado no momento.</div>
            )}
          </div>
          <div className="mt-2 card px-3 py-2.5">
            <p className="text-[0.7rem] font-bold">🔔 Alertas deste time</p>
            <p className="mt-0.5 text-[0.65rem] muted">Favoritando {team.name} você recebe notificações de gols, escanteios, faltas, impedimentos, pênaltis, fim de jogo e escalação prevista.</p>
            <div className="mt-2 flex justify-center"><FavoriteButton team={{ id: team.id, name: team.name, slug: team.slug, logo: team.logo, color: team.badgeColor }} /></div>
          </div>
        </section>
      </div>

      {team.externalId ? (
        <Link href={`/jogadores?liga=${["brasileirao","brasileirao-serie-b","copa-do-brasil","premier-league","laliga","serie-a","bundesliga","ligue-1","liga-portugal","champions","europa-league","libertadores","sul-americana","liga-argentina","mls","eredivisie"].includes(leagueSlug ?? "") ? { brasileirao: "bra.1", "brasileirao-serie-b": "bra.2", "copa-do-brasil": "bra.copa_do_brazil", "premier-league": "eng.1", laliga: "esp.1", "serie-a": "ita.1", bundesliga: "ger.1", "ligue-1": "fra.1", "liga-portugal": "por.1", champions: "uefa.champions", "europa-league": "uefa.europa", libertadores: "conmebol.libertadores", "sul-americana": "conmebol.sudamericana", "liga-argentina": "arg.1", mls: "usa.1", eredivisie: "ned.1" }[leagueSlug as string] : "bra.1"}&time=${team.externalId}&minJogos=1`} className="card card-hover flex items-center gap-2 px-3 py-2.5">
          <span className="text-lg">🏅</span>
          <span className="min-w-0 flex-1">
            <span className="block text-[0.8rem] font-extrabold">Estatísticas dos jogadores do {team.name}</span>
            <span className="block text-[0.62rem] muted">Gols, assistências, finalizações, faltas, cartões e impedimentos por atleta na temporada</span>
          </span>
          <span className="text-[0.7rem] font-bold text-[var(--brand)]">ver →</span>
        </Link>
      ) : null}

      <section>
        <SectionHeader title="Escalação prevista" subtitle={lineup?.source ?? "Baseada na última escalação oficial"} icon={<span>📋</span>} />
        {hasAccess && !lineup ? <div className="card px-3 py-4 text-center text-[0.72rem] muted">A escalação prevista aparece após a primeira partida do time com escalação oficial sincronizada.</div> : null}
        {hasAccess && lineup ? (
          <LineupBoard sides={[{ name: team.name, short: team.shortName, color: team.badgeColor, colorAlt: team.badgeColorAlt, formation: lineup.formation, confidence: lineup.confidence, source: lineup.source, players: lineup.players }]} />
        ) : !hasAccess ? (
          <PremiumLock title="Escalação prevista exclusiva VIP" description="Prováveis titulares, formação, dúvidas e notas projetadas. Libere com o dia grátis do Gmail ou assine o VIP." />
        ) : null}
      </section>

      <section>
        <SectionHeader title="Análises do time" subtitle="Oportunidades com base no desempenho" icon={<span>🧠</span>} />
        {hasAccess ? (
          <div className="grid gap-2 sm:grid-cols-2">
            {insights.length ? insights.map((insight) => <InsightCard key={insight.id} insight={insight} />) : (
              <div className="card px-3 py-4 text-[0.75rem] muted sm:col-span-2">As análises são geradas a partir dos jogos reais do time (ontem, hoje e amanhã).</div>
            )}
          </div>
        ) : (
          <PremiumLock title="Análises exclusivas VIP" description="Veja as oportunidades estatísticas deste time com confiança e odd de referência." />
        )}
      </section>

      <section>
        <SectionHeader title="Classificação" subtitle={leagueName ?? ""} icon={<span>🏆</span>} />
        <div className="card overflow-hidden">
          <div className="flex items-center gap-2 border-b px-2.5 py-1.5 text-[0.55rem] font-bold uppercase tracking-wide muted hairline">
            <span className="w-4">#</span><span className="flex-1">Time</span><span className="w-6 text-center">J</span><span className="w-6 text-center">V</span><span className="w-8 text-center">SG</span><span className="w-12 text-center">Forma</span>
          </div>
          {leagueTeams.map((row) => (
            <Link key={row.id} href={`/times/${row.slug}`} className={`flex items-center gap-2 border-b px-2.5 py-1.5 last:border-0 hairline ${row.id === team.id ? "bg-[var(--brand-soft)]" : ""}`}>
              <span className="w-4 text-[0.62rem] font-bold muted">{row.position}</span>
              <span className="flex flex-1 items-center gap-1.5 truncate text-[0.7rem] font-semibold"><TeamBadge name={row.name} color={row.color} colorAlt={row.colorAlt} size={18} logo={row.logo} />{row.name}</span>
              <span className="w-6 text-center text-[0.62rem] tabular-nums muted">{row.played}</span>
              <span className="w-6 text-center text-[0.62rem] tabular-nums muted">{row.wins}</span>
              <span className="w-8 text-center text-[0.62rem] font-bold tabular-nums">{row.goalsFor - row.goalsAgainst}</span>
              <span className="w-12"><FormPills form={row.form} /></span>
            </Link>
          ))}
        </div>
      </section>

      <Collapse title="Dados do clube e fontes">
        <div className="grid grid-cols-2 gap-2 text-[0.7rem]">
          <p><span className="muted">País:</span> {team.country}</p>
          <p><span className="muted">Competição:</span> {leagueName}</p>
          <p><span className="muted">Formação recente:</span> {team.formation}</p>
          <p><span className="muted">Campanha:</span> {team.wins}V {team.draws}E {team.losses}D</p>
          <p><span className="muted">Fonte:</span> {isReal ? "ESPN (oficial)" : "cadastro manual"}</p>
        </div>
        <p className="mt-2 text-[0.62rem] leading-relaxed muted">
          Resultados, forma e campanha vêm da ESPN. As médias por partida são calculadas somente com jogos reais encerrados sincronizados pelo
          GreenScore. A escalação prevista reproduz a última escalação oficial do time e é substituída pela oficial quando divulgada.
        </p>
      </Collapse>
      <p className="text-center text-[0.6rem] muted">Última atualização do perfil: {formatKickoff(new Date(), true)}</p>
    </div>
  );
}

import { TileRowSkeleton } from "@/components/skeletons";
export default function Loading() { return <div className="space-y-3"><div className="px-1"><div className="h-6 w-32 animate-pulse rounded-lg bg-[var(--surface-3)]" /></div><TileRowSkeleton count={8} /><TileRowSkeleton count={8} /></div>; }

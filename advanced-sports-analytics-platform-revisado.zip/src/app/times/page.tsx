import Link from "next/link";
import { getLeagues, getTeams } from "@/lib/data";
import { FormPills, SectionHeader, TeamBadge } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function TeamsPage({ searchParams }: { searchParams: Promise<{ liga?: string }> }) {
  const params = await searchParams;
  const [teams, leagues] = await Promise.all([getTeams(), getLeagues()]);
  const league = leagues.find((l) => l.slug === params.liga);
  const filtered = league ? teams.filter((row) => row.team.leagueId === league.id) : teams;

  return (
    <div className="space-y-4">
      <div className="px-1">
        <h1 className="text-xl font-black tracking-tight">Times</h1>
        <p className="text-[0.7rem] muted">Perfil completo: desempenho, últimos jogos, estatísticas e escalação prevista</p>
      </div>

      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3">
        <Link href="/times" className={`chip !py-1.5 ${!league ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>🌍 Todos</Link>
        {leagues.map((item) => (
          <Link key={item.id} href={`/times?liga=${item.slug}`} className={`chip !py-1.5 ${league?.id === item.id ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>
            {item.flag} {item.name}
          </Link>
        ))}
      </div>

      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map(({ team, leagueName, leagueFlag }) => (
          <Link key={team.id} href={`/times/${team.slug}`} className="card card-hover overflow-hidden">
            <div className="flex items-center gap-2 border-b px-3 py-2.5 hairline">
              <TeamBadge name={team.name} color={team.badgeColor} colorAlt={team.badgeColorAlt} size={34} logo={team.logo} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[0.85rem] font-extrabold">{team.name}</p>
                <p className="truncate text-[0.6rem] muted">{leagueFlag} {leagueName} · {team.country}</p>
              </div>
              {team.source === "espn" ? <span className="chip !border-emerald-500/30 !py-0 !text-emerald-500">ESPN</span> : null}
            </div>
            <div className="grid grid-cols-3 divide-x divide-[var(--line)] text-center">
              <div className="px-1 py-1.5">
                <p className="text-[0.8rem] font-black">{team.wins}V</p>
                <p className="text-[0.52rem] muted">{team.played} jogos</p>
              </div>
              <div className="px-1 py-1.5">
                <p className="text-[0.8rem] font-black">{team.draws}E {team.losses}D</p>
                <p className="text-[0.52rem] muted">campanha</p>
              </div>
              <div className="px-1 py-1.5">
                <p className="text-[0.8rem] font-black">{team.statsSample >= 3 ? team.avgCorners : "—"}</p>
                <p className="text-[0.52rem] muted">{team.statsSample >= 3 ? `escanteios/jogo (${team.statsSample} j)` : "escanteios/jogo"}</p>
              </div>
            </div>
            <div className="flex items-center justify-between border-t px-3 py-1.5 hairline">
              <FormPills form={team.form} />
              <span className="text-[0.55rem] font-bold muted">{team.statsSample >= 3 ? `${team.avgPossession}% posse · ${team.avgFouls} faltas/jogo` : `médias após 3 jogos com estatísticas (${team.statsSample}/3)`}</span>
            </div>
          </Link>
        ))}
      </div>

      <section className="card px-3 py-3">
        <SectionHeader title="O que você encontra no perfil do time" subtitle="Dados combinados de histórico e médias da temporada" />
        <div className="grid grid-cols-2 gap-1.5 text-[0.68rem] sm:grid-cols-3">
          {["Últimos 5 jogos", "Desempenho ofensivo", "Desempenho defensivo", "Escalação prevista", "Médias de cartões", "Médias de faltas", "Impedimentos", "Escanteios", "Análises do time"].map((item) => (
            <span key={item} className="rounded-lg bg-[var(--surface-3)] px-2 py-1.5 font-semibold">✓ {item}</span>
          ))}
        </div>
      </section>
    </div>
  );
}

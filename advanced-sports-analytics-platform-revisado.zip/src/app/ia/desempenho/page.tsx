import Link from "next/link";
import { runBacktestAction } from "@/app/actions";
import { getSessionUser } from "@/lib/auth";
import { ESPN_LEAGUES } from "@/lib/espn";
import { getHistoryState } from "@/lib/history";
import { HALF_LIFE_DAYS, MODEL_VERSION } from "@/lib/model";
import { latestEvaluations, livePerformance, settlePredictions } from "@/lib/predict";
import { SectionHeader, StatTile } from "@/components/ui";

export const dynamic = "force-dynamic";

const f = (v: number | null | undefined, d = 4) => (v === null || v === undefined ? "—" : v.toFixed(d));
const pct = (v: number | null | undefined) => (v === null || v === undefined ? "—" : `${(v * 100).toFixed(1)}%`);

export default async function PerformancePage({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const session = await getSessionUser();
  await settlePredictions().catch(() => 0);
  const [evals, live] = await Promise.all([latestEvaluations(), livePerformance()]);
  const states = await Promise.all(ESPN_LEAGUES.map(async (l) => ({ ...l, state: await getHistoryState(l.code) })));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><Link href="/ia" className="chip">← IA Analista</Link><span className="chip">{MODEL_VERSION}</span></div>
      <div className="px-1">
        <h1 className="text-xl font-black tracking-tight">Desempenho e metodologia do modelo</h1>
        <p className="text-[0.7rem] muted">Backtest temporal (o modelo só usa jogos anteriores à partida avaliada) e desempenho das previsões reais já liquidadas.</p>
      </div>
      {sp.ok ? <div className="card border-emerald-500/40 px-3 py-2 text-[0.72rem] font-semibold text-emerald-600 dark:text-emerald-400">✓ Backtest executado: {sp.ok}</div> : null}
      {sp.erro ? <div className="card border-rose-500/40 px-3 py-2 text-[0.72rem] font-semibold text-rose-500">Não foi possível executar: {sp.erro}</div> : null}

      <section>
        <SectionHeader title="Previsões reais liquidadas" subtitle="Previsões emitidas pelo site antes do jogo e comparadas com o resultado" icon={<span>🧾</span>} />
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <StatTile label="Previsões pré-jogo" value={live.n} hint={`${live.liveN} atualizações ao vivo`} icon="📌" />
          <StatTile label="Brier 1X2" value={f(live.brier)} hint="0 = perfeito · 0,667 = chute uniforme" icon="🎯" />
          <StatTile label="Log loss" value={f(live.logLoss)} hint="1,099 = chute uniforme" icon="📉" />
          <StatTile label="Brier over 2,5" value={f(live.brierOver25)} hint="0,25 = chute 50/50" icon="⚽" />
        </div>
        {live.n < 30 ? <p className="mt-1.5 text-[0.62rem] muted">Amostra ainda pequena ({live.n} jogos): os números acima ganham significado estatístico a partir de algumas dezenas de partidas. Não afirmamos "aprendizado automático": o modelo é reajustado com os novos resultados, e esta página mede se ele acerta.</p> : null}
      </section>

      <section>
        <SectionHeader title="Backtest por competição" subtitle="Modelo vs. referência ingênua (frequências 1X2 e over 2,5 observadas até a data de cada jogo)" icon={<span>📏</span>} />
        {evals.length === 0 ? <div className="card px-4 py-6 text-center text-[0.74rem] muted">Nenhum backtest registrado ainda. {session?.role === "admin" ? "Execute abaixo." : "O administrador pode executá-lo."}</div> : null}
        <div className="grid gap-2 lg:grid-cols-2">
          {evals.map((e) => {
            const m = e.metrics as { n: number; brier: number; logLoss: number; accuracy: number; brierOver25: number; baseline: { brier: number; logLoss: number; accuracy: number; brierOver25: number }; calibration: { range: string; n: number; predicted: number; observed: number }[] };
            const league = ESPN_LEAGUES.find((l) => l.code === e.leagueCode);
            const better = m.brier < m.baseline.brier;
            return (
              <div key={e.id} className="card px-3 py-3">
                <div className="flex items-center justify-between"><p className="text-[0.82rem] font-extrabold">{league?.flag} {league?.name ?? e.leagueCode}</p><span className={`chip ${better ? "!border-emerald-500/40 !text-emerald-500" : "!border-amber-500/40 !text-amber-500"}`}>{better ? "supera a referência" : "não supera a referência"}</span></div>
                <p className="text-[0.6rem] muted">{m.n} jogos avaliados · {new Date(e.runAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" })} · {e.modelVersion}</p>
                <table className="mt-2 w-full text-[0.66rem]">
                  <thead><tr className="muted"><th className="text-left font-semibold">Métrica</th><th className="text-right font-semibold">Modelo</th><th className="text-right font-semibold">Referência</th></tr></thead>
                  <tbody>
                    <tr><td>Brier 1X2 (menor é melhor)</td><td className="text-right font-bold tabular-nums">{f(m.brier)}</td><td className="text-right tabular-nums muted">{f(m.baseline.brier)}</td></tr>
                    <tr><td>Log loss 1X2</td><td className="text-right font-bold tabular-nums">{f(m.logLoss)}</td><td className="text-right tabular-nums muted">{f(m.baseline.logLoss)}</td></tr>
                    <tr><td>Acerto do favorito</td><td className="text-right font-bold tabular-nums">{pct(m.accuracy)}</td><td className="text-right tabular-nums muted">{pct(m.baseline.accuracy)}</td></tr>
                    <tr><td>Brier over 2,5</td><td className="text-right font-bold tabular-nums">{f(m.brierOver25)}</td><td className="text-right tabular-nums muted">{f(m.baseline.brierOver25)}</td></tr>
                  </tbody>
                </table>
                <p className="mt-2 text-[0.62rem] font-bold">Calibração (probabilidade do favorito do modelo)</p>
                <div className="mt-1 space-y-1">
                  {m.calibration.map((c) => (
                    <div key={c.range} className="flex items-center gap-2 text-[0.6rem]">
                      <span className="w-14 muted">{c.range}</span>
                      <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-[var(--surface-3)]"><div className="absolute inset-y-0 left-0 bg-sky-500/50" style={{ width: `${c.predicted * 100}%` }} /><div className="absolute inset-y-0 left-0 h-full border-r-2 border-emerald-500" style={{ width: `${c.observed * 100}%` }} /></div>
                      <span className="w-28 text-right tabular-nums">prev {Math.round(c.predicted * 100)}% · real {Math.round(c.observed * 100)}% (n={c.n})</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {session?.role === "admin" ? (
        <section className="card px-3 py-3">
          <p className="text-[0.78rem] font-extrabold">👑 Executar backtest (admin)</p>
          <p className="text-[0.62rem] muted">Baixa o histórico da liga (se necessário) e avalia o modelo jogo a jogo em ordem temporal. Leva de 2 a 10 segundos por liga.</p>
          <form action={runBacktestAction} className="mt-2 flex gap-1.5">
            <select name="liga" className="input !py-1.5 !text-[0.72rem]">{ESPN_LEAGUES.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name}</option>)}</select>
            <button className="btn btn-primary !px-3 !py-1.5 !text-[0.7rem]">Rodar backtest</button>
          </form>
          <div className="mt-2 flex flex-wrap gap-1">{states.map((s) => <span key={s.code} className={`chip !py-0 ${s.state?.lastSuccessAt ? "!border-emerald-500/30 !text-emerald-500" : ""}`} title={s.state?.lastMessage ?? "sem histórico"}>{s.flag} {s.state?.matchesSynced ?? 0}</span>)}</div>
        </section>
      ) : null}

      <section className="card px-3 py-3 text-[0.66rem] leading-relaxed">
        <p className="text-[0.78rem] font-extrabold">Metodologia</p>
        <p>• <b>Modelo:</b> Poisson bivariado com correção de Dixon-Coles (ρ ajustado por máxima verossimilhança em grade) para placares 0-0, 1-0, 0-1 e 1-1.</p>
        <p>• <b>Parâmetros:</b> rating de ataque e defesa por equipe (1,00 = média da liga), vantagem de mando estimada por competição e médias de gols da liga; ajuste iterativo multiplicativo com encolhimento (prior de 4 jogos) para equipes com pouca amostra.</p>
        <p>• <b>Ponderação temporal:</b> peso = 0,5^(dias/{HALF_LIFE_DAYS}); jogos recentes valem mais sem descartar a temporada.</p>
        <p>• <b>Mercados:</b> todos derivados da mesma matriz de placares (0–8 gols) — 1X2 soma 100%, over/under complementares, BTTS consistente.</p>
        <p>• <b>Ao vivo:</b> gols restantes ~ Poisson(λ × minutos restantes/90) somados ao placar atual; sem uso de expulsões/substituições (não estruturadas na fonte).</p>
        <p>• <b>Qualidade dos dados:</b> critério objetivo por amostra (alta ≥15 jogos/time e ≥150 na liga; média ≥8; baixa ≥5; abaixo disso não há previsão).</p>
        <p>• <b>Limitações:</b> sem lesões/suspensões confirmadas, sem escalação como variável do modelo, sem clima; projeções de estatísticas dependem de jogos com estatísticas já sincronizados.</p>
        <p>• <b>Fontes auditadas:</b> Football-Data.org (configurada sem token — oferece resultados e tabelas, não estatísticas por partida); ESPN (usada: resultados, calendário, estatísticas por jogo, escalações).</p>
      </section>
    </div>
  );
}

import Link from "next/link";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getMatches } from "@/lib/data";
import { getAnalysis } from "@/lib/analysis-cache";
import { ESPN_LEAGUES } from "@/lib/espn";
import { ModelBadge, ProbBar, QualityBadge } from "@/components/analysis";
import { TeamBadge } from "@/components/ui";
import { dayKey, dayLabel, formatKickoff } from "@/lib/utils";
import { LiveRefresher } from "@/components/client";

export const dynamic = "force-dynamic";

const pct = (v: number) => `${Math.round(v * 100)}%`;

export default async function AiPage({ searchParams }: { searchParams: Promise<{ liga?: string; dia?: string }> }) {
  const sp = await searchParams;
  const session = await getSessionUser();
  const hasAccess = session ? accessInfo(session).active : false;
  const all = (await getMatches()).filter((m) => m.source === "espn" && m.leagueCode);
  const today = dayKey(new Date());
  const dayFilter = sp.dia ?? "hoje";
  let list = all;
  if (sp.liga) list = list.filter((m) => m.leagueCode === sp.liga);
  if (dayFilter === "hoje") list = list.filter((m) => dayKey(m.kickoff) === today || m.status === "live");
  if (dayFilter === "amanha") list = list.filter((m) => dayKey(m.kickoff) === dayKey(new Date(Date.now() + 86400000)));
  if (dayFilter === "ontem") list = list.filter((m) => dayKey(m.kickoff) === dayKey(new Date(Date.now() - 86400000)));
  list = [...list.filter((m) => m.status === "live"), ...list.filter((m) => m.status === "scheduled"), ...list.filter((m) => m.status === "finished")].slice(0, 40);

  const analyses = await Promise.all(list.map(async (m) => ({ m, a: await getAnalysis(m).catch(() => null) })));
  const leaguesPresent = ESPN_LEAGUES.filter((l) => all.some((m) => m.leagueCode === l.code));
  const withModel = analyses.filter((x) => x.a?.pre).length;

  return (
    <div className="space-y-4">
      <section className="card relative overflow-hidden border-0 brand-gradient px-4 py-4 text-white">
        <div className="pointer-events-none absolute inset-0 pitch opacity-25" />
        <div className="relative">
          <span className="chip !border-white/25 !bg-white/15 !text-white">IA ANALISTA — INTELIGÊNCIA PREDITIVA</span>
          <h1 className="mt-1.5 text-xl font-black leading-tight">Análise individual de cada partida</h1>
          <p className="text-[0.72rem] text-emerald-50/85">Modelo Poisson/Dixon-Coles com ponderação temporal, ajustado por competição com resultados oficiais. {withModel} de {list.length} jogos listados já têm probabilidades (os demais entram automaticamente ao indexar o histórico).</p>
          <div className="mt-2 flex flex-wrap gap-1.5 text-[0.6rem] font-semibold">
            <span className="rounded-full bg-white/15 px-2 py-0.5">Fonte: ESPN</span>
            <span className="rounded-full bg-white/15 px-2 py-0.5">Histórico: temporada atual (+ anterior quando curta)</span>
            <Link href="/desempenho" className="rounded-full bg-white/25 px-2 py-0.5">📊 Track Record →</Link>
            <Link href="/ia/desempenho" className="rounded-full bg-white/15 px-2 py-0.5">📏 Backtest →</Link>
          </div>
        </div>
      </section>

      <div className="flex flex-wrap items-center gap-1.5">
        {[["ontem", "Ontem"], ["hoje", "📅 Hoje + ao vivo"], ["amanha", "Amanhã"], ["todos", "Todos"]].map(([k, l]) => (
          <Link key={k} href={`/ia?dia=${k}${sp.liga ? `&liga=${sp.liga}` : ""}`} className={`chip !px-3 !py-1.5 ${dayFilter === k ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}>{l}</Link>
        ))}
        <LiveRefresher intervalMs={60000} />
      </div>
      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3 lg:mx-0 lg:px-0">
        <Link href={`/ia?dia=${dayFilter}`} className={`chip !py-1 ${!sp.liga ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>🌍 Todas</Link>
        {leaguesPresent.map((l) => <Link key={l.code} href={`/ia?dia=${dayFilter}&liga=${l.code}`} className={`chip !py-1 ${sp.liga === l.code ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>{l.flag} {l.name}</Link>)}
      </div>

      {analyses.length === 0 ? <div className="card px-4 py-8 text-center text-[0.78rem] muted">Nenhuma partida para este filtro.</div> : null}
      <div className="grid gap-2 lg:grid-cols-2">
        {analyses.map(({ m, a }) => {
          const mk = a?.live ?? a?.pre ?? null;
          return (
            <div key={m.id} className="card overflow-hidden">
              <div className="flex items-center justify-between gap-2 border-b px-3 py-2 hairline">
                <span className="truncate text-[0.6rem] font-semibold muted">{m.leagueFlag} {m.leagueName} · {m.round} · {dayLabel(dayKey(m.kickoff))} {formatKickoff(m.kickoff)}</span>
                <span className={`chip !py-0 ${m.status === "live" ? "!border-emerald-500/40 !text-emerald-500" : ""}`}>{m.status === "live" ? <><span className="live-dot" /> {m.minute}′ · {m.homeScore}-{m.awayScore}</> : m.status === "finished" ? `ENC ${m.homeScore}-${m.awayScore}` : "agendado"}</span>
              </div>
              <div className="px-3 py-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex min-w-0 items-center gap-1.5 text-[0.8rem] font-bold"><TeamBadge name={m.homeName} color={m.homeColor} colorAlt={m.homeColorAlt} size={22} logo={m.homeLogo} /><span className="truncate">{m.homeName}</span></span>
                  <span className="text-[0.6rem] muted">vs</span>
                  <span className="flex min-w-0 items-center gap-1.5 text-[0.8rem] font-bold"><span className="truncate">{m.awayName}</span><TeamBadge name={m.awayName} color={m.awayColor} colorAlt={m.awayColorAlt} size={22} logo={m.awayLogo} /></span>
                </div>
                {mk && a ? (
                  <div className="mt-2 space-y-1.5">
                    <ProbBar m={mk} homeShort={m.homeShort} awayShort={m.awayShort} />
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="chip !py-0">λ {mk.lambdaHome.toFixed(2)} · {mk.lambdaAway.toFixed(2)}</span>
                      <span className="chip !py-0">+2,5: {pct(mk.over25)}</span>
                      <span className="chip !py-0">BTTS: {pct(mk.btts)}</span>
                      <span className="chip !py-0">placar {mk.scorelines[0].score} ({pct(mk.scorelines[0].p)})</span>
                      <ModelBadge modelType={a.modelType} version={a.version} />
                      <QualityBadge quality={a.quality} sampleHome={a.sampleHome} sampleAway={a.sampleAway} />
                    </div>
                    {a.live ? <p className="text-[0.58rem] text-emerald-600 dark:text-emerald-400">probabilidades atualizadas com o placar ao vivo · pré-jogo: {pct(a.pre!.home)}/{pct(a.pre!.draw)}/{pct(a.pre!.away)}</p> : null}
                  </div>
                ) : (
                  <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-[var(--surface-3)] px-2 py-1.5 text-[0.62rem] muted"><span>⏳</span>{a ? "Análise em processamento — o histórico recente deste confronto ainda está sendo indexado pelo modelo." : "Fonte temporariamente indisponível — tentaremos novamente em instantes."}</p>
                )}
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-[0.56rem] muted">dados de {a ? formatKickoff(a.asOf, true) : "—"}</span>
                  {!a || a.modelType === "sem_dados" ? (
                    <button type="button" disabled aria-disabled className="btn btn-ghost cursor-not-allowed !px-3 !py-1 !text-[0.66rem] opacity-60" title="O histórico deste confronto ainda está sendo indexado">⏳ Análise em breve</button>
                  ) : (
                    <Link href={`/jogos/${m.id}#ia`} className="btn btn-primary !px-3 !py-1 !text-[0.66rem]">{hasAccess ? "Ver análise completa →" : "Ver análise (prévia) →"}</Link>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <p className="px-1 text-[0.58rem] leading-relaxed muted">Probabilidades estimadas, não garantias. Pré-jogo e ao vivo são sempre apresentados separadamente; o horário dos dados está em cada cartão.</p>
    </div>
  );
}

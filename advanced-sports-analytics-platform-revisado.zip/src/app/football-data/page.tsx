import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { fdCompetitions, fdDay, fdMatches, fdScorers, fdStandings, FD_STATUS_PT, getFdKey, type FdCompetition, type FdMatch } from "@/lib/football-data";
import { SectionHeader, StatTile } from "@/components/ui";
import { LiveRefresher } from "@/components/client";

export const dynamic = "force-dynamic";

const TZ = "America/Sao_Paulo";
const time = (iso: string) => new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: TZ });
const date = (iso: string) => new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", timeZone: TZ });
const dateTime = (iso?: string) => (iso ? new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: TZ }) : "—");

function Crest({ src, name, size = 20 }: { src?: string; name: string; size?: number }) {
  if (!src) return <span className="inline-flex shrink-0 items-center justify-center rounded-full bg-[var(--surface-3)] text-[0.55rem] font-black" style={{ width: size, height: size }}>{name.slice(0, 2).toUpperCase()}</span>;
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={src} alt="" width={size} height={size} loading="lazy" className="shrink-0 object-contain" style={{ width: size, height: size }} />;
}

function StatusChip({ m }: { m: FdMatch }) {
  const live = m.status === "IN_PLAY" || m.status === "PAUSED";
  return <span className={`chip !py-0 ${live ? "!border-emerald-500/40 !bg-emerald-500/10 !text-emerald-500" : m.status === "FINISHED" ? "" : "!text-sky-500"}`}>{live ? <><span className="live-dot" /> {m.status === "PAUSED" ? "INT" : m.minute ? `${m.minute}′` : "ao vivo"}</> : m.status === "FINISHED" ? "ENC" : FD_STATUS_PT[m.status] ?? m.status}</span>;
}

function MatchLine({ m }: { m: FdMatch }) {
  const played = m.score.fullTime.home !== null;
  return (
    <div className="flex items-center gap-2 border-b px-2.5 py-2 last:border-0 hairline">
      <div className="w-12 shrink-0 text-center"><p className="text-[0.66rem] font-extrabold">{time(m.utcDate)}</p><p className="text-[0.5rem] muted">{date(m.utcDate)}</p></div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-1.5 text-[0.78rem] font-semibold"><Crest src={m.homeTeam.crest} name={m.homeTeam.name} /><span className="truncate">{m.homeTeam.name}</span></span><span className="w-5 text-center text-[0.85rem] font-extrabold tabular-nums">{played ? m.score.fullTime.home : "-"}</span></div>
        <div className="mt-0.5 flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-1.5 text-[0.78rem] font-semibold"><Crest src={m.awayTeam.crest} name={m.awayTeam.name} /><span className="truncate">{m.awayTeam.name}</span></span><span className="w-5 text-center text-[0.85rem] font-extrabold tabular-nums">{played ? m.score.fullTime.away : "-"}</span></div>
        <div className="mt-1 flex flex-wrap items-center gap-1 text-[0.55rem] muted">
          <StatusChip m={m} />
          <span>{m.competition.name}{m.matchday ? ` · rodada ${m.matchday}` : ""}{m.stage && m.stage !== "REGULAR_SEASON" ? ` · ${m.stage.replace(/_/g, " ").toLowerCase()}` : ""}</span>
          {played && m.score.halfTime.home !== null ? <span>· 1ºT {m.score.halfTime.home}-{m.score.halfTime.away}</span> : null}
          {m.referees?.[0] ? <span>· árb. {m.referees[0].name}</span> : null}
          {m.venue ? <span>· {m.venue}</span> : null}
        </div>
      </div>
    </div>
  );
}

export default async function FootballDataPage({ searchParams }: { searchParams: Promise<{ comp?: string; dia?: string; status?: string; aba?: string }> }) {
  const sp = await searchParams;
  const session = await getSessionUser();
  const cred = await getFdKey();
  const isAdmin = session?.role === "admin";

  if (!cred) {
    return (
      <div className="space-y-4">
        <Header />
        <div className="card border-amber-500/40 px-4 py-6 text-center">
          <p className="text-[0.95rem] font-extrabold">🔑 Chave da Football-Data.org ainda não configurada</p>
          <p className="mx-auto mt-1 max-w-md text-[0.72rem] muted">Cole sua chave no painel do proprietário. Ela fica guardada apenas no servidor e nunca é enviada ao navegador. Depois, esta página passa a listar competições, jogos, tabelas e artilheiros vindos da Football-Data.</p>
          {isAdmin ? <Link href="/admin/apis" className="btn btn-primary mt-3">Ir para Admin → APIs de dados</Link> : <p className="mt-2 text-[0.66rem] muted">Peça ao administrador para configurar a chave.</p>}
        </div>
      </div>
    );
  }

  const comps = await fdCompetitions();
  const list: FdCompetition[] = comps.ok ? comps.data.competitions : [];
  const selected = list.find((c) => c.code === sp.comp) ?? null;
  const dia = sp.dia ?? "hoje";
  const range = dia === "ontem" ? [fdDay(-1), fdDay(-1)] : dia === "amanha" ? [fdDay(1), fdDay(1)] : dia === "semana" ? [fdDay(0), fdDay(7)] : dia === "passada" ? [fdDay(-7), fdDay(-1)] : [fdDay(0), fdDay(0)];
  const aba = sp.aba ?? "jogos";

  const matchesRes = aba === "jogos" ? await fdMatches({ dateFrom: range[0], dateTo: range[1], competitions: selected ? String(selected.id) : undefined, status: sp.status || undefined }) : null;
  const standingsRes = aba === "tabela" && selected ? await fdStandings(selected.code) : null;
  const scorersRes = aba === "artilheiros" && selected ? await fdScorers(selected.code, 25) : null;

  const matches = matchesRes?.ok ? matchesRes.data.matches : [];
  const grouped = new Map<string, FdMatch[]>();
  for (const m of matches) grouped.set(m.competition.name, [...(grouped.get(m.competition.name) ?? []), m]);
  const live = matches.filter((m) => m.status === "IN_PLAY" || m.status === "PAUSED").length;
  const q = (extra: Record<string, string | undefined>) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries({ comp: sp.comp, dia, status: sp.status, aba, ...extra })) if (v) params.set(k, v);
    return `/football-data?${params.toString()}`;
  };

  return (
    <div className="space-y-4">
      <Header />
      <div className="flex flex-wrap items-center gap-1.5">
        <span className={`chip ${comps.ok ? "!border-emerald-500/30 !bg-emerald-500/10 !text-emerald-600 dark:!text-emerald-400" : "!border-rose-500/40 !text-rose-500"}`}>{comps.ok ? `✓ conectado · ${list.length} competições liberadas` : `⚠ ${comps.error}`}</span>
        <span className="chip">plano gratuito · 10 req/min · cache 90s</span>
        {matchesRes?.ok ? <span className="chip">{matchesRes.cached ? "resposta em cache" : "dados ao vivo da API"}{matchesRes.remaining !== null ? ` · ${matchesRes.remaining} req restantes/min` : ""}</span> : null}
        <LiveRefresher intervalMs={90000} />
      </div>

      <section className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <StatTile label="Competições" value={list.length} hint="liberadas na sua chave" icon="🏆" />
        <StatTile label="Jogos no período" value={matchesRes?.ok ? matches.length : "—"} hint={`${range[0]}${range[0] !== range[1] ? ` → ${range[1]}` : ""}`} icon="📅" />
        <StatTile label="Ao vivo" value={matchesRes?.ok ? live : "—"} hint="na Football-Data agora" icon="🔴" />
        <StatTile label="Fonte" value="FD.org" hint="football-data.org v4" icon="🔌" />
      </section>

      {!comps.ok ? <div className="card border-rose-500/40 px-3 py-3 text-[0.74rem]"><b className="text-rose-500">Falha ao listar competições:</b> {comps.error} {isAdmin ? <Link href="/admin/apis" className="font-bold text-[var(--brand)]">Verificar chave →</Link> : null}</div> : null}

      <section>
        <SectionHeader title="Competições disponíveis na sua chave" subtitle="Toque para filtrar — cada card mostra temporada e rodada atual" icon={<span>🏆</span>} />
        <div className="no-scrollbar -mx-3 flex gap-2 overflow-x-auto px-3 pb-1 lg:mx-0 lg:grid lg:grid-cols-4 lg:px-0">
          <Link href={q({ comp: undefined, aba: "jogos" })} className={`card card-hover min-w-[150px] px-3 py-2.5 ${!selected ? "border-emerald-500/50" : ""}`}><p className="text-[0.78rem] font-bold">🌍 Todas</p><p className="text-[0.55rem] muted">jogos de todas as competições</p></Link>
          {list.map((c) => (
            <Link key={c.id} href={q({ comp: c.code })} className={`card card-hover min-w-[170px] px-3 py-2.5 ${selected?.code === c.code ? "border-emerald-500/50 ring-1 ring-emerald-500/30" : ""}`}>
              <div className="flex items-center gap-2"><Crest src={c.emblem} name={c.name} size={24} /><div className="min-w-0"><p className="truncate text-[0.76rem] font-bold">{c.name}</p><p className="truncate text-[0.52rem] muted">{c.area.name} · {c.code} · {c.type === "LEAGUE" ? "liga" : "copa"}</p></div></div>
              <p className="mt-1 text-[0.52rem] muted">{c.currentSeason ? `${c.currentSeason.startDate.slice(0, 4)}/${c.currentSeason.endDate.slice(2, 4)}${c.currentSeason.currentMatchday ? ` · rodada ${c.currentSeason.currentMatchday}` : ""}` : "sem temporada ativa"}</p>
            </Link>
          ))}
        </div>
      </section>

      {selected ? (
        <div className="flex flex-wrap gap-1.5">
          {[["jogos", "📅 Jogos"], ["tabela", "📊 Classificação"], ["artilheiros", "⚽ Artilheiros"]].map(([k, l]) => <Link key={k} href={q({ aba: k })} className={`chip !px-3 !py-1.5 ${aba === k ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}>{l}</Link>)}
        </div>
      ) : null}

      {aba === "jogos" ? (
        <>
          <div className="flex flex-wrap gap-1.5">
            {[["ontem", "Ontem"], ["hoje", "📅 Hoje"], ["amanha", "Amanhã"], ["semana", "Próx. 7 dias"], ["passada", "Últimos 7 dias"]].map(([k, l]) => <Link key={k} href={q({ dia: k })} className={`chip !py-1.5 ${dia === k ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>{l}</Link>)}
            <span className="mx-1 hidden w-px bg-[var(--line)] sm:block" />
            {[["", "Todos status"], ["SCHEDULED,TIMED", "Agendados"], ["IN_PLAY,PAUSED", "Ao vivo"], ["FINISHED", "Encerrados"]].map(([k, l]) => <Link key={l} href={q({ status: k || undefined })} className={`chip !py-1.5 ${(sp.status ?? "") === k ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>{l}</Link>)}
          </div>
          {matchesRes && !matchesRes.ok ? <div className="card border-rose-500/40 px-3 py-3 text-[0.74rem]"><b className="text-rose-500">Erro:</b> {matchesRes.error}</div> : null}
          {matchesRes?.ok && matches.length === 0 ? <div className="card px-4 py-8 text-center text-[0.76rem] muted">Nenhum jogo{selected ? ` de ${selected.name}` : ""} neste período na Football-Data.</div> : null}
          {[...grouped.entries()].map(([name, list]) => (
            <section key={name}>
              <SectionHeader title={name} subtitle={`${list.length} jogo(s) · atualizado ${dateTime(list[0]?.lastUpdated)}`} />
              <div className="card overflow-hidden">{list.map((m) => <MatchLine key={m.id} m={m} />)}</div>
            </section>
          ))}
        </>
      ) : null}

      {aba === "tabela" && selected ? (
        standingsRes && !standingsRes.ok ? <div className="card border-rose-500/40 px-3 py-3 text-[0.74rem]"><b className="text-rose-500">Erro:</b> {standingsRes.error}</div> : standingsRes?.ok ? (
          standingsRes.data.standings.filter((s) => s.type === "TOTAL").map((s) => (
            <section key={`${s.stage}-${s.group ?? ""}`}>
              <SectionHeader title={`${selected.name}${s.group ? ` · ${s.group.replace(/_/g, " ")}` : ""}`} subtitle={`Classificação geral · rodada ${standingsRes.data.season?.currentMatchday ?? "—"}`} icon={<span>📊</span>} />
              <div className="card overflow-hidden">
                <div className="grid grid-cols-[1.4rem_1fr_1.6rem_1.6rem_1.6rem_1.6rem_2.6rem_2rem_2.6rem] items-center gap-1 border-b px-2.5 py-1.5 text-[0.52rem] font-bold uppercase tracking-wide muted hairline"><span>#</span><span>Time</span><span className="text-center">J</span><span className="text-center">V</span><span className="text-center">E</span><span className="text-center">D</span><span className="text-center">Gols</span><span className="text-center">SG</span><span className="text-right">Pts</span></div>
                {s.table.map((r) => (
                  <div key={r.team.id} className="grid grid-cols-[1.4rem_1fr_1.6rem_1.6rem_1.6rem_1.6rem_2.6rem_2rem_2.6rem] items-center gap-1 border-b px-2.5 py-1.5 text-[0.68rem] last:border-0 hairline">
                    <span className={`font-bold ${r.position <= 4 ? "text-emerald-500" : "muted"}`}>{r.position}</span>
                    <span className="flex min-w-0 items-center gap-1.5 font-semibold"><Crest src={r.team.crest} name={r.team.name} size={16} /><span className="truncate">{r.team.shortName ?? r.team.name}</span>{r.form ? <span className="ml-1 hidden gap-0.5 sm:flex">{r.form.split(",").map((f, i) => <span key={i} className={`h-3 w-3 rounded-sm ${f === "W" ? "bg-emerald-500" : f === "D" ? "bg-slate-400" : "bg-rose-500"}`} />)}</span> : null}</span>
                    <span className="text-center tabular-nums muted">{r.playedGames}</span><span className="text-center tabular-nums muted">{r.won}</span><span className="text-center tabular-nums muted">{r.draw}</span><span className="text-center tabular-nums muted">{r.lost}</span>
                    <span className="text-center tabular-nums muted">{r.goalsFor}:{r.goalsAgainst}</span><span className="text-center tabular-nums">{r.goalDifference > 0 ? `+${r.goalDifference}` : r.goalDifference}</span><span className="text-right font-black tabular-nums">{r.points}</span>
                  </div>
                ))}
              </div>
            </section>
          ))
        ) : null
      ) : null}

      {aba === "artilheiros" && selected ? (
        scorersRes && !scorersRes.ok ? <div className="card border-rose-500/40 px-3 py-3 text-[0.74rem]"><b className="text-rose-500">Erro:</b> {scorersRes.error}</div> : scorersRes?.ok ? (
          <section>
            <SectionHeader title={`Artilheiros · ${selected.name}`} subtitle="Gols, assistências e pênaltis segundo a Football-Data" icon={<span>⚽</span>} />
            <div className="card overflow-hidden">
              <div className="grid grid-cols-[1.4rem_1fr_2rem_2rem_2.4rem_2.4rem] items-center gap-1 border-b px-2.5 py-1.5 text-[0.52rem] font-bold uppercase tracking-wide muted hairline"><span>#</span><span>Jogador</span><span className="text-center">J</span><span className="text-center">G</span><span className="text-center">Ast</span><span className="text-center">Pên</span></div>
              {scorersRes.data.scorers.map((sc, i) => (
                <div key={sc.player.id} className={`grid grid-cols-[1.4rem_1fr_2rem_2rem_2.4rem_2.4rem] items-center gap-1 border-b px-2.5 py-1.5 text-[0.7rem] last:border-0 hairline ${i < 3 ? "bg-emerald-500/[0.04]" : ""}`}>
                  <span className={`font-black ${i < 3 ? "text-emerald-500" : "muted"}`}>{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</span>
                  <span className="flex min-w-0 items-center gap-1.5"><Crest src={sc.team.crest} name={sc.team.name} size={16} /><span className="min-w-0"><span className="block truncate font-bold">{sc.player.name}</span><span className="block truncate text-[0.52rem] muted">{sc.team.shortName ?? sc.team.name}{sc.player.nationality ? ` · ${sc.player.nationality}` : ""}{sc.player.position ? ` · ${sc.player.position}` : ""}</span></span></span>
                  <span className="text-center tabular-nums muted">{sc.playedMatches ?? "—"}</span><span className="text-center text-[0.85rem] font-black tabular-nums text-emerald-500">{sc.goals}</span><span className="text-center tabular-nums">{sc.assists ?? 0}</span><span className="text-center tabular-nums muted">{sc.penalties ?? 0}</span>
                </div>
              ))}
            </div>
          </section>
        ) : null
      ) : null}

      <section className="card px-3 py-2.5 text-[0.62rem] leading-relaxed muted">
        <p className="text-[0.74rem] font-bold text-[var(--ink)]">Sobre esta fonte</p>
        <p>• Football-Data.org (plano gratuito): 12 competições, resultados, calendário, classificação, artilheiros e árbitros; limite de 10 requisições por minuto (o site usa cache de 90 s para jogos, 15 min para tabelas e 30 min para artilheiros).</p>
        <p>• Não fornece estatísticas por partida (escanteios, faltas, finalizações) nem escalações — por isso a ESPN continua como fonte padrão do site; aqui você consulta e compara os dados da Football-Data lado a lado.</p>
        <p>• A chave fica no servidor (tabela de integrações); a página mostra apenas resultados.</p>
      </section>
    </div>
  );
}

function Header() {
  return (
    <section className="card relative overflow-hidden border-0 bg-gradient-to-br from-slate-800 via-slate-700 to-emerald-700 px-4 py-4 text-white">
      <div className="pointer-events-none absolute inset-0 pitch opacity-25" />
      <div className="relative">
        <span className="chip !border-white/25 !bg-white/15 !text-white">FONTE SECUNDÁRIA</span>
        <h1 className="mt-1.5 text-xl font-black leading-tight">Football-Data.org</h1>
        <p className="text-[0.72rem] text-emerald-50/85">Competições, jogos, classificação e artilheiros direto da API oficial da Football-Data — filtrados pela sua chave.</p>
      </div>
    </section>
  );
}

import Link from "next/link";
import { deleteNotificationAction, markAllReadAction, saveAlertPrefsAction } from "@/app/actions";
import { ALERT_OPTIONS, normalizePrefs } from "@/lib/alerts";
import { AlertSoundTools } from "@/components/client";
import { BrowserNotificationsButton } from "@/components/onesignal";
import { WebPushPanel } from "@/components/web-push";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getFavorites, getUserNotifications } from "@/lib/data";
import { AccessPill, EmptyState, SectionHeader, TeamBadge } from "@/components/ui";
import { eventMeta } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function NotificationsPage({ searchParams }: { searchParams: Promise<{ prefs?: string }> }) {
  const params = await searchParams;
  const session = await getSessionUser();
  if (!session) {
    return (
      <div className="space-y-4">
        <h1 className="px-1 text-xl font-black tracking-tight">Notificações</h1>
        <div className="card flex flex-col items-center gap-2 px-5 py-8 text-center">
          <span className="text-3xl">🔔</span>
          <p className="text-sm font-extrabold">Entre para ver seus alertas</p>
          <p className="max-w-xs text-[0.72rem] muted">Gols, escanteios, faltas, impedimentos, pênaltis, escalações e fim de jogo do seu time favorito.</p>
          <div className="mt-1 flex gap-2">
            <Link href="/login" className="btn btn-primary">Entrar</Link>
            <Link href="/cadastro" className="btn btn-ghost">Criar conta grátis</Link>
          </div>
        </div>
      </div>
    );
  }

  const [notifications, favorites] = await Promise.all([getUserNotifications(session.id), getFavorites(session.id)]);
  const info = accessInfo(session);
  const unread = notifications.filter((n) => !n.isRead);
  const prefs = normalizePrefs(session.alertPrefs);
  const activeCount = ALERT_OPTIONS.filter((o) => prefs[o.key]).length;

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-2 px-1">
        <div>
          <h1 className="text-xl font-black tracking-tight">Notificações</h1>
          <p className="text-[0.68rem] muted">{unread.length} não lida(s) · atualização automática a cada 30s</p>
        </div>
        <AccessPill active={info.active} label={info.label} />
      </div>

      {!info.active ? (
        <div className="card border-rose-500/40 px-3 py-2.5">
          <p className="text-[0.8rem] font-bold">Seu acesso expirou</p>
          <p className="text-[0.68rem] muted">Os alertas em tempo real ficam pausados até você renovar o plano VIP.</p>
          <Link href="/planos" className="btn btn-primary mt-2 w-full !py-1.5 !text-[0.72rem]">Reativar acesso VIP</Link>
        </div>
      ) : null}

      {params.prefs ? <div className="card border-emerald-500/40 px-3 py-2 text-[0.72rem] font-semibold text-emerald-600 dark:text-emerald-400">✓ Preferências de alerta salvas. Você só receberá o que marcou.</div> : null}

      <section className="card overflow-hidden" id="configurar">
        <div className="flex items-center justify-between border-b px-3 py-2.5 hairline">
          <div>
            <p className="text-[0.82rem] font-extrabold">⚙️ Configurar alertas</p>
            <p className="text-[0.62rem] muted">{activeCount} de {ALERT_OPTIONS.length} tipos ativos · som {prefs.sound ? "ligado" : "desligado"}</p>
          </div>
          <span className="chip">{favorites.length} favorito(s)</span>
        </div>
        <form action={saveAlertPrefsAction} className="px-3 py-2.5">
          <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
            {ALERT_OPTIONS.map((option) => (
              <label key={option.key} className="flex cursor-pointer items-center gap-2.5 rounded-xl border px-2.5 py-2 hairline hover:border-emerald-500/40">
                <input type="checkbox" name={option.key} defaultChecked={prefs[option.key]} className="h-4 w-4 accent-emerald-500" />
                <span className="text-base">{option.icon}</span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[0.75rem] font-bold">{option.label}</span>
                  <span className="block text-[0.58rem] muted">{option.hint}</span>
                </span>
              </label>
            ))}
          </div>
          <label className="mt-2 flex cursor-pointer items-center gap-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/5 px-2.5 py-2">
            <input type="checkbox" name="sound" defaultChecked={prefs.sound} className="h-4 w-4 accent-emerald-500" />
            <span className="text-base">🔊</span>
            <span className="min-w-0 flex-1">
              <span className="block text-[0.75rem] font-bold">Tocar som ao receber alerta</span>
              <span className="block text-[0.58rem] muted">Som de gol diferente dos demais · vibração no celular</span>
            </span>
          </label>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <button className="btn btn-primary !px-3 !py-1.5 !text-[0.72rem]">Salvar preferências</button>
            <AlertSoundTools />
          </div>
          <div className="mt-2 rounded-xl border border-emerald-500/30 bg-emerald-500/5 px-2.5 py-2">
            <p className="text-[0.7rem] font-bold">📲 Push no celular — com o site fechado (Web Push)</p>
            <p className="mb-1.5 text-[0.58rem] muted">Ative uma vez neste dispositivo: gols, cartões, escanteios e fim de jogo dos seus favoritos chegam como notificação do sistema, mesmo com o navegador em segundo plano.</p>
            <WebPushPanel loggedIn />
          </div>
          <div className="mt-2 rounded-xl border px-2.5 py-2 hairline">
            <p className="text-[0.7rem] font-bold">📲 Notificações no Navegador (OneSignal)</p>
            <p className="mb-1.5 text-[0.58rem] muted">Receba os alertas mesmo com o site fechado — no celular e no computador. Toque para autorizar no pop-up do navegador.</p>
            <BrowserNotificationsButton appId="f06a705d-ebd0-4390-9a11-207fe769b81d" />
          </div>
          <p className="mt-2 text-[0.58rem] leading-relaxed muted">
            Os alertas valem para os seus times favoritos. Substituições e outros lances não marcados nunca geram notificação.
            Mantenha o site aberto (pode ser em segundo plano) para ouvir o som — o navegador exige um toque na página antes de liberar o áudio.
          </p>
        </form>
      </section>

      {favorites.length ? (
        <div className="card px-3 py-2.5">
          <p className="text-[0.72rem] font-bold">Times favoritos monitorados</p>
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {favorites.map(({ team }) => (
              <Link key={team.id} href={`/times/${team.slug}`} className="chip !border-amber-500/40 !bg-amber-500/10 !text-amber-600 dark:!text-amber-400">
                <TeamBadge name={team.name} color={team.badgeColor} colorAlt={team.badgeColorAlt} size={14} /> ★ {team.name}
              </Link>
            ))}
          </div>
          <p className="mt-1.5 text-[0.6rem] muted">Alertas ativos: {ALERT_OPTIONS.filter((o) => prefs[o.key]).map((o) => `${o.icon} ${o.label}`).join(" · ") || "nenhum — configure acima"}</p>
        </div>
      ) : (
        <div className="card border-amber-500/40 px-3 py-2.5">
          <p className="text-[0.78rem] font-bold">⭐ Escolha seu time favorito</p>
          <p className="text-[0.66rem] muted">Ao favoritar um time você recebe uma notificação quando ele estiver em campo, marcar, sofrer cartão ou o jogo terminar.</p>
          <Link href="/times" className="btn btn-ghost mt-2 w-full !py-1.5 !text-[0.7rem]">Escolher favorito</Link>
        </div>
      )}

      <div className="flex gap-1.5">
        <form action={markAllReadAction} className="flex-1">
          <input type="hidden" name="redirectTo" value="/notificacoes" />
          <button className="btn btn-ghost w-full !py-1.5 !text-[0.7rem]">Marcar todas como lidas</button>
        </form>
        <Link href="/jogos" className="btn btn-primary flex-1 !py-1.5 !text-[0.7rem]">Ver jogos ao vivo</Link>
      </div>

      <SectionHeader title="Histórico de alertas" subtitle="Mais recentes primeiro" icon={<span>🔔</span>} />
      {notifications.length ? (
        <div className="space-y-1.5">
          {notifications.map((notification) => {
            const meta = eventMeta(notification.type);
            return (
              <div key={notification.id} className={`card flex items-start gap-2.5 px-3 py-2.5 ${notification.isRead ? "" : "border-emerald-500/40"}`}>
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[var(--surface-3)] text-sm">{meta.icon}</span>
                <div className="min-w-0 flex-1">
                  <p className="text-[0.78rem] font-bold leading-snug">{notification.title}</p>
                  <p className="text-[0.68rem] leading-relaxed muted">{notification.body}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-[0.55rem] muted">
                      {new Date(notification.createdAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}
                    </span>
                    {notification.matchId ? <Link href={`/jogos/${notification.matchId}`} className="text-[0.6rem] font-bold text-[var(--brand)]">Abrir jogo →</Link> : null}
                    {!notification.isRead ? <span className="chip !border-emerald-500/30 !py-0 !text-[0.5rem] !text-emerald-500">nova</span> : null}
                  </div>
                </div>
                <form action={deleteNotificationAction}>
                  <input type="hidden" name="id" value={notification.id} />
                  <button className="px-1 text-[0.7rem] muted" aria-label="Remover">✕</button>
                </form>
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState title="Nenhuma notificação ainda" description="Favoritar um time é a forma mais rápida de receber alertas." icon="🔕" />
      )}

      <section className="card px-3 py-2.5">
        <p className="text-[0.75rem] font-bold">Resumo dos seus alertas</p>
        <div className="mt-1.5 grid grid-cols-2 gap-1.5 text-[0.65rem]">
          {ALERT_OPTIONS.map((option) => (
            <span key={option.key} className={`flex items-center gap-1 rounded-lg px-2 py-1.5 font-semibold ${prefs[option.key] ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-[var(--surface-3)] muted line-through"}`}>
              <span>{option.icon}</span> {option.label}
            </span>
          ))}
        </div>
      </section>
    </div>
  );
}

import Link from "next/link";
import { adjustUserAccessAction } from "@/app/actions";
import { getAdminOverview } from "@/lib/data";
import { AccessPill, SectionHeader, StatTile } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage({ searchParams }: { searchParams: Promise<{ q?: string; atualizado?: string }> }) {
  const params = await searchParams;
  const { users, subscriptions } = await getAdminOverview();
  const query = (params.q ?? "").toLowerCase().trim();
  const filtered = query ? users.filter((u) => `${u.name} ${u.email}`.toLowerCase().includes(query)) : users;
  const active = users.filter((u) => new Date(u.accessExpiresAt).getTime() > Date.now());
  const expired = users.filter((u) => new Date(u.accessExpiresAt).getTime() <= Date.now());
  const gmailTrial = users.filter((u) => u.trialSource === "gmail-trial");

  return (
    <div className="space-y-4">
      {params.atualizado ? <div className="card border-emerald-500/40 px-3 py-2 text-[0.72rem] font-semibold text-emerald-600 dark:text-emerald-400">✓ Acesso atualizado com sucesso.</div> : null}

      <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
        <StatTile label="Total" value={users.length} icon="👥" />
        <StatTile label="Ativos" value={active.length} hint="acesso dentro da data" icon="✅" />
        <StatTile label="Expirados" value={expired.length} hint="bloqueados" icon="⛔" />
        <StatTile label="Trial Gmail" value={gmailTrial.length} hint="1 dia grátis" icon="🎁" />
      </div>

      <form action="/admin/usuarios" className="flex gap-1.5">
        <input name="q" defaultValue={params.q ?? ""} placeholder="Buscar por nome ou e-mail..." className="input" />
        <button className="btn btn-ghost shrink-0">Buscar</button>
      </form>

      <div className="flex gap-1.5">
        <Link href="/admin/usuarios" className={`chip !py-1.5 ${!query ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>Todos ({users.length})</Link>
        <Link href="/admin/usuarios?q=@gmail.com" className="chip !py-1.5">Gmail</Link>
        <Link href="/admin/usuarios?q=demo" className="chip !py-1.5">Demo</Link>
      </div>

      <div className="space-y-2">
        {filtered.map((user) => {
          const isActive = new Date(user.accessExpiresAt).getTime() > Date.now();
          const days = Math.max(0, Math.ceil((new Date(user.accessExpiresAt).getTime() - Date.now()) / 86400000));
          const subs = subscriptions.filter((s) => s.userId === user.id);
          return (
            <div key={user.id} className="card overflow-hidden">
              <div className="flex items-start gap-2.5 px-3 py-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--brand-soft)] text-[0.7rem] font-black text-[var(--brand)]">{user.avatarSeed}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.82rem] font-extrabold">
                    {user.name} {user.role === "admin" ? "👑" : ""}
                  </p>
                  <p className="truncate text-[0.62rem] muted">{user.email}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-1">
                    <AccessPill active={isActive} label={isActive ? `${days} dia(s) restantes` : "expirado"} />
                    <span className="chip !py-0">{user.plan.toUpperCase()}</span>
                    <span className="chip !py-0">{user.trialSource}</span>
                    <span className="chip !py-0">{subs.length} assinatura(s)</span>
                  </div>
                  <p className="mt-1 text-[0.55rem] muted">
                    Expira {new Date(user.accessExpiresAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })}
                    {" · "}Último login {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "nunca"}
                    {" · "}Criado {new Date(user.createdAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 border-t px-3 py-2 hairline">
                {[7, 30, 365].map((amount) => (
                  <form key={amount} action={adjustUserAccessAction}>
                    <input type="hidden" name="userId" value={user.id} />
                    <input type="hidden" name="days" value={amount} />
                    <input type="hidden" name="action" value="extend" />
                    <button className="chip hover:!text-emerald-500">+{amount}d</button>
                  </form>
                ))}
                <form action={adjustUserAccessAction}>
                  <input type="hidden" name="userId" value={user.id} />
                  <input type="hidden" name="action" value="expire" />
                  <button className="chip hover:!border-rose-500/50 hover:!text-rose-500">Expirar agora</button>
                </form>
                <span className="ml-auto text-[0.55rem] muted">Plano define a data de expiração</span>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 ? <div className="card px-3 py-6 text-center text-[0.75rem] muted">Nenhum usuário encontrado.</div> : null}
      </div>

      <section className="card px-3 py-3">
        <SectionHeader title="Como a expiração funciona" icon={<span>⏳</span>} />
        <div className="space-y-1 text-[0.66rem] leading-relaxed muted">
          <p>• Cadastro com <b>@gmail.com</b>: 1 dia (24h) grátis automático.</p>
          <p>• Outros domínios: 6 horas de teste.</p>
          <p>• Planos VIP: diário (+1d), semanal (+7d), mensal (+30d) e anual (+365d), somados à data atual.</p>
          <p>• Após a data de expiração, o usuário vê paywall nas estatísticas, escalações e análises até assinar.</p>
          <p>• Você pode liberar ou encerrar o acesso manualmente como cortesia.</p>
        </div>
      </section>
    </div>
  );
}

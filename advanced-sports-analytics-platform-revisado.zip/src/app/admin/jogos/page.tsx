import Link from "next/link";
import { createMatchAction, createTeamAction, simulateLiveEventAction, syncNowAction, syncPlayersAction, updateLineupAction, updateMatchStatusAction } from "@/app/actions";
import { PLAYER_LEAGUES, getPlayersSyncState } from "@/lib/players";
import { getSyncStatus } from "@/lib/espn";
import { DataSourceBadge } from "@/components/ui";
import { getLeagues, getMatches, getTeams } from "@/lib/data";
import { SectionHeader, TeamBadge } from "@/components/ui";
import { Collapse } from "@/components/client";
import { formatKickoff } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminMatchesPage({ searchParams }: { searchParams: Promise<{ jogo?: string; time?: string; erro?: string; status?: string; escalacao?: string; jogadores?: string }> }) {
  const params = await searchParams;
  const playerStates = await Promise.all(PLAYER_LEAGUES.map(async (l) => ({ ...l, state: await getPlayersSyncState(l.code) })));
  const [leagues, teams, matches] = await Promise.all([getLeagues(), getTeams(), getMatches()]);
  const sync = await getSyncStatus().catch(() => null);
  const teamOptions = teams.map(({ team }) => ({ id: team.id, name: team.name, slug: team.slug }));

  return (
    <div className="space-y-4">
      {params.jogo || params.time || params.status || params.escalacao ? (
        <div className="card border-emerald-500/40 px-3 py-2 text-[0.72rem] font-semibold text-emerald-600 dark:text-emerald-400">
          ✓ Alteração salva com sucesso. {params.jogo ? `Jogo #${params.jogo} criado.` : ""}
        </div>
      ) : null}
      {params.erro ? <div className="card border-rose-500/40 px-3 py-2 text-[0.72rem] font-semibold text-rose-500">Verifique os campos e tente novamente.</div> : null}

      <div className="card flex flex-wrap items-center gap-2 px-3 py-2.5">
        <div className="min-w-0 flex-1">
          <p className="text-[0.8rem] font-extrabold">📡 Sincronização de jogos reais</p>
          <p className="text-[0.62rem] muted">{sync?.lastMessage || "Ainda não sincronizado"} · automática a cada 45s enquanto o site é acessado · fonte ESPN (sem chave)</p>
        </div>
        <DataSourceBadge lastSuccessAt={sync?.lastSuccessAt} matches={sync?.matchesSynced ?? 0} />
        <form action={syncNowAction}>
          <input type="hidden" name="redirectTo" value="/admin/jogos" />
          <button className="btn btn-primary !px-3 !py-1.5 !text-[0.7rem]">🔄 Sincronizar agora</button>
        </form>
      </div>

      <div className="card px-3 py-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <div className="min-w-0 flex-1">
            <p className="text-[0.8rem] font-extrabold">🏅 Central de Jogadores — sincronização de elencos e estatísticas</p>
            <p className="text-[0.62rem] muted">Elencos a cada 6h por liga (sob demanda ao abrir a página) · estatísticas detalhadas progressivas · fonte ESPN · cron: <code>/api/players/sync?liga=bra.1</code> com header x-sync-secret</p>
          </div>
          <form action={syncPlayersAction} className="flex gap-1.5">
            <select name="liga" className="input !w-auto !py-1.5 !text-[0.7rem]">
              {PLAYER_LEAGUES.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name}</option>)}
            </select>
            <button className="btn btn-primary !px-3 !py-1.5 !text-[0.7rem]">Sincronizar jogadores</button>
          </form>
        </div>
        {params.jogadores ? <p className="mt-2 rounded-lg bg-emerald-500/10 px-2 py-1 text-[0.66rem] font-semibold text-emerald-600 dark:text-emerald-400">✓ {params.jogadores}</p> : null}
        <div className="mt-2 flex flex-wrap gap-1">
          {playerStates.map((l) => (
            <span key={l.code} className={`chip !py-0 ${l.state?.lastSuccessAt ? "!border-emerald-500/30 !text-emerald-500" : ""}`} title={l.state?.lastMessage ?? "nunca sincronizado"}>
              {l.flag} {l.state?.matchesSynced ?? 0}
            </span>
          ))}
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <div className="card px-3 py-2"><p className="text-lg font-black">{matches.length}</p><p className="text-[0.6rem] muted">jogos reais (ontem/hoje/amanhã)</p></div>
        <div className="card px-3 py-2"><p className="text-lg font-black">{matches.filter((m) => m.status === "live").length}</p><p className="text-[0.6rem] muted">ao vivo agora</p></div>
        <div className="card px-3 py-2"><p className="text-lg font-black">{teams.length}</p><p className="text-[0.6rem] muted">times com perfil</p></div>
      </div>

      <Collapse title="➕ Cadastrar novo time" defaultOpen={false}>
        <form action={createTeamAction} className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label">Nome</label><input name="name" className="input" placeholder="Nome do clube" required /></div>
            <div><label className="label">Liga</label><select name="leagueId" className="input">{leagues.map((l) => <option key={l.id} value={l.id}>{l.flag} {l.name}</option>)}</select></div>
            <div><label className="label">País</label><input name="country" className="input" defaultValue="Brasil" /></div>
            <div><label className="label">Estádio</label><input name="stadium" className="input" placeholder="Arena" /></div>
            <div><label className="label">Técnico</label><input name="coach" className="input" placeholder="Treinador" /></div>
            <div><label className="label">Posição</label><input name="position" type="number" min={1} max={40} className="input" defaultValue={10} /></div>
            <div><label className="label">Cor principal</label><input name="badgeColor" type="color" className="input !p-1" defaultValue="#16a34a" /></div>
            <div><label className="label">Formação</label><input name="formation" className="input" defaultValue="4-3-3" /></div>
          </div>
          <button className="btn btn-primary w-full !py-2 !text-[0.75rem]">Salvar time</button>
        </form>
      </Collapse>

      <Collapse title="➕ Cadastrar nova partida" defaultOpen={false}>
        <form action={createMatchAction} className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label">Time da casa</label><select name="homeTeamId" className="input">{teamOptions.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
            <div><label className="label">Visitante</label><select name="awayTeamId" className="input" defaultValue={teamOptions[1]?.id}>{teamOptions.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
            <div><label className="label">Liga</label><select name="leagueId" className="input">{leagues.map((l) => <option key={l.id} value={l.id}>{l.flag} {l.name}</option>)}</select></div>
            <div><label className="label">Data/hora</label><input name="kickoff" type="datetime-local" className="input" /></div>
            <div><label className="label">Rodada</label><input name="round" className="input" defaultValue="Rodada 1" /></div>
            <div><label className="label">Estádio</label><input name="venue" className="input" placeholder="Arena" /></div>
            <div><label className="label">Status</label><select name="status" className="input"><option value="scheduled">Agendado</option><option value="live">Ao vivo</option><option value="finished">Encerrado</option></select></div>
          </div>
          <button className="btn btn-primary w-full !py-2 !text-[0.75rem]">Cadastrar partida</button>
        </form>
      </Collapse>

      <Collapse title="📋 Editar escalação prevista" defaultOpen={false}>
        <form action={updateLineupAction} className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label">Time</label><select name="teamId" className="input">{teamOptions.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
            <div><label className="label">Formação</label><input name="formation" className="input" defaultValue="4-3-3" /></div>
          </div>
          <div>
            <label className="label">Jogadores — um por linha: Nome | POS | nota</label>
            <textarea name="players" rows={6} className="input font-mono !text-[0.7rem]" placeholder={"Goleiro|GOL|7.2\nLateral|LAT|7.0\nZagueiro|ZAG|6.9"} />
          </div>
          <button className="btn btn-primary w-full !py-2 !text-[0.75rem]">Salvar escalação prevista</button>
        </form>
      </Collapse>

      <section>
        <SectionHeader title="Partidas monitoradas" subtitle="Controle de status, lances ao vivo e acesso ao jogo" icon={<span>⚽</span>} />
        <div className="space-y-1.5">
          {matches.map((match) => (
            <div key={match.id} className="card px-2.5 py-2">
              <div className="flex items-center gap-2">
                <TeamBadge name={match.homeName} color={match.homeColor} colorAlt={match.homeColorAlt} size={20} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.74rem] font-bold">{match.homeShort} {match.homeScore} x {match.awayScore} {match.awayShort}</p>
                  <p className="truncate text-[0.55rem] muted">{match.leagueFlag} {match.leagueName} · {formatKickoff(match.kickoff, true)} · {match.status}</p>
                </div>
                <TeamBadge name={match.awayName} color={match.awayColor} colorAlt={match.awayColorAlt} size={20} />
              </div>
              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                {(match.source === "espn" ? [] : ["scheduled", "live", "finished"].filter((status) => status !== match.status)).map((status) => (
                  <form key={status} action={updateMatchStatusAction}>
                    <input type="hidden" name="id" value={match.id} />
                    <input type="hidden" name="status" value={status} />
                    <button className="chip">{status === "live" ? "▶ ao vivo" : status === "finished" ? "⏱ encerrar" : "agendar"}</button>
                  </form>
                ))}
                {match.source === "espn" ? (
                  <span className="chip !border-emerald-500/30 !text-emerald-500">✓ ESPN</span>
                ) : (
                  <form action={simulateLiveEventAction}>
                    <input type="hidden" name="matchId" value={match.id} />
                    <input type="hidden" name="redirectTo" value="/admin/jogos" />
                    <button className="chip !border-emerald-500/40 !text-emerald-500">⚡ gerar lance (demo)</button>
                  </form>
                )}
                <Link href={`/jogos/${match.id}`} className="chip ml-auto">abrir →</Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="card px-3 py-2.5">
        <p className="text-[0.75rem] font-bold">Como funcionam os dados reais</p>
        <p className="mt-1 text-[0.65rem] leading-relaxed muted">
          Os jogos de ontem, hoje e amanhã de 16 competições são importados automaticamente da ESPN (placar, minuto, estatísticas,
          lances, escalações oficiais, odds e forma dos times). A sincronização roda a cada 45s enquanto há acessos e pode ser forçada aqui
          ou via <code>/api/sync?force=1</code> (ideal para um cron externo). Quando um jogo muda (gol, escanteio, cartão, impedimento,
          início ou fim), quem favoritou o time recebe a notificação. Jogos cadastrados manualmente continuam com o modo de simulação.
        </p>
      </section>
    </div>
  );
}

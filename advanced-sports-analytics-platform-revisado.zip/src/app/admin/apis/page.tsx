import { deleteIntegrationAction, saveIntegrationAction, syncIntegrationAction, testIntegrationAction, toggleIntegrationAction } from "@/app/actions";
import { getIntegrations } from "@/lib/data";
import { PROVIDER_PRESETS, presetFor } from "@/lib/providers";
import { AccessPill, SectionHeader } from "@/components/ui";
import { ApiKeyInput, Collapse, ProviderSelect } from "@/components/client";
import { fdCompetitions, getFdKey } from "@/lib/football-data";
import Link from "next/link";

export const dynamic = "force-dynamic";

function when(date: Date | null) {
  return date ? new Date(date).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "nunca";
}

export default async function AdminApisPage({ searchParams }: { searchParams: Promise<{ salvo?: string; testado?: string; falha?: string; sincronizado?: string; erro?: string; id?: string }> }) {
  const params = await searchParams;
  const integrations = await getIntegrations();
  const highlighted = integrations.find((i) => String(i.id) === params.id);
  const fdCred = await getFdKey();
  const fdComps = fdCred?.active ? await fdCompetitions() : null;

  return (
    <div className="space-y-4">
      {params.salvo || params.testado || params.sincronizado ? (
        <div className="card border-emerald-500/40 px-3 py-2 text-[0.72rem] font-semibold text-emerald-600 dark:text-emerald-400">
          ✓ {params.sincronizado ? "Sincronização concluída" : params.testado ? "Teste concluído" : "Integração salva e testada"}
          {highlighted?.lastResult ? ` — ${highlighted.lastResult}` : ""}
        </div>
      ) : null}
      {params.falha ? (
        <div className="card border-rose-500/40 px-3 py-2.5 text-[0.72rem]">
          <p className="font-extrabold text-rose-500">❌ A integração foi salva, mas o teste falhou</p>
          <p className="mt-0.5 leading-relaxed">{highlighted?.lastError || "Verifique a Base URL e a chave."}</p>
          {highlighted ? (
            <p className="mt-1 text-[0.62rem] muted">
              Dica: para {presetFor(highlighted.provider).label} a Base URL correta é <b>{presetFor(highlighted.provider).baseUrl || "a URL JSON da sua API"}</b> e a autenticação usa {presetFor(highlighted.provider).authHint}.
            </p>
          ) : null}
        </div>
      ) : null}
      {params.erro ? <div className="card border-rose-500/40 px-3 py-2 text-[0.72rem] font-semibold text-rose-500">Integração não encontrada.</div> : null}

      <div className="card px-3 py-2.5">
        <p className="text-[0.8rem] font-extrabold">🔌 Central de APIs de dados reais</p>
        <p className="mt-1 text-[0.66rem] leading-relaxed muted">
          Escolha o provedor, cole a chave e clique em <b>Salvar e testar</b>. A URL correta é preenchida automaticamente (e corrigida se você
          colar o endereço do site em vez da API). Com a conexão OK, use <b>Sincronizar jogos</b> para importar partidas reais de hoje e ao vivo
          para o site. A chave fica somente no servidor.
        </p>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          <span className="chip">✅ {integrations.filter((i) => i.status === "connected").length} conectada(s)</span>
          <span className="chip">❌ {integrations.filter((i) => i.status === "error").length} com erro</span>
          <span className="chip">🔑 {integrations.filter((i) => i.apiKey).length} com chave</span>
        </div>
      </div>

      <section className="card overflow-hidden border-emerald-500/30">
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2.5">
          <div>
            <p className="text-[0.8rem] font-extrabold">🔌 Football-Data.org — fonte secundária</p>
            <p className="text-[0.62rem] muted">{fdCred ? (fdCred.active ? "Chave configurada e ativa. Dados disponíveis em /football-data." : "Chave salva, mas a integração está desativada.") : "Cole sua chave abaixo (campo da integração Football-Data.org) e clique em Salvar e testar."}</p>
          </div>
          <Link href="/football-data" className="btn btn-primary !px-3 !py-1.5 !text-[0.7rem]">Abrir página da Football-Data →</Link>
        </div>
        {fdComps ? (
          <div className="border-t px-3 py-2.5 hairline">
            {fdComps.ok ? (
              <>
                <p className="text-[0.66rem] font-bold">Competições liberadas pela sua chave ({fdComps.data.competitions.length})</p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {fdComps.data.competitions.map((c) => (
                    <Link key={c.id} href={`/football-data?comp=${c.code}`} className="chip !py-0.5">
                      {c.emblem ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={c.emblem} alt="" width={12} height={12} className="h-3 w-3 object-contain" /> : null}
                      {c.name} <span className="muted">· {c.code}</span>
                    </Link>
                  ))}
                </div>
                <p className="mt-1.5 text-[0.56rem] muted">Entrega: resultados, calendário, classificação, artilheiros, árbitros. Não entrega: estatísticas por partida (escanteios, faltas, finalizações), escalações, eventos ao vivo detalhados.</p>
              </>
            ) : <p className="text-[0.66rem] text-rose-500">Não foi possível listar competições: {fdComps.error}</p>}
          </div>
        ) : null}
      </section>

      <Collapse title="➕ Adicionar nova integração" defaultOpen={integrations.length === 0 || Boolean(params.falha && !params.id)}>
        <form action={saveIntegrationAction} className="space-y-2">
          <ProviderSelect presets={PROVIDER_PRESETS.map((p) => ({ id: p.id, label: p.label, baseUrl: p.baseUrl, authHint: p.authHint, docs: p.docs }))} />
          <div><label className="label">Rótulo (opcional)</label><input name="label" className="input" placeholder="Ex.: Football-Data principal" /></div>
          <div><label className="label">Chave da API</label><ApiKeyInput name="apiKey" /></div>
          <div><label className="label">Observações</label><textarea name="notes" rows={2} className="input" placeholder="Plano contratado, limites, contato..." /></div>
          <label className="flex items-center gap-2 text-[0.7rem] font-semibold"><input type="checkbox" name="isActive" defaultChecked className="h-4 w-4 accent-emerald-500" /> Ativar imediatamente</label>
          <button className="btn btn-primary w-full !py-2 !text-[0.75rem]">Salvar e testar conexão</button>
        </form>
      </Collapse>

      <section>
        <SectionHeader title="Integrações configuradas" subtitle="Teste, sincronize, edite ou remova provedores" icon={<span>🔌</span>} />
        <div className="space-y-2">
          {integrations.map((integration) => {
            const preset = presetFor(integration.provider);
            const isError = integration.status === "error";
            return (
              <div key={integration.id} className={`card overflow-hidden ${isError ? "border-rose-500/40" : integration.status === "connected" ? "border-emerald-500/30" : ""}`}>
                <div className="flex items-start justify-between gap-2 px-3 py-2.5">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[0.8rem] font-extrabold">{integration.label}</p>
                    <p className="truncate text-[0.58rem] muted">{preset.label} · {integration.baseUrl || "sem base URL"} · {integration.apiKey ? `chave ${integration.apiKey.slice(0, 4)}••••${integration.apiKey.slice(-4)}` : "sem chave"}</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      <span className={`chip ${isError ? "!border-rose-500/40 !bg-rose-500/10 !text-rose-500" : integration.status === "connected" ? "!border-emerald-500/30 !bg-emerald-500/10 !text-emerald-500" : ""}`}>
                        {isError ? "ERRO" : integration.status === "connected" ? "CONECTADA" : "NÃO TESTADA"}
                      </span>
                      <AccessPill active={integration.isActive} label={integration.isActive ? "ativa" : "inativa"} />
                      <span className="chip !py-0">{integration.requestsToday} req</span>
                      <span className="chip !py-0">teste {when(integration.lastTestedAt)}</span>
                      <span className="chip !py-0">sync {when(integration.lastSyncAt)}</span>
                    </div>
                    {isError && integration.lastError ? (
                      <p className="mt-1.5 rounded-lg bg-rose-500/10 px-2 py-1.5 text-[0.64rem] leading-relaxed text-rose-600 dark:text-rose-300">{integration.lastError}</p>
                    ) : null}
                    {!isError && integration.lastResult ? (
                      <p className="mt-1.5 rounded-lg bg-emerald-500/10 px-2 py-1.5 text-[0.64rem] leading-relaxed text-emerald-700 dark:text-emerald-300">{integration.lastResult}</p>
                    ) : null}
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5 border-t px-3 py-2 hairline">
                  <form action={testIntegrationAction}>
                    <input type="hidden" name="id" value={integration.id} />
                    <button className="btn btn-ghost !px-2.5 !py-1 !text-[0.65rem]">🧪 Testar</button>
                  </form>
                  {preset.supportsSync ? (
                    <form action={syncIntegrationAction}>
                      <input type="hidden" name="id" value={integration.id} />
                      <button className="btn btn-primary !px-2.5 !py-1 !text-[0.65rem]">🔄 Sincronizar jogos</button>
                    </form>
                  ) : null}
                  <form action={toggleIntegrationAction}>
                    <input type="hidden" name="id" value={integration.id} />
                    <button className="btn btn-ghost !px-2.5 !py-1 !text-[0.65rem]">{integration.isActive ? "Desativar" : "Ativar"}</button>
                  </form>
                  <form action={deleteIntegrationAction} className="ml-auto">
                    <input type="hidden" name="id" value={integration.id} />
                    <button className="btn !border-rose-500/30 !bg-rose-500/10 !px-2.5 !py-1 !text-[0.65rem] !text-rose-500">Remover</button>
                  </form>
                </div>
                <Collapse title="✏️ Editar URL, chave ou provedor">
                  <form action={saveIntegrationAction} className="space-y-2">
                    <input type="hidden" name="id" value={integration.id} />
                    <ProviderSelect
                      presets={PROVIDER_PRESETS.map((p) => ({ id: p.id, label: p.label, baseUrl: p.baseUrl, authHint: p.authHint, docs: p.docs }))}
                      defaultProvider={preset.id}
                      defaultBaseUrl={integration.baseUrl}
                    />
                    <div><label className="label">Rótulo</label><input name="label" defaultValue={integration.label} className="input" /></div>
                    <div>
                      <label className="label">Nova chave {integration.apiKey ? "(deixe em branco para manter a atual)" : ""}</label>
                      <ApiKeyInput name="apiKey" defaultValue="" />
                    </div>
                    <div><label className="label">Observações</label><textarea name="notes" rows={2} defaultValue={integration.notes} className="input" /></div>
                    <div className="flex items-center justify-between">
                      <label className="flex items-center gap-2 text-[0.7rem] font-semibold"><input type="checkbox" name="isActive" defaultChecked={integration.isActive} className="h-4 w-4 accent-emerald-500" /> Ativa</label>
                      <button className="btn btn-primary !px-3 !py-1.5 !text-[0.7rem]">Salvar e testar</button>
                    </div>
                  </form>
                </Collapse>
              </div>
            );
          })}
        </div>
      </section>

      <section>
        <SectionHeader title="Provedores suportados" subtitle="URL e autenticação corretas de cada um" icon={<span>📚</span>} />
        <div className="grid gap-2 sm:grid-cols-2">
          {PROVIDER_PRESETS.filter((p) => p.id !== "custom").map((provider) => (
            <div key={provider.id} className="card px-3 py-2.5">
              <p className="text-[0.78rem] font-extrabold">{provider.label}</p>
              <p className="mt-0.5 text-[0.62rem] muted">{provider.coverage}</p>
              <p className="mt-1 break-all font-mono text-[0.6rem]">{provider.baseUrl}</p>
              <div className="mt-1.5 flex flex-wrap gap-1">
                <span className="chip !py-0">{provider.authHint}</span>
                {provider.supportsSync ? <span className="chip !border-emerald-500/30 !py-0 !text-emerald-500">importa jogos</span> : null}
                <a href={provider.docs} target="_blank" rel="noreferrer" className="chip !py-0 !text-[var(--brand)]">obter chave ↗</a>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Collapse title="❓ Erros comuns e como resolver">
        <div className="space-y-1.5 text-[0.66rem] leading-relaxed muted">
          <p><b>HTTP 404 com conteúdo HTML</b> (ex.: aparece <code>plausible.js</code>): a URL aponta para o site do provedor, não para a API. Football-Data usa <code>https://api.football-data.org/v4</code>; API-Football usa <code>https://v3.football.api-sports.io</code>. O painel agora corrige isso automaticamente.</p>
          <p><b>HTTP 401/403</b>: chave inválida, expirada ou colada com espaços. Gere uma nova no painel do provedor.</p>
          <p><b>HTTP 429</b>: limite de requisições (Football-Data grátis: 10/min). Aguarde e tente de novo.</p>
          <p><b>API-Football retorna 200 com erro</b>: a chave existe mas não está ativa/assinada; a mensagem do provedor é exibida no cartão.</p>
          <p><b>Tempo limite</b>: o servidor não alcançou o provedor em 12s — verifique a URL e tente novamente.</p>
        </div>
      </Collapse>
    </div>
  );
}

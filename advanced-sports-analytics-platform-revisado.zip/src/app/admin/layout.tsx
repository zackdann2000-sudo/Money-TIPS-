import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { AdminTabs } from "@/components/nav";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const TABS = [
  { href: "/admin", label: "Visão geral" },
  { href: "/admin/usuarios", label: "Usuários & acessos" },
  { href: "/admin/jogos", label: "Jogos & times" },
  { href: "/admin/apis", label: "APIs de dados" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const session = await getSessionUser();
  if (!session) redirect("/login?next=/admin");
  if (session.role !== "admin") redirect("/conta");

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <div>
          <h1 className="text-lg font-black tracking-tight">👑 Painel do proprietário</h1>
          <p className="text-[0.65rem] muted">{session.name} · acesso total</p>
        </div>
        <span className="chip !border-amber-500/40 !bg-amber-500/10 !text-amber-500">ADMIN</span>
      </div>
      <AdminTabs tabs={TABS} />
      {children}
    </div>
  );
}

import Link from "next/link";
import { getAdminOverview } from "@/lib/data";
import { AccessPill, SectionHeader, StatTile } from "@/components/ui";
import { brl } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminOverviewPage() {
  const { users, subscriptions, integrations, logs, stats } = await getAdminOverview();
  const activePct = stats.totalUsers ? Math.round((stats.activeUsers / stats.totalUsers) * 100) : 0;
  const trial = users.filter((u) => u.plan === "free" && new Date(u.accessExpiresAt).getTime() > Date.now()).length;
  const vip = users.filter((u) => u.plan !== "free").length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
        <StatTile label="Usuários" value={stats.totalUsers} hint={`${vip} VIP · ${trial} em teste`} icon="👥" />
        <StatTile label="Acessos ativos" value={stats.activeUsers} hint={`${activePct}% da base`} icon="✅" />
        <StatTile label="Expirados" value={stats.expiredUsers} hint="precisam renovar VIP" icon="⛔" />
        <StatTile label="Receita ativa" value={brl(stats.revenue)} hint="assinaturas vigentes" icon="💳" />
      </div>

      <section className="card px-3 py-3">
        <div className="flex items-center justify-between">
          <p className="text-[0.78rem] font-extrabold">Saúde da base de assinantes</p>
          <span className="text-[0.65rem] font-bold text-emerald-500">{activePct}% ativos</span>
        </div>
        <div className="mt-2 flex h-2.5 overflow-hidden rounded-full bg-[var(--surface-3)]">
          <div className="h-full bg-emerald-500" style={{ width: `${activePct}%` }} />
          <div className="h-full bg-rose-500/70" style={{ width: `${100 - activePct}%` }} />
        </div>
        <div className="mt-1.5 flex justify-between text-[0.58rem] muted">
          <span>{stats.activeUsers} {stats.activeUsers === 1 ? "ativo" : "ativos"}</span>
          <span>{stats.expiredUsers} {stats.expiredUsers === 1 ? "expirado" : "expirados"}</span>
        </div>
      </section>

      <div className="grid gap-2 sm:grid-cols-3">
        {[
          { href: "/admin/usuarios", icon: "👥", title: "Usuários & acessos", text: "Ativar, expirar ou liberar dias de VIP." },
          { href: "/admin/jogos", icon: "⚽", title: "Jogos & times", text: `${stats.matches} jogos · ${stats.teams} times cadastrados.` },
          { href: "/admin/apis", icon: "🔌", title: "APIs de dados", text: `${integrations.filter((i) => i.isActive).length} integração(ões) ativa(s).` },
        ].map((item) => (
          <Link key={item.href} href={item.href} className="card card-hover px-3 py-2.5">
            <span className="text-lg">{item.icon}</span>
            <p className="mt-1 text-[0.78rem] font-bold">{item.title}</p>
            <p className="text-[0.62rem] muted">{item.text}</p>
          </Link>
        ))}
      </div>

      <section>
        <SectionHeader title="Novos usuários" subtitle="Cadastros recentes e situação do acesso" href="/admin/usuarios" action="Gerenciar" icon={<span>👥</span>} />
        <div className="card overflow-hidden">
          {users.slice(0, 6).map((user) => {
            const active = new Date(user.accessExpiresAt).getTime() > Date.now();
            return (
              <div key={user.id} className="flex items-center gap-2 border-b px-2.5 py-2 last:border-0 hairline">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--brand-soft)] text-[0.6rem] font-black text-[var(--brand)]">{user.avatarSeed}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.75rem] font-bold">{user.name} {user.role === "admin" ? "👑" : ""}</p>
                  <p className="truncate text-[0.58rem] muted">{user.email} · {user.trialSource}</p>
                </div>
                <div className="text-right">
                  <AccessPill active={active} label={active ? `${Math.max(0, Math.ceil((new Date(user.accessExpiresAt).getTime() - Date.now()) / 86400000))}d` : "expirado"} />
                  <p className="mt-0.5 text-[0.52rem] muted">{new Date(user.accessExpiresAt).toLocaleDateString("pt-BR")}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section>
          <SectionHeader title="Últimos acessos registrados" subtitle="Quem visitou o site" icon={<span>🔐</span>} />
          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {logs.length ? logs.map((row) => (
              <div key={row.log.id} className="flex items-center justify-between gap-2 px-2.5 py-1.5">
                <div className="min-w-0">
                  <p className="truncate text-[0.7rem] font-semibold">{row.userName ?? "Visitante"}</p>
                  <p className="truncate text-[0.55rem] muted">{row.userEmail ?? "não autenticado"} · {row.log.path}</p>
                </div>
                <span className="shrink-0 text-[0.55rem] muted">{new Date(row.log.createdAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</span>
              </div>
            )) : <div className="px-3 py-3 text-center text-[0.7rem] muted">Nenhum acesso registrado.</div>}
          </div>
        </section>

        <section>
          <SectionHeader title="Assinaturas" subtitle="Histórico recente" href="/admin/usuarios" action="Usuários" icon={<span>💳</span>} />
          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {subscriptions.slice(0, 6).map((sub) => {
              const user = users.find((u) => u.id === sub.userId);
              return (
                <div key={sub.id} className="flex items-center justify-between gap-2 px-2.5 py-1.5">
                  <div className="min-w-0">
                    <p className="truncate text-[0.7rem] font-semibold">{user?.name ?? `Usuário #${sub.userId}`}</p>
                    <p className="truncate text-[0.55rem] muted">{sub.planSlug} · {new Date(sub.startsAt).toLocaleDateString("pt-BR")} → {new Date(sub.expiresAt).toLocaleDateString("pt-BR")}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[0.68rem] font-bold">{brl(sub.amountCents)}</p>
                    <AccessPill active={sub.status === "active"} label={sub.status} />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      <section>
        <SectionHeader title="Status das integrações" subtitle="Fontes de dados do site" href="/admin/apis" action="Configurar" icon={<span>🔌</span>} />
        <div className="card divide-y divide-[var(--line)] overflow-hidden">
          {integrations.map((integration) => (
            <div key={integration.id} className="flex items-center justify-between gap-2 px-2.5 py-2">
              <div className="min-w-0">
                <p className="truncate text-[0.72rem] font-bold">{integration.label}</p>
                <p className="truncate text-[0.55rem] muted">{integration.baseUrl || "sem URL"} · {integration.apiKey ? "chave configurada" : "sem chave"}</p>
              </div>
              <AccessPill active={integration.isActive} label={integration.isActive ? "ativa" : "inativa"} />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

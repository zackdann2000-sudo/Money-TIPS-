import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/client";
import { Logo } from "@/components/nav";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const session = await getSessionUser();
  if (session) redirect("/conta");

  return (
    <div className="mx-auto max-w-md space-y-3 py-2">
      <div className="text-center">
        <div className="flex justify-center"><Logo /></div>
        <h1 className="mt-3 text-xl font-black tracking-tight">Bem-vindo de volta</h1>
        <p className="text-[0.72rem] muted">Entre para acompanhar seus times e alertas ao vivo</p>
      </div>

      <div className="card px-4 py-4">
        <AuthForm mode="login" />
      </div>

      <div className="card px-3 py-2.5 text-[0.68rem]">
        <p className="font-bold">Contas de demonstração</p>
        <div className="mt-1 space-y-0.5 muted">
          <p>👤 demo@gmail.com / demo123 — VIP ativo (21 dias)</p>
          <p>👑 admin@greenscore.app / admin123 — proprietário</p>
          <p>⛔ marina@gmail.com / demo123 — acesso expirado</p>
        </div>
      </div>

      <p className="text-center text-[0.72rem] muted">
        Ainda não tem conta? <Link href="/cadastro" className="font-bold text-[var(--brand)]">Ganhe 1 dia grátis com Gmail</Link>
      </p>
    </div>
  );
}

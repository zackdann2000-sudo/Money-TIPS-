import Link from "next/link";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getPlayersByIds, PLAYER_LEAGUES, POSITIONS, searchPlayers, type StatRow } from "@/lib/players";
import { Bars, CompareBar, CompareToggle } from "@/components/players";
import { PremiumLock, SectionHeader } from "@/components/ui";

export const dynamic = "force-dynamic";

const COLORS = ["var(--brand)", "#38bdf8", "#f59e0b", "#f43f5e"];
const dec = (v: number | null) => (v === null || Number.isNaN(v) ? "—" : v.toFixed(2));
const per = (v: number, apps: number) => (apps > 0 ? v / apps : null);
const p90 = (v: number, min: number | null) => (min ? (v / min) * 90 : null);
const ratio = (a: number, b: number) => (b > 0 ? a / b : null);

type Row = { label: string; group: string; value: (r: StatRow) => number | null; display?: (r: StatRow) => string; lowerIsBetter?: boolean; needsDetailed?: boolean };

const ROWS: Row[] = [
  { group: "Participação", label: "Jogos", value: (r) => r.appearances },
  { group: "Participação", label: "Minutos", value: (r) => r.minutes ?? null, needsDetailed: true },
  { group: "Participação", label: "Titularidades", value: (r) => r.starts ?? null, needsDetailed: true },
  { group: "Ataque", label: "Gols", value: (r) => r.goals },
  { group: "Ataque", label: "Assistências", value: (r) => r.assists },
  { group: "Ataque", label: "Gols por 90", value: (r) => p90(r.goals, r.minutes), needsDetailed: true },
  { group: "Ataque", label: "Assistências por 90", value: (r) => p90(r.assists, r.minutes), needsDetailed: true },
  { group: "Ataque", label: "G+A por 90", value: (r) => p90(r.goals + r.assists, r.minutes), needsDetailed: true },
  { group: "Finalizações", label: "Finalizações", value: (r) => r.shots },
  { group: "Finalizações", label: "No alvo", value: (r) => r.shotsOnTarget },
  { group: "Finalizações", label: "Precisão (%)", value: (r) => (r.shots >= 10 ? (ratio(r.shotsOnTarget, r.shots) ?? 0) * 100 : null), display: (r) => (r.shots >= 10 ? `${(((r.shotsOnTarget / r.shots) || 0) * 100).toFixed(1)}%` : "amostra < 10") },
  { group: "Finalizações", label: "Finalizações por 90", value: (r) => p90(r.shots, r.minutes), needsDetailed: true },
  { group: "Criação", label: "Grandes chances criadas", value: (r) => r.bigChancesCreated ?? null, needsDetailed: true },
  { group: "Criação", label: "Passes decisivos", value: (r) => r.shotAssists ?? null, needsDetailed: true },
  { group: "Passes", label: "Passes certos", value: (r) => r.accuratePasses ?? null, needsDetailed: true },
  { group: "Passes", label: "Precisão de passes (%)", value: (r) => ((r.totalPasses ?? 0) >= 100 ? (ratio(r.accuratePasses ?? 0, r.totalPasses ?? 0) ?? 0) * 100 : null), display: (r) => ((r.totalPasses ?? 0) >= 100 ? `${(((r.accuratePasses ?? 0) / (r.totalPasses ?? 1)) * 100).toFixed(1)}%` : "amostra < 100"), needsDetailed: true },
  { group: "Faltas", label: "Faltas cometidas", value: (r) => r.foulsCommitted, lowerIsBetter: true },
  { group: "Faltas", label: "Faltas sofridas", value: (r) => r.foulsSuffered },
  { group: "Faltas", label: "Faltas cometidas por 90", value: (r) => p90(r.foulsCommitted, r.minutes), lowerIsBetter: true, needsDetailed: true },
  { group: "Disciplina", label: "Cartões amarelos", value: (r) => r.yellowCards, lowerIsBetter: true },
  { group: "Disciplina", label: "Cartões vermelhos", value: (r) => r.redCards, lowerIsBetter: true },
  { group: "Disciplina", label: "Cartões por jogo", value: (r) => per(r.yellowCards + r.redCards, r.appearances), lowerIsBetter: true },
  { group: "Disciplina", label: "Impedimentos", value: (r) => r.offsides, lowerIsBetter: true },
  { group: "Defesa", label: "Desarmes certos", value: (r) => r.tacklesWon ?? null, needsDetailed: true },
  { group: "Defesa", label: "Interceptações", value: (r) => r.interceptions ?? null, needsDetailed: true },
  { group: "Defesa", label: "Cortes", value: (r) => r.clearances ?? null, needsDetailed: true },
  { group: "Defesa", label: "Bolas recuperadas", value: (r) => r.recoveries ?? null, needsDetailed: true },
  { group: "Defesa", label: "Duelos ganhos", value: (r) => r.duelsWon ?? null, needsDetailed: true },
  { group: "Goleiro", label: "Defesas", value: (r) => (r.player.position === "G" ? r.saves : null) },
  { group: "Goleiro", label: "Gols sofridos", value: (r) => (r.player.position === "G" ? r.goalsConceded : null), lowerIsBetter: true },
  { group: "Goleiro", label: "Jogos sem sofrer gol", value: (r) => (r.player.position === "G" ? (r.cleanSheets ?? null) : null), needsDetailed: true },
];

export default async function ComparePage({ searchParams }: { searchParams: Promise<{ ids?: string; liga?: string; temporada?: string; q?: string }> }) {
  const sp = await searchParams;
  const ids = [...new Set((sp.ids ?? "").split(",").map((v) => Number(v)).filter((v) => Number.isInteger(v) && v > 0))].slice(0, 4);
  const session = await getSessionUser();
  const hasAccess = session ? accessInfo(session).active : false;
  const league = PLAYER_LEAGUES.some((l) => l.code === sp.liga) ? sp.liga : undefined;
  const season = Number(sp.temporada) || undefined;
  const rows = hasAccess ? await getPlayersByIds(ids, league, season) : [];
  const suggestions = sp.q ? await searchPlayers(sp.q, league) : [];

  const minutesList = rows.map((r) => r.minutes ?? 0).filter((m) => m > 0);
  const minutesWarning = minutesList.length >= 2 && Math.max(...minutesList) / Math.max(1, Math.min(...minutesList)) >= 2;
  const mixedPositions = new Set(rows.map((r) => r.player.position)).size > 1;
  const mixedContext = new Set(rows.map((r) => `${r.leagueCode}-${r.season}`)).size > 1;
  const groups = [...new Set(ROWS.map((r) => r.group))];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href={`/jogadores${league ? `?liga=${league}` : ""}`} className="chip">← Rankings</Link>
        <span className="chip">{rows.length}/4 jogadores</span>
      </div>
      <div className="px-1">
        <h1 className="text-xl font-black tracking-tight">Comparador de jogadores</h1>
        <p className="text-[0.7rem] muted">Selecione de 2 a 4 atletas nos rankings (botão “+ comparar”) ou busque abaixo. Mesma temporada e competição por padrão.</p>
      </div>

      <form action="/jogadores/comparar" className="card flex gap-1.5 px-3 py-2.5">
        <input type="hidden" name="ids" value={ids.join(",")} />
        {league ? <input type="hidden" name="liga" value={league} /> : null}
        {season ? <input type="hidden" name="temporada" value={season} /> : null}
        <input name="q" defaultValue={sp.q ?? ""} placeholder="Buscar jogador para adicionar…" className="input !py-1.5 !text-[0.78rem]" />
        <button className="btn btn-ghost !px-3 !py-1.5 !text-[0.72rem]">Buscar</button>
      </form>
      {suggestions.length ? (
        <div className="card divide-y divide-[var(--line)] overflow-hidden">
          {suggestions.map((s) => (
            <div key={s.player.id} className="flex items-center gap-2 px-3 py-1.5">
              <span className="min-w-0 flex-1 truncate text-[0.74rem] font-semibold">{s.player.name} <span className="muted">· {s.stat.teamName} · {POSITIONS[s.player.position]?.label}</span></span>
              <CompareToggle playerId={s.player.id} />
            </div>
          ))}
        </div>
      ) : sp.q ? <p className="px-1 text-[0.66rem] muted">Nenhum jogador encontrado para “{sp.q}”.</p> : null}

      {!hasAccess ? (
        <PremiumLock title="O comparador é exclusivo para contas ativas" description="Entre com sua conta (1 dia grátis via Gmail) ou assine o VIP para comparar até 4 jogadores lado a lado com gráficos." />
      ) : rows.length < 2 ? (
        <div className="card px-4 py-8 text-center text-[0.78rem] muted">Selecione pelo menos 2 jogadores para comparar.</div>
      ) : (
        <>
          {minutesWarning ? <div className="card border-amber-500/40 px-3 py-2 text-[0.68rem] text-amber-700 dark:text-amber-300">⚠️ Amostras muito diferentes: a diferença de minutos entre os atletas é de 2× ou mais. Prefira as métricas por 90 minutos e interprete totais com cautela.</div> : null}
          {mixedPositions ? <div className="card px-3 py-2 text-[0.68rem] muted">ℹ️ Você está comparando posições diferentes — métricas defensivas e ofensivas têm pesos distintos por função.</div> : null}
          {mixedContext ? <div className="card border-amber-500/40 px-3 py-2 text-[0.68rem] text-amber-700 dark:text-amber-300">⚠️ Competições/temporadas diferentes entre os atletas selecionados.</div> : null}

          <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${rows.length}, minmax(0, 1fr))` }}>
            {rows.map((r, i) => (
              <Link key={r.id} href={`/jogadores/${r.player.id}?liga=${r.leagueCode}&temporada=${r.season}`} className="card flex flex-col items-center px-2 py-2.5 text-center" style={{ borderColor: COLORS[i] }}>
                {r.player.headshot ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={r.player.headshot} alt="" width={44} height={44} className="h-11 w-11 rounded-full bg-[var(--surface-3)] object-cover" /> : <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--surface-3)] text-xs font-black">{r.player.name.slice(0, 2)}</span>}
                <p className="mt-1 line-clamp-2 text-[0.7rem] font-bold leading-tight">{r.player.shortName || r.player.name}</p>
                <p className="text-[0.55rem] muted">{r.teamName}</p>
                <p className="text-[0.55rem] muted">{POSITIONS[r.player.position]?.label} · {r.appearances}j{r.minutes ? ` · ${r.minutes}′` : ""}</p>
              </Link>
            ))}
          </div>

          {groups.map((group) => {
            const rowsInGroup = ROWS.filter((r) => r.group === group).filter((row) => rows.some((r) => row.value(r) !== null));
            if (!rowsInGroup.length) return null;
            return (
              <section key={group}>
                <SectionHeader title={group} />
                <div className="card divide-y divide-[var(--line)] overflow-hidden">
                  {rowsInGroup.map((row) => {
                    const values = rows.map((r) => row.value(r));
                    const valid = values.filter((v): v is number => v !== null);
                    const best = valid.length ? (row.lowerIsBetter ? Math.min(...valid) : Math.max(...valid)) : null;
                    return (
                      <div key={row.label} className="px-3 py-2">
                        <p className="mb-1 text-[0.68rem] font-bold">{row.label}{row.needsDetailed && values.some((v) => v === null) ? <span className="ml-1 text-[0.55rem] font-semibold muted">(detalhamento pendente para algum atleta)</span> : null}</p>
                        <Bars
                          max={Math.max(1, ...valid)}
                          rows={rows.map((r, i) => {
                            const v = values[i];
                            return {
                              label: `${r.player.shortName || r.player.name}${v !== null && v === best && valid.length > 1 ? " ★" : ""}`,
                              value: v,
                              display: row.display ? row.display(r) : v === null ? "—" : Number.isInteger(v) ? String(v) : dec(v),
                              color: COLORS[i],
                            };
                          })}
                        />
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })}
          <p className="px-1 text-[0.6rem] leading-relaxed muted">★ = melhor valor da linha (menor nas métricas de faltas/cartões/gols sofridos). Fonte: ESPN · métricas por 90 exigem minutos jogados.</p>
        </>
      )}
      <CompareBar league={league} season={season} />
    </div>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { averagesFor, getPlayerProfile, loadStatRows, PLAYER_LEAGUES, POSITIONS, rankRows } from "@/lib/players";
import { Bars, CompareBar, CompareToggle } from "@/components/players";
import { PlayerRadarWidget } from "@/components/player-radar";
import { PremiumLock, SectionHeader, StatTile } from "@/components/ui";

export const dynamic = "force-dynamic";

const pct = (a: number, b: number) => (b > 0 ? `${((a / b) * 100).toFixed(1)}%` : "—");
const dec = (v: number | null | undefined) => (v === null || v === undefined || Number.isNaN(v) ? "—" : v.toFixed(2));
const per = (v: number, apps: number) => (apps > 0 ? v / apps : null);
const p90 = (v: number, min: number | null | undefined) => (min ? (v / min) * 90 : null);

export default async function PlayerPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ liga?: string; temporada?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const profile = await getPlayerProfile(Number(id), sp.liga, Number(sp.temporada) || undefined);
  if (!profile) notFound();
  const { player, seasons, current } = profile;
  const session = await getSessionUser();
  const hasAccess = session ? accessInfo(session).active : false;
  const league = current ? PLAYER_LEAGUES.find((l) => l.code === current.leagueCode) : null;

  const rows = current ? await loadStatRows({ league: current.leagueCode, season: current.season }) : [];
  const avg = current ? averagesFor(rows, player.position) : null;
  const rankIn = (metric: string, minApps = 1) => {
    const ranked = rankRows(rows, { metric, minApps, pageSize: 100, page: 1 });
    const all = rankRows(rows, { metric, minApps, pageSize: 100, page: 1 }).total;
    const found = ranked.items.find((i) => i.stat.player.id === player.id);
    return found ? `${found.rank}º de ${all}` : null;
  };
  const posRank = current
    ? rankRows(rows.filter((r) => r.player.position === player.position), { metric: player.position === "G" ? "saves" : "involvements", minApps: 1, pageSize: 100 })
    : null;
  const posPlace = posRank?.items.find((i) => i.stat.player.id === player.id)?.rank;

  const c = current;
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href={`/jogadores?liga=${c?.leagueCode ?? "bra.1"}`} className="chip">← Rankings</Link>
        <CompareToggle playerId={player.id} />
      </div>

      <section className="card overflow-hidden">
        <div className="relative brand-gradient px-3.5 py-3.5 text-white">
          <div className="pointer-events-none absolute inset-0 pitch opacity-25" />
          <div className="relative flex items-center gap-3">
            {player.headshot ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={player.headshot} alt={player.name} width={64} height={64} className="h-16 w-16 rounded-2xl bg-white/15 object-cover" />
            ) : (
              <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/15 text-xl font-black">{player.name.split(" ").slice(0, 2).map((p) => p[0]).join("")}</span>
            )}
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-lg font-black leading-tight">{player.name}</h1>
              <p className="text-[0.66rem] text-emerald-50/85">
                {POSITIONS[player.position]?.label ?? player.position}{player.jersey ? ` · #${player.jersey}` : ""}{player.nationality ? ` · ${player.nationality}` : ""}{player.age ? ` · ${player.age} anos` : ""}
              </p>
              {c ? (
                <p className="mt-0.5 flex items-center gap-1 text-[0.66rem] text-emerald-50/85">
                  {c.teamLogo ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={c.teamLogo} alt="" width={14} height={14} className="h-3.5 w-3.5 object-contain" /> : null}
                  {c.teamName} · {league?.flag} {league?.name} · temporada {c.season}
                </p>
              ) : null}
            </div>
          </div>
        </div>
        {c ? (
          <div className="grid grid-cols-4 divide-x divide-[var(--line)] text-center">
            {[
              { value: c.appearances, label: "jogos" },
              { value: c.minutes ?? "—", label: "minutos" },
              { value: c.goals, label: "gols" },
              { value: c.assists, label: "assistências" },
            ].map((item) => (
              <div key={item.label} className="px-1 py-2">
                <p className="text-[0.95rem] font-black tabular-nums leading-none">{item.value}</p>
                <p className="mt-0.5 text-[0.52rem] muted">{item.label}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="px-3 py-4 text-center text-[0.72rem] muted">Sem estatísticas de temporada registradas para este jogador.</div>
        )}
      </section>

      {c ? (
        <>
          {seasons.length > 1 ? (
            <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3">
              {seasons.map((s) => (
                <Link key={s.id} href={`/jogadores/${player.id}?liga=${s.leagueCode}&temporada=${s.season}`} className={`chip !py-1.5 ${s.id === c.id ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>
                  {PLAYER_LEAGUES.find((l) => l.code === s.leagueCode)?.flag} {PLAYER_LEAGUES.find((l) => l.code === s.leagueCode)?.name} {s.season} · {s.teamName}
                </Link>
              ))}
            </div>
          ) : null}

          <section className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatTile label="Finalizações" value={`${c.shots} (${c.shotsOnTarget} no alvo)`} hint={`precisão ${pct(c.shotsOnTarget, c.shots)}`} icon="🎯" />
            <StatTile label="Faltas" value={`${c.foulsCommitted} / ${c.foulsSuffered}`} hint="cometidas / sofridas" icon="✋" />
            <StatTile label="Cartões" value={`${c.yellowCards} 🟨 ${c.redCards} 🟥`} hint={`${dec(per(c.yellowCards + c.redCards, c.appearances))} por jogo`} icon="🟨" />
            <StatTile label="Impedimentos" value={c.offsides} hint={`${dec(per(c.offsides, c.appearances))} por jogo`} icon="🚫" />
          </section>

          <section>
            <SectionHeader title="Posição nos rankings" subtitle={`${league?.name} ${c.season} · entre jogadores com ≥1 jogo`} icon={<span>🏅</span>} />
            <div className="flex flex-wrap gap-1.5">
              {[
                ["Gols", rankIn("goals")],
                ["Assistências", rankIn("assists")],
                ["Finalizações", rankIn("shots")],
                ["Faltas cometidas", rankIn("foulsCommitted")],
                ["Faltas sofridas", rankIn("foulsSuffered")],
                ["Cartões", rankIn("totalCards")],
                ["Impedimentos", rankIn("offsides")],
                player.position === "G" ? ["Defesas", rankIn("saves")] : ["G+A", rankIn("involvements")],
              ].map(([label, value]) => (
                <span key={label as string} className={`chip ${value ? "" : "opacity-50"}`}>{label}: <b className="ml-1 text-emerald-500">{value ?? "sem registro"}</b></span>
              ))}
              {posPlace ? <span className="chip !border-emerald-500/40 !text-emerald-500">{posPlace}º entre {POSITIONS[player.position]?.plural.toLowerCase()} ({player.position === "G" ? "defesas" : "G+A"})</span> : null}
            </div>
          </section>

          {hasAccess ? (
            <>
              <PlayerRadarWidget
                playerName={player.shortName || player.name}
                source="ESPN · temporada atual"
                data={(() => {
                  const apps = Math.max(1, c.appearances);
                  const pos = avg?.position;
                  const lg = avg?.league;
                  // escala: valor do jogador relativo à média (média = 50; 2× a média = 100)
                  const scale = (v: number | null, m: number | null | undefined) => (v === null || !m || m <= 0 ? null : Math.max(0, Math.min(100, Math.round((v / m) * 50))));
                  const shots = c.shots / apps, goals = c.goals / apps, assists = c.assists / apps;
                  const passAcc = (c.totalPasses ?? 0) >= 50 ? (c.accuratePasses ?? 0) / (c.totalPasses ?? 1) : null;
                  const tackles = c.detailed ? (c.tackles ?? 0) / apps : null;
                  const dribbles = c.detailed && c.duels ? (c.duelsWon ?? 0) / apps : null;
                  const rows = [
                    { atributo: "Finalização", jogador: scale(shots, pos?.shotsPerGame ?? lg?.shotsPerGame), bruto: `${shots.toFixed(2)}/j` },
                    { atributo: "Passes", jogador: scale(passAcc, pos?.passAccuracy ?? lg?.passAccuracy), bruto: passAcc !== null ? `${Math.round(passAcc * 100)}% precisão` : "sem amostra" },
                    { atributo: "Dribles/duelos", jogador: scale(dribbles, pos?.duelWinRate ? pos.duelWinRate * 10 : null), bruto: dribbles !== null ? `${dribbles.toFixed(1)} duelos ganhos/j` : "sem detalhe" },
                    { atributo: "Desarmes", jogador: scale(tackles, pos?.tacklesPerGame ?? lg?.tacklesPerGame), bruto: tackles !== null ? `${tackles.toFixed(2)}/j` : "sem detalhe" },
                    { atributo: "Gols", jogador: scale(goals + assists * 0.5, (pos?.goalsPerGame ?? 0) + (pos?.assistsPerGame ?? 0) * 0.5 || lg?.goalsPerGame), bruto: `${goals.toFixed(2)} G + ${assists.toFixed(2)} A /j` },
                  ];
                  return rows.map((r) => ({ atributo: r.atributo, jogador: r.jogador ?? 0, liga: 50, bruto: r.jogador === null ? `${r.bruto} (indisponível)` : r.bruto }));
                })()}
              />

              <section>
                <SectionHeader title="Comparação com a média" subtitle={`vs. ${POSITIONS[player.position]?.plural.toLowerCase()} da liga (${avg?.position.count}) e vs. todos os jogadores com minutos (${avg?.league.count})`} icon={<span>📊</span>} />
                <div className="grid gap-2 sm:grid-cols-2">
                  {[
                    { label: "Gols por jogo", mine: per(c.goals, c.appearances), pos: avg?.position.goalsPerGame, lg: avg?.league.goalsPerGame },
                    { label: "Assistências por jogo", mine: per(c.assists, c.appearances), pos: avg?.position.assistsPerGame, lg: avg?.league.assistsPerGame },
                    { label: "Finalizações por jogo", mine: per(c.shots, c.appearances), pos: avg?.position.shotsPerGame, lg: avg?.league.shotsPerGame },
                    { label: "Faltas cometidas por jogo", mine: per(c.foulsCommitted, c.appearances), pos: avg?.position.foulsCommittedPerGame, lg: avg?.league.foulsCommittedPerGame },
                    { label: "Faltas sofridas por jogo", mine: per(c.foulsSuffered, c.appearances), pos: avg?.position.foulsSufferedPerGame, lg: avg?.league.foulsSufferedPerGame },
                    { label: "Cartões por jogo", mine: per(c.yellowCards + c.redCards, c.appearances), pos: avg?.position.cardsPerGame, lg: avg?.league.cardsPerGame },
                    { label: "Impedimentos por jogo", mine: per(c.offsides, c.appearances), pos: avg?.position.offsidesPerGame, lg: avg?.league.offsidesPerGame },
                    ...(c.detailed ? [
                      { label: "Desarmes por jogo", mine: per(c.tackles ?? 0, c.appearances), pos: avg?.position.tacklesPerGame, lg: avg?.league.tacklesPerGame },
                      { label: "Interceptações por jogo", mine: per(c.interceptions ?? 0, c.appearances), pos: avg?.position.interceptionsPerGame, lg: avg?.league.interceptionsPerGame },
                    ] : []),
                  ].map((row) => (
                    <div key={row.label} className="card px-3 py-2.5">
                      <p className="mb-1.5 text-[0.72rem] font-bold">{row.label}</p>
                      <Bars rows={[
                        { label: player.shortName || player.name, value: row.mine, display: dec(row.mine), color: "var(--brand)" },
                        { label: `Média ${POSITIONS[player.position]?.plural.split(" ")[0].toLowerCase()}`, value: row.pos ?? null, display: dec(row.pos), color: "#38bdf8" },
                        { label: "Média da liga", value: row.lg ?? null, display: dec(row.lg), color: "#94a3b8" },
                      ]} />
                    </div>
                  ))}
                </div>
              </section>

              <section>
                <SectionHeader title="Estatísticas detalhadas" subtitle={c.detailed ? `Minutos, passes, defesa e eficiência · atualizado ${c.detailedAt ? new Date(c.detailedAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" }) : ""}` : "Ainda não disponíveis para este atleta na fonte"} icon={<span>🧾</span>} />
                {c.detailed ? (
                  <div className="card divide-y divide-[var(--line)] overflow-hidden text-[0.72rem]">
                    {[
                      ["Titularidades", `${c.starts ?? 0} de ${c.appearances} (${pct(c.starts ?? 0, c.appearances)})`],
                      ["Gols por 90 min", dec(p90(c.goals, c.minutes))],
                      ["Assistências por 90 min", dec(p90(c.assists, c.minutes))],
                      ["Participações (G+A) por 90", dec(p90(c.goals + c.assists, c.minutes))],
                      ["Pênaltis convertidos / cobrados", `${c.penaltyGoals ?? 0} / ${c.penaltyShots ?? 0}`],
                      ["Gols de cabeça", c.headedGoals ?? 0],
                      ["Grandes chances criadas", c.bigChancesCreated ?? 0],
                      ["Passes decisivos (p/ finalização)", c.shotAssists ?? 0],
                      ["Passes certos / total", `${c.accuratePasses ?? 0} / ${c.totalPasses ?? 0} (${pct(c.accuratePasses ?? 0, c.totalPasses ?? 0)})`],
                      ["Cruzamentos certos / total", `${c.accurateCrosses ?? 0} / ${c.totalCrosses ?? 0}`],
                      ["Toques na bola", c.touches ?? 0],
                      ["Desarmes certos / tentativas", `${c.tacklesWon ?? 0} / ${c.tackles ?? 0}`],
                      ["Interceptações", c.interceptions ?? 0],
                      ["Cortes / afastamentos", c.clearances ?? 0],
                      ["Finalizações bloqueadas", c.blockedShots ?? 0],
                      ["Bolas recuperadas", c.recoveries ?? 0],
                      ["Duelos ganhos / total", `${c.duelsWon ?? 0} / ${c.duels ?? 0} (${pct(c.duelsWon ?? 0, c.duels ?? 0)})`],
                      ["Faltas cometidas por 90", dec(p90(c.foulsCommitted, c.minutes))],
                      ["Cartões por 90", dec(p90(c.yellowCards + c.redCards, c.minutes))],
                      ...(player.position === "G" ? [
                        ["Defesas", c.saves],
                        ["Gols sofridos", c.goalsConceded],
                        ["% de defesas (def ÷ (def + GS))", pct(c.saves, c.saves + c.goalsConceded)],
                        ["Jogos sem sofrer gol", c.cleanSheets ?? 0],
                      ] : []),
                    ].map(([label, value]) => (
                      <div key={label as string} className="flex items-center justify-between gap-2 px-3 py-1.5">
                        <span className="muted">{label}</span>
                        <span className="font-bold tabular-nums">{value as string}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="card px-3 py-4 text-center text-[0.72rem] muted">A fonte ainda não publicou o detalhamento (minutos, passes, defesa) para este atleta nesta temporada.</div>
                )}
              </section>
            </>
          ) : (
            <PremiumLock title="Comparações e estatísticas detalhadas são exclusivas para contas ativas" description="Entre (1 dia grátis via Gmail) ou assine o VIP para ver comparação com a média da posição e da liga, minutos, passes, desarmes, duelos e métricas por 90." />
          )}

          <section className="card px-3 py-2.5 text-[0.62rem] leading-relaxed muted">
            <p><b className="text-[var(--ink)]">Fonte:</b> ESPN (estatísticas oficiais da temporada) · elenco atualizado a cada 6h · detalhamento por atleta atualizado ao abrir o perfil (cache 6h).</p>
            <p><b className="text-[var(--ink)]">Limitações:</b> evolução rodada a rodada não está disponível na fonte agregada por temporada; a posição segue a granularidade da fonte (G/D/M/F).</p>
          </section>
        </>
      ) : null}
      <CompareBar league={c?.leagueCode} season={c?.season} />
    </div>
  );
}

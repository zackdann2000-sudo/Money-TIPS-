import Link from "next/link";
import { Suspense } from "react";
import { accessInfo, getSessionUser } from "@/lib/auth";
import {
  availableSeasons,
  currentSeasonFor,
  enrichStalePlayers,
  formatMetric,
  getPlayersSyncState,
  loadStatRows,
  METRIC_CATEGORIES,
  METRICS,
  nationalitiesInLeague,
  PLAYER_LEAGUES,
  POSITIONS,
  rankRows,
  syncLeaguePlayers,
  teamsInLeague,
} from "@/lib/players";
import { AutoSubmitForm, CompareBar, CompareToggle, Skeleton } from "@/components/players";
import { PremiumLock, SectionHeader } from "@/components/ui";

export const dynamic = "force-dynamic";

type Search = Record<string, string | undefined>;

function PlayerAvatar({ src, name, size = 32 }: { src: string; name: string; size?: number }) {
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={name} width={size} height={size} loading="lazy" className="shrink-0 rounded-full bg-[var(--surface-3)] object-cover" style={{ width: size, height: size }} />;
  }
  return (
    <span className="flex shrink-0 items-center justify-center rounded-full bg-[var(--surface-3)] text-[0.6rem] font-black muted" style={{ width: size, height: size }}>
      {name.split(" ").slice(0, 2).map((p) => p[0]).join("")}
    </span>
  );
}

async function Rankings({ sp }: { sp: Search }) {
  const league = PLAYER_LEAGUES.some((l) => l.code === sp.liga) ? sp.liga! : "bra.1";
  const category = METRIC_CATEGORIES.some((c) => c.key === sp.cat) ? sp.cat! : "gols";
  const metricsInCategory = METRICS.filter((m) => m.category === category);
  const metric = metricsInCategory.find((m) => m.key === sp.metrica) ?? metricsInCategory[0];
  const position = ["G", "D", "M", "F"].includes(sp.posicao ?? "") ? sp.posicao : undefined;
  const order = sp.ordem === "asc" ? "asc" : "desc";
  const minApps = Math.min(60, Math.max(0, Number(sp.minJogos ?? 3) || 0));
  const minMinutes = Math.min(6000, Math.max(0, Number(sp.minMinutos ?? 0) || 0));
  const page = Math.max(1, Number(sp.pagina ?? 1) || 1);

  const session = await getSessionUser();
  const hasAccess = session ? accessInfo(session).active : false;

  let syncError: string | null = null;
  const state = await getPlayersSyncState(league);
  if (!state?.lastSuccessAt) {
    const result = await syncLeaguePlayers(league);
    if (!result.ok) syncError = result.message;
  } else if (Date.now() - new Date(state.lastSuccessAt).getTime() > 6 * 60 * 60 * 1000) {
    void syncLeaguePlayers(league).catch(() => undefined);
  }
  const seasons = await availableSeasons(league);
  const season = Number(sp.temporada) && seasons.includes(Number(sp.temporada)) ? Number(sp.temporada) : ((await currentSeasonFor(league)) ?? undefined);
  if (metric.needsDetailed && season) await enrichStalePlayers(league, season, 60).catch(() => undefined);

  const [rows, teams, nationalities, freshState] = await Promise.all([
    loadStatRows({ league, season, team: sp.time || undefined, position }),
    teamsInLeague(league, season),
    nationalitiesInLeague(league),
    getPlayersSyncState(league),
  ]);
  const result = rankRows(rows, { metric: metric.key, minApps, minMinutes, order, search: sp.q, nationality: sp.pais, page, pageSize: 25 });
  const leagueInfo = PLAYER_LEAGUES.find((l) => l.code === league)!;
  const totalPages = Math.max(1, Math.ceil(result.total / 25));
  const visibleItems = hasAccess ? result.items : result.items.slice(0, page === 1 ? 10 : 0);
  const detailedCount = rows.filter((r) => r.detailed).length;
  const playedCount = rows.filter((r) => r.appearances > 0).length;

  const qs = (extra: Record<string, string | number | undefined>) => {
    const params = new URLSearchParams();
    const merged: Record<string, string | number | undefined> = { liga: league, temporada: season, cat: category, metrica: metric.key, posicao: position, time: sp.time, pais: sp.pais, q: sp.q, minJogos: minApps, minMinutos: minMinutes || undefined, ordem: order, ...extra };
    for (const [k, v] of Object.entries(merged)) if (v !== undefined && v !== "" && v !== null) params.set(k, String(v));
    return `/jogadores?${params.toString()}`;
  };

  return (
    <>
      <section className="card relative overflow-hidden border-0 brand-gradient px-4 py-4 text-white">
        <div className="pointer-events-none absolute inset-0 pitch opacity-25" />
        <div className="relative">
          <span className="chip !border-white/25 !bg-white/15 !text-white">CENTRAL DE JOGADORES</span>
          <h1 className="mt-1.5 text-xl font-black leading-tight">Rankings da temporada {season ?? ""}</h1>
          <p className="text-[0.72rem] text-emerald-50/85">{leagueInfo.flag} {leagueInfo.name} · {playedCount} jogadores com minutos · {rows.length} no elenco · {detailedCount} com estatísticas completas</p>
          <div className="mt-2 flex flex-wrap gap-1.5 text-[0.6rem] font-semibold">
            <span className="rounded-full bg-white/15 px-2 py-0.5">Fonte: ESPN (dados oficiais)</span>
            <span className="rounded-full bg-white/15 px-2 py-0.5">Atualizado: {freshState?.lastSuccessAt ? new Date(freshState.lastSuccessAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" }) : "—"}</span>
            <span className="rounded-full bg-white/15 px-2 py-0.5">Elencos a cada 6h · estatísticas detalhadas progressivas</span>
          </div>
        </div>
      </section>

      {syncError ? <div className="card border-rose-500/40 px-3 py-2.5 text-[0.72rem]"><b className="text-rose-500">Falha ao obter dados da fonte:</b> {syncError}. Tente novamente em instantes.</div> : null}

      <AutoSubmitForm action="/jogadores">
        <input type="hidden" name="cat" value={category} />
        <div className="card grid grid-cols-2 gap-2 px-3 py-3 sm:grid-cols-3 lg:grid-cols-4">
          <div><label className="label">Liga / campeonato</label>
            <select name="liga" defaultValue={league} className="input !py-1.5 !text-[0.78rem]">
              {PLAYER_LEAGUES.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name} · {l.country}</option>)}
            </select></div>
          <div><label className="label">Temporada</label>
            <select name="temporada" defaultValue={season ?? ""} className="input !py-1.5 !text-[0.78rem]">
              {seasons.length ? seasons.map((s) => <option key={s} value={s}>{s}{s >= 2000 && league !== "bra.1" && league !== "bra.2" && league !== "bra.copa_do_brazil" && league !== "arg.1" && league !== "usa.1" && !league.startsWith("conmebol") ? `/${String(s + 1).slice(-2)}` : ""}</option>) : <option value="">atual</option>}
            </select></div>
          <div><label className="label">Time</label>
            <select name="time" defaultValue={sp.time ?? ""} className="input !py-1.5 !text-[0.78rem]">
              <option value="">Todos os times</option>
              {teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select></div>
          <div><label className="label">Posição</label>
            <select name="posicao" defaultValue={position ?? ""} className="input !py-1.5 !text-[0.78rem]">
              <option value="">Todas</option>
              {Object.entries(POSITIONS).map(([k, v]) => <option key={k} value={k}>{v.plural}</option>)}
            </select></div>
          <div><label className="label">Estatística</label>
            <select name="metrica" defaultValue={metric.key} className="input !py-1.5 !text-[0.78rem]">
              {metricsInCategory.map((m) => <option key={m.key} value={m.key}>{m.label}</option>)}
            </select></div>
          <div><label className="label">Mín. de jogos</label>
            <select name="minJogos" defaultValue={String(minApps)} className="input !py-1.5 !text-[0.78rem]">
              {[0, 1, 3, 5, 10, 15, 20].map((v) => <option key={v} value={v}>{v === 0 ? "Sem mínimo" : `${v}+ jogos`}</option>)}
            </select></div>
          <div><label className="label">Mín. de minutos</label>
            <select name="minMinutos" defaultValue={String(minMinutes)} className="input !py-1.5 !text-[0.78rem]">
              {[0, 90, 270, 450, 900, 1500].map((v) => <option key={v} value={v}>{v === 0 ? "Sem mínimo" : `${v}+ min`}</option>)}
            </select></div>
          <div><label className="label">Ordem</label>
            <select name="ordem" defaultValue={order} className="input !py-1.5 !text-[0.78rem]">
              <option value="desc">Maior → menor</option>
              <option value="asc">Menor → maior</option>
            </select></div>
          <div><label className="label">Nacionalidade</label>
            <select name="pais" defaultValue={sp.pais ?? ""} className="input !py-1.5 !text-[0.78rem]">
              <option value="">Todas</option>
              {nationalities.map((c) => <option key={c} value={c}>{c}</option>)}
            </select></div>
          <div className="col-span-2 sm:col-span-2 lg:col-span-3"><label className="label">Jogador</label>
            <div className="flex gap-1.5">
              <input name="q" defaultValue={sp.q ?? ""} placeholder="Buscar por nome do jogador ou clube…" className="input !py-1.5 !text-[0.78rem]" />
              <button className="btn btn-primary !px-3 !py-1.5 !text-[0.72rem]">Filtrar</button>
              <Link href={`/jogadores?liga=${league}`} className="btn btn-ghost !px-3 !py-1.5 !text-[0.72rem]">Limpar</Link>
            </div></div>
        </div>
      </AutoSubmitForm>

      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3 lg:mx-0 lg:px-0">
        {METRIC_CATEGORIES.map((c) => (
          <Link key={c.key} href={qs({ cat: c.key, metrica: METRICS.find((m) => m.category === c.key)?.key, pagina: 1 })} className={`chip !px-3 !py-1.5 ${category === c.key ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}>
            {c.icon} {c.label}
          </Link>
        ))}
      </div>
      <p className="px-1 text-[0.64rem] leading-relaxed muted">{METRIC_CATEGORIES.find((c) => c.key === category)?.description}</p>

      <section>
        <SectionHeader
          title={`${metric.label} — ${order === "asc" ? "menores" : "maiores"} valores`}
          subtitle={`${result.total} jogador(es) no ranking${metric.minSample ? ` · ${metric.minSample.label}` : ""}${result.excludedForSample ? ` · ${result.excludedForSample} fora por amostra insuficiente` : ""}${metric.note ? ` · ${metric.note}` : ""}`}
          icon={<span>🏅</span>}
        />
        {metric.needsDetailed && detailedCount < playedCount ? (
          <p className="mb-1.5 rounded-lg bg-amber-500/10 px-2.5 py-1.5 text-[0.62rem] text-amber-700 dark:text-amber-300">
            Esta métrica usa estatísticas detalhadas (minutos, passes, desarmes…). {detailedCount} de {playedCount} jogadores já têm esses dados; os demais são carregados progressivamente a cada acesso e entram no ranking automaticamente.
          </p>
        ) : null}
        {result.total === 0 ? (
          <div className="card px-4 py-8 text-center text-[0.78rem] muted">Nenhum jogador atende aos filtros. Reduza o mínimo de jogos/minutos ou altere a posição.</div>
        ) : (
          <div className="card overflow-hidden">
            <div className="hidden grid-cols-[2.2rem_1fr_3.4rem_3.4rem_4.5rem_3.8rem_3.8rem_5.6rem] items-center gap-2 border-b px-3 py-1.5 text-[0.55rem] font-bold uppercase tracking-wide muted hairline sm:grid">
              <span>#</span><span>Jogador</span><span className="text-center">Jogos</span><span className="text-center">Min.</span><span className="text-right">{metric.short}</span><span className="text-right">/jogo</span><span className="text-right">/90</span><span></span>
            </div>
            {visibleItems.map((item) => {
              const p = item.stat.player;
              const medal = item.rank === 1 ? "🥇" : item.rank === 2 ? "🥈" : item.rank === 3 ? "🥉" : null;
              return (
                <div key={item.stat.id} className={`grid grid-cols-[2rem_1fr_auto] items-center gap-2 border-b px-3 py-2 last:border-0 hairline sm:grid-cols-[2.2rem_1fr_3.4rem_3.4rem_4.5rem_3.8rem_3.8rem_5.6rem] ${item.rank <= 3 ? "bg-emerald-500/[0.04]" : ""}`}>
                  <span className={`text-[0.72rem] font-black tabular-nums ${item.rank <= 3 ? "text-emerald-500" : "muted"}`}>{medal ?? item.rank}</span>
                  <Link href={`/jogadores/${p.id}?liga=${league}${season ? `&temporada=${season}` : ""}`} className="flex min-w-0 items-center gap-2">
                    <PlayerAvatar src={p.headshot} name={p.name} />
                    <span className="min-w-0">
                      <span className="block truncate text-[0.78rem] font-bold">{p.name}</span>
                      <span className="flex items-center gap-1 truncate text-[0.58rem] muted">
                        {item.stat.teamLogo ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={item.stat.teamLogo} alt="" width={12} height={12} className="h-3 w-3 object-contain" /> : null}
                        {item.stat.teamName} · {POSITIONS[p.position]?.label ?? p.position}{p.nationality ? ` · ${p.nationality}` : ""}
                        <span className="sm:hidden"> · {item.stat.appearances}j{item.stat.minutes ? ` · ${item.stat.minutes}′` : ""}</span>
                      </span>
                    </span>
                  </Link>
                  <span className="hidden text-center text-[0.7rem] tabular-nums muted sm:block">{item.stat.appearances}</span>
                  <span className="hidden text-center text-[0.7rem] tabular-nums muted sm:block">{item.stat.minutes ?? "—"}</span>
                  <span className="text-right text-[0.9rem] font-black tabular-nums text-emerald-500 sm:text-[0.85rem]">
                    {formatMetric(item.value, metric)}
                    <span className="block text-[0.52rem] font-semibold muted sm:hidden">{metric.format ? "" : `${formatMetric(item.perGame, { ...metric, format: "dec" })}/j`}</span>
                  </span>
                  <span className="hidden text-right text-[0.66rem] tabular-nums muted sm:block">{metric.format ? "—" : formatMetric(item.perGame, { ...metric, format: "dec" })}</span>
                  <span className="hidden text-right text-[0.66rem] tabular-nums muted sm:block">{metric.format ? "—" : formatMetric(item.per90, { ...metric, format: "dec" })}</span>
                  <span className="col-span-3 flex justify-end sm:col-span-1"><CompareToggle playerId={p.id} compact /></span>
                </div>
              );
            })}
          </div>
        )}
        {!hasAccess && result.total > visibleItems.length ? (
          <div className="mt-2"><PremiumLock title={`Mais ${result.total - visibleItems.length} jogadores neste ranking`} description="Visitantes veem o top 10. Entre com sua conta (1 dia grátis via Gmail) ou assine o VIP para ver o ranking completo, perfis detalhados e o comparador." /></div>
        ) : null}
        {hasAccess && totalPages > 1 ? (
          <div className="mt-2 flex items-center justify-between">
            <Link href={qs({ pagina: Math.max(1, page - 1) })} className={`btn btn-ghost !py-1.5 !text-[0.7rem] ${page <= 1 ? "pointer-events-none opacity-40" : ""}`}>← Anterior</Link>
            <span className="text-[0.66rem] muted">Página {page} de {totalPages} · 25 por página</span>
            <Link href={qs({ pagina: Math.min(totalPages, page + 1) })} className={`btn btn-ghost !py-1.5 !text-[0.7rem] ${page >= totalPages ? "pointer-events-none opacity-40" : ""}`}>Próxima →</Link>
          </div>
        ) : null}
      </section>

      <section className="card px-3 py-2.5 text-[0.64rem] leading-relaxed muted">
        <p className="text-[0.74rem] font-bold text-[var(--ink)]">Metodologia e transparência</p>
        <p>• <b>Por partida</b> = valor ÷ jogos disputados. <b>Por 90</b> = valor ÷ minutos × 90 (exige minutos, carregados progressivamente).</p>
        <p>• <b>Total de cartões</b> = amarelos + vermelhos. <b>% de defesas</b> = defesas ÷ (defesas + gols sofridos). <b>Regularidade</b> = jogos como titular ÷ jogos.</p>
        <p>• Posições seguem a granularidade da fonte (goleiro, defensor, meio-campista, atacante). Escanteios individuais, gols de fora da área e duelos aéreos não são fornecidos e por isso não aparecem.</p>
        <p>• Valores zerados são omitidos das listas decrescentes. Nenhum número é estimado ou inventado.</p>
      </section>
      <CompareBar league={league} season={season} />
    </>
  );
}

export default async function PlayersPage({ searchParams }: { searchParams: Promise<Search> }) {
  const sp = await searchParams;
  return (
    <div className="space-y-4">
      <Suspense fallback={<div className="space-y-3"><div className="card h-28 animate-pulse" /><Skeleton rows={10} /></div>}>
        <Rankings sp={sp} />
      </Suspense>
    </div>
  );
}

import Detector from "@/components/detector";
import { CATEGORIAS, LIGAS } from "@/lib/detector";

export const dynamic = "force-dynamic";

export default function DetectorPage() {
  return <Detector categorias={CATEGORIAS} ligas={LIGAS} />;
}

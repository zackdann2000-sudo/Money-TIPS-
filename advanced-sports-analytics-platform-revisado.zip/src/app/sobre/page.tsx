import Link from "next/link";
import { SectionHeader } from "@/components/ui";

export const dynamic = "force-static";

const FEATURES = [
  { icon: "⚽", title: "Placar e eventos ao vivo", text: "Gols, pênaltis, cartões amarelos e vermelhos, faltas, impedimentos e escanteios registrados minuto a minuto, com placar e estatísticas atualizados." },
  { icon: "📊", title: "Estatísticas completas", text: "Posse de bola, finalizações, finalizações no alvo, xG, escanteios, faltas, cartões e impedimentos — total e por equipe." },
  { icon: "📋", title: "Escalação prevista", text: "Prováveis titulares, formação e confiança do modelo por time, construída a partir de minutagem, histórico de escalações e dados públicos." },
  { icon: "🛡️", title: "Perfil dos times", text: "Últimos jogos, forma (V/E/D), desempenho ofensivo e defensivo, over 2,5, ambas marcam, clean sheets e médias por partida." },
  { icon: "🔔", title: "Notificações inteligentes", text: "Alertas de gol, escanteio, falta, impedimento, pênalti, cartão, fim de jogo e escalação prevista — com aviso quando seu time favorito entra em campo." },
  { icon: "🔎", title: "Análises e oportunidades", text: "Cruzamento de médias reais das ligas com o histórico dos confrontos, exibindo mercados com nível de confiança e odd de referência." },
  { icon: "👑", title: "Painel do proprietário", text: "Cadastro de times e jogos, controle de lances ao vivo, usuários ativos e expirados, receita e integrações de API em um só lugar." },
  { icon: "🌗", title: "Tema claro e escuro", text: "Interface mobile-first no estilo dos grandes apps de placar, com tabelas compactas, navegação inferior e leitura confortável." },
];

export default function AboutPage() {
  return (
    <div className="space-y-4">
      <section className="card relative overflow-hidden border-0 brand-gradient px-4 py-5 text-white">
        <div className="pointer-events-none absolute inset-0 pitch opacity-30" />
        <div className="relative">
          <span className="chip !border-white/25 !bg-white/15 !text-white">SOBRE O GREENSCORE</span>
          <h1 className="mt-2 text-xl font-black leading-tight">Seu centro de estatísticas do futebol</h1>
          <p className="mt-1 max-w-lg text-[0.72rem] leading-relaxed text-emerald-50/85">
            O GreenScore reúne placar ao vivo, eventos detalhados, desempenho dos times, escalações previstas e análises estatísticas
            em uma experiência pensada primeiro para o celular. Inspirado na profundidade dos grandes agregadores de futebol.
          </p>
          <div className="mt-3 flex gap-2">
            <Link href="/jogos" className="btn !bg-white !text-emerald-900">Ver jogos</Link>
            <Link href="/planos" className="btn !border-white/30 !bg-white/10 !text-white">Conhecer o VIP</Link>
          </div>
        </div>
      </section>

      <section>
        <SectionHeader title="Tudo que está incluído" subtitle="Do lance ao vivo à análise de mercado" />
        <div className="grid gap-2 sm:grid-cols-2">
          {FEATURES.map((feature) => (
            <div key={feature.title} className="card px-3 py-2.5">
              <p className="text-[0.8rem] font-extrabold">{feature.icon} {feature.title}</p>
              <p className="mt-0.5 text-[0.66rem] leading-relaxed muted">{feature.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card px-3 py-3">
        <SectionHeader title="Como funcionam as notificações" subtitle="Alertas por time favorito" />
        <div className="space-y-1 text-[0.68rem] leading-relaxed muted">
          <p>1. Crie sua conta (Gmail libera 1 dia grátis; outros domínios, 6 horas de teste).</p>
          <p>2. Abra um time e toque em <b>☆ Favoritar</b> ou ative os alertas em <b>Minha conta</b>.</p>
          <p>3. Ao gerar/ocorrer um lance do time, os usuários que o favoritaram recebem uma notificação com placar e minuto.</p>
          <p>4. A faixa “em campo agora” aparece automaticamente quando um dos seus favoritos está jogando.</p>
          <p>5. Todos os alertas ficam salvos em <b>Notificações</b>, onde é possível marcar como lidos e remover.</p>
        </div>
      </section>

      <section className="card px-3 py-3">
        <SectionHeader title="Acesso, planos e expiração" subtitle="Cada conta possui uma data limite" />
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[0.66rem]">
            <thead className="border-b hairline">
              <tr className="muted"><th className="py-1">Origem</th><th className="py-1">Duração</th><th className="py-1">Depois</th></tr>
            </thead>
            <tbody>
              {[
                ["Cadastro com Gmail", "1 dia (24h) grátis", "Assinar VIP"],
                ["Cadastro com outro e-mail", "6 horas de teste", "Assinar VIP"],
                ["VIP diário", "1 dia", "Renovar"],
                ["VIP semanal", "7 dias", "Renovar"],
                ["VIP mensal", "30 dias", "Renovar"],
                ["VIP anual", "365 dias", "Renovar"],
              ].map((row) => (
                <tr key={row[0]} className="border-b last:border-0 hairline">
                  <td className="py-1 font-semibold">{row[0]}</td><td className="py-1">{row[1]}</td><td className="py-1 muted">{row[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-1.5 text-[0.62rem] leading-relaxed muted">
          Ao expirar, o usuário continua logado, mas vê paywall nas estatísticas detalhadas, escalações previstas e análises. O painel do
          proprietário permite consultar quem está ativo, expirado, últimos logins e liberar dias como cortesia.
        </p>
      </section>

      <section className="card px-3 py-3">
        <SectionHeader title="Dados e integrações" subtitle="Fontes reais + modelo próprio" />
        <div className="space-y-1 text-[0.66rem] leading-relaxed muted">
          <p>• Médias e históricos combinam dados públicos das temporadas 2025/26 (Brasileirão, Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions e Libertadores).</p>
          <p>• A aba <b>APIs de dados</b> do painel permite conectar provedores como API-Football, Football-Data.org e TheSportsDB para atualização automática.</p>
          <p>• As escalações previstas são projeções estatísticas — não substituem a escalação oficial divulgada pelos clubes.</p>
          <p>• Este projeto é uma demonstração funcional completa: cadastro, assinatura, expiração, painel, notificações e banco de dados PostgreSQL.</p>
        </div>
      </section>

      <section className="card px-3 py-3">
        <SectionHeader title="Perguntas frequentes" />
        <div className="space-y-2">
          {[
            ["Preciso instalar aplicativo?", "Não. O GreenScore é web e funciona no navegador do celular. Você pode adicionar à tela inicial para abrir como um app."],
            ["Como recebo os alertas?", "Favoritando seu time e mantendo o acesso ativo. Os alertas aparecem na tela, na central de notificações e no histórico do jogo."],
            ["Posso usar no computador?", "Sim. A interface mobile-first se adapta ao desktop com menu lateral e visualizações ampliadas."],
            ["As análises garantem acerto?", "Não. São projeções informativas baseadas em dados. Aposte apenas se for maior de 18 anos e com responsabilidade."],
          ].map(([question, answer]) => (
            <div key={question}>
              <p className="text-[0.74rem] font-bold">{question}</p>
              <p className="text-[0.64rem] leading-relaxed muted">{answer}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card flex flex-col items-center gap-2 px-4 py-4 text-center">
        <p className="text-[0.9rem] font-black">Comece agora com 1 dia grátis</p>
        <p className="max-w-sm text-[0.68rem] muted">Cadastre-se com Gmail e tenha acesso completo aos jogos, estatísticas, escalações e alertas.</p>
        <div className="flex gap-2">
          <Link href="/cadastro" className="btn btn-primary">Criar conta</Link>
          <Link href="/login" className="btn btn-ghost">Entrar</Link>
        </div>
      </section>
    </div>
  );
}

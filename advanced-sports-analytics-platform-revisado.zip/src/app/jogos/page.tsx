import Link from "next/link";
import { getLeagues, getMatches, getMatchesByDay } from "@/lib/data";
import { MatchRow, SectionHeader, DataSourceBadge } from "@/components/ui";
import { getSyncStatus } from "@/lib/espn";
import { syncNowAction } from "@/app/actions";
import { xgForList } from "@/lib/analysis-cache";
import { LiveRefresher } from "@/components/client";
import { dayKey, dayLabel } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function MatchesPage({ searchParams }: { searchParams: Promise<{ f?: string; liga?: string; dia?: string; sync?: string }> }) {
  const params = await searchParams;
  const filter = params.f ?? "all";
  const [leagues, all] = await Promise.all([getLeagues(), getMatches()]);
  const sync = await getSyncStatus().catch(() => null);
  const todayKey = dayKey(new Date());
  const dayFilter = params.dia ?? (filter === "all" ? "hoje" : "todos");
  const league = leagues.find((l) => l.slug === params.liga);

  let matches = all;
  if (league) matches = matches.filter((m) => m.leagueId === league.id);
  if (filter === "live") matches = matches.filter((m) => m.status === "live");
  if (filter === "finished") matches = matches.filter((m) => m.status === "finished");
  if (filter === "scheduled") matches = matches.filter((m) => m.status === "scheduled");
  if (dayFilter === "hoje") matches = matches.filter((m) => dayKey(m.kickoff) === todayKey);
  if (dayFilter === "ontem") matches = matches.filter((m) => dayKey(m.kickoff) === dayKey(new Date(Date.now() - 86400000)));
  if (dayFilter === "amanha") matches = matches.filter((m) => dayKey(m.kickoff) === dayKey(new Date(Date.now() + 86400000)));

  const days = await getMatchesByDay();
  const groups = new Map<string, typeof matches>();
  for (const match of matches) {
    const key = dayKey(match.kickoff);
    groups.set(key, [...(groups.get(key) ?? []), match]);
  }
  const grouped = [...groups.entries()].sort(([a], [b]) => a.localeCompare(b));
  const live = all.filter((m) => m.status === "live");
  const xg = await xgForList(matches.slice(0, 40)).catch(() => ({} as Record<number, { home: number; away: number; source: string }>));
  const q = (f: string, d: string) => `/jogos?f=${f}&dia=${d}${league ? `&liga=${league.slug}` : ""}`;

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between px-1">
        <div>
          <h1 className="text-xl font-black tracking-tight">Jogos & estatísticas</h1>
          <p className="text-[0.7rem] muted">{days.reduce((sum, d) => sum + d.list.length, 0)} partidas reais (ontem, hoje e amanhã) · {live.length} ao vivo agora</p>
        </div>
        <LiveRefresher />
      </div>

      <div className="flex flex-wrap items-center gap-1.5 px-1">
        <DataSourceBadge lastSuccessAt={sync?.lastSuccessAt} matches={sync?.matchesSynced ?? 0} />
        <form action={syncNowAction}>
          <input type="hidden" name="redirectTo" value="/jogos" />
          <button className="chip hover:!text-emerald-500">🔄 atualizar agora</button>
        </form>
        {params.sync === "ok" ? <span className="chip !text-emerald-500">sincronizado ✓</span> : null}
        {params.sync === "erro" ? <span className="chip !text-rose-500">falha ao sincronizar</span> : null}
      </div>

      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3 lg:mx-0 lg:px-0">
        {[
          { key: "ontem", label: "Ontem" },
          { key: "hoje", label: "📅 Hoje" },
          { key: "amanha", label: "Amanhã" },
          { key: "todos", label: "Todos" },
        ].map((item) => (
          <Link key={item.key} href={q(filter, item.key)} className={`chip !px-3 !py-1.5 ${dayFilter === item.key ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}>
            {item.label}
          </Link>
        ))}
      </div>

      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3 lg:mx-0 lg:px-0">
        {[
          { key: "all", label: "Todos" },
          { key: "live", label: `🔴 Ao vivo (${live.length})` },
          { key: "scheduled", label: "Agendados" },
          { key: "finished", label: "Encerrados" },
        ].map((item) => (
          <Link
            key={item.key}
            href={q(item.key, item.key === "all" ? dayFilter : "todos")}
            className={`chip !px-3 !py-1.5 ${filter === item.key ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}
          >
            {item.label}
          </Link>
        ))}
      </div>

      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3 pb-1 lg:mx-0 lg:px-0">
        <Link href={`/jogos?f=${filter}&dia=${dayFilter}`} className={`chip !py-1 ${!league ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>🌍 Todas as ligas</Link>
        {leagues.filter((l) => all.some((m) => m.leagueId === l.id)).map((item) => (
          <Link key={item.id} href={`/jogos?f=${filter}&dia=${dayFilter}&liga=${item.slug}`} className={`chip !py-1 ${league?.id === item.id ? "!border-emerald-500/50 !text-emerald-500" : ""}`}>
            {item.flag} {item.name}
          </Link>
        ))}
      </div>

      {grouped.length === 0 ? (
        <div className="card flex flex-col items-center gap-2 px-4 py-8 text-center">
          <span className="text-2xl">📭</span>
          <p className="text-[0.82rem] font-bold">Nenhuma partida para este filtro</p>
          <p className="text-[0.68rem] muted">Experimente outro dia ou limpe os filtros para ver todas as competições.</p>
          <div className="mt-1 flex flex-wrap justify-center gap-1.5">
            <Link href={q("all", dayFilter === "amanha" ? "todos" : "amanha")} className="btn btn-primary !px-3 !py-1.5 !text-[0.7rem]">{dayFilter === "amanha" ? "Ver todos os jogos" : "Ver jogos de amanhã"}</Link>
            <Link href="/jogos?f=all&dia=todos" className="btn btn-ghost !px-3 !py-1.5 !text-[0.7rem]">Limpar filtros</Link>
          </div>
        </div>
      ) : (
        grouped.map(([day, list]) => (
          <section key={day}>
            <div className="mb-1.5 flex items-center justify-between px-1">
              <h2 className="text-[0.8rem] font-extrabold">{dayLabel(day)}</h2>
              <span className="text-[0.6rem] muted">{new Date(`${day}T12:00:00`).toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" })}</span>
            </div>
            <div className="space-y-1.5">
              {list.map((match) => <MatchRow key={match.id} match={match} xg={xg[match.id] ?? null} />)}
            </div>
          </section>
        ))
      )}

      <section className="card px-3 py-2.5">
        <p className="mb-1.5 text-[0.7rem] font-bold">Legenda</p>
        <div className="grid grid-cols-3 gap-1 text-[0.58rem] sm:grid-cols-5">
          {[
            ["⚽", "Gols e placar"], ["🚩", "Escanteios"], ["🟨", "Cartões amarelos/vermelhos"],
            ["✋", "Faltas cometidas"], ["🚫", "Impedimentos"], ["🎯", "Finalizações e xG"],
            ["⏱️", "Posse de bola"], ["🥅", "Pênaltis"], ["📋", "Escalação prevista"],
          ].map(([icon, label]) => (
            <div key={label} className="flex items-center gap-1 rounded-md bg-[var(--surface-3)] px-1.5 py-1">
              <span>{icon}</span>
              <span className="truncate font-semibold">{label}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

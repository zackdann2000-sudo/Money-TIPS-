import Link from "next/link";
import { notFound } from "next/navigation";
import MatchDetails, { mockEvents, type MatchEvent, type MatchLineup, type MatchStat } from "@/components/match-details";
import { getMatchById } from "@/lib/data";
import { formatKickoff } from "@/lib/utils";

export const dynamic = "force-dynamic";

const statusLabel = (status: string, minute: number, detail: string) => (status === "finished" ? "Encerrado" : status === "live" ? (/HT|intervalo/i.test(detail) ? "Intervalo" : `${minute}'`) : "Agendado");

/** Converte os eventos reais (tabela match_events) para a estrutura da timeline. */
function toTimeline(events: { minute: number; half: number; type: string; side: string; player: string; detail: string; scoreAfter: string }[]): MatchEvent[] {
  const out: MatchEvent[] = [];
  for (const e of events) {
    if (e.side !== "home" && e.side !== "away") continue;
    const time = e.side === "home" ? "casa" : "fora";
    const minuto = e.minute > 90 ? `90+${e.minute - 90}'` : e.half === 1 && e.minute > 45 ? `45+${e.minute - 45}'` : `${e.minute}'`;
    if (e.type === "goal" || e.type === "penalty") {
      const assist = e.detail.match(/assistência:\s*(.+)$/)?.[1];
      const missed = /perdido/i.test(e.detail);
      const own = /contra/i.test(e.detail);
      out.push({ minuto, tipo: missed ? "penalti_perdido" : own ? "gol_contra" : e.type === "penalty" ? "penalti" : "gol", time, jogador: e.player, assistencia: assist?.trim(), placar: missed ? undefined : e.scoreAfter || undefined });
    } else if (e.type === "yellow" || e.type === "card") out.push({ minuto, tipo: "cartao_amarelo", time, jogador: e.player });
    else if (e.type === "red") out.push({ minuto, tipo: "cartao_vermelho", time, jogador: e.player });
    else if (e.type === "sub") {
      const m = e.detail.match(/sai\s+(.+?),\s+entra\s+(.+?)(?:\s+\(lesão\))?$/);
      out.push({ minuto, tipo: "substituicao", time, jogador_saiu: m?.[1] ?? "—", jogador_entrou: m?.[2] ?? e.player, observacao: /lesão/.test(e.detail) ? "por lesão" : undefined });
    } else if (e.type === "var") out.push({ minuto, tipo: "var", time, jogador: e.player || "VAR", observacao: e.detail });
  }
  return out;
}

export default async function MatchDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await getMatchById(Number(id));
  if (!data) notFound();
  const { match, events, lineups } = data;
  const real = toTimeline(events);
  const demo = real.length === 0 && match.status !== "scheduled";
  const eventos = demo ? mockEvents : real;

  const estatisticas: MatchStat[] = match.homeShots + match.awayShots > 0 ? [
    { label: "Posse de bola", casa: match.homePossession, fora: match.awayPossession, sufixo: "%", icone: "⏱️" },
    { label: "Finalizações", casa: match.homeShots, fora: match.awayShots, icone: "🎯" },
    { label: "No alvo", casa: match.homeShotsOnTarget, fora: match.awayShotsOnTarget, icone: "🥅" },
    { label: "Escanteios", casa: match.homeCorners, fora: match.awayCorners, icone: "🚩" },
    { label: "Faltas", casa: match.homeFouls, fora: match.awayFouls, icone: "✋" },
    { label: "Cartões", casa: match.homeCards, fora: match.awayCards, icone: "🟨" },
    { label: "Impedimentos", casa: match.homeOffsides, fora: match.awayOffsides, icone: "🚫" },
  ] : [];
  const avancadas: MatchStat[] = match.homeShots + match.awayShots > 0 ? [
    { label: "Precisão (no alvo %)", casa: Math.round((match.homeShotsOnTarget / Math.max(1, match.homeShots)) * 100), fora: Math.round((match.awayShotsOnTarget / Math.max(1, match.awayShots)) * 100), sufixo: "%" },
    { label: "Fora do alvo", casa: match.homeShots - match.homeShotsOnTarget, fora: match.awayShots - match.awayShotsOnTarget },
    { label: "Gols por finalização no alvo %", casa: Math.round((match.homeScore / Math.max(1, match.homeShotsOnTarget)) * 100), fora: Math.round((match.awayScore / Math.max(1, match.awayShotsOnTarget)) * 100), sufixo: "%" },
    { label: "Faltas por cartão", casa: Math.round(match.homeFouls / Math.max(1, match.homeCards)), fora: Math.round(match.awayFouls / Math.max(1, match.awayCards)) },
  ] : [];
  const toLineup = (teamId: number): MatchLineup | null => {
    const l = lineups.find((x) => x.teamId === teamId);
    return l ? { formacao: l.formation, titulares: l.players.slice(0, 11).map((p) => ({ numero: p.number, nome: p.name, posicao: p.pos })) } : null;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Link href={`/jogos/${match.id}`} className="chip">← Página do jogo</Link>
        <span className="chip">{match.leagueFlag} {match.leagueName}</span>
      </div>
      <MatchDetails
        casa={{ nome: match.homeName, sigla: match.homeShort, escudo: match.homeLogo || undefined, cor: match.homeColor }}
        fora={{ nome: match.awayName, sigla: match.awayShort, escudo: match.awayLogo || undefined, cor: match.awayColor }}
        placar={{ casa: match.homeScore, fora: match.awayScore }}
        status={statusLabel(match.status, match.minute, match.statusDetail)}
        competicao={`${match.leagueName ?? "Competição"} · ${match.round}`}
        dataHora={formatKickoff(match.kickoff, true)}
        estadio={match.venue || undefined}
        eventos={eventos}
        estatisticas={estatisticas}
        avancadas={avancadas}
        formacoes={{ casa: toLineup(match.homeId), fora: toLineup(match.awayId) }}
        fonte={demo ? "Sem eventos da fonte para este jogo — exibindo mockEvents de demonstração" : `Fonte: ESPN · atualizado ${formatKickoff(match.updatedAt, true)}`}
        demo={demo}
      />
    </div>
  );
}

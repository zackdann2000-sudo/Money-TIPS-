import Link from "next/link";
import { notFound } from "next/navigation";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { players, playerSeasonStats, teams } from "@/db/schema";
import { getMatchById, getLeagueBySlug, type MatchRow } from "@/lib/data";
import { analyzeMatch } from "@/lib/predict";
import { leagueDef } from "@/lib/history";
import { formatKickoff } from "@/lib/utils";
import MatchTabs, { type MatchTab } from "@/components/match-center/MatchTabs";
import OportunidadesBoard from "@/components/oportunidades-cards";
import PreLiveCompare from "@/components/match-center/PreLiveCompare";
import H2H from "@/components/match-center/H2H";
import Last10Matrix from "@/components/match-center/Last10Matrix";
import Pitch from "@/components/match-center/Pitch";
import ScouterOracle from "@/components/scouter-oracle";
import { mockCompareStats, mockReferee, placeFormation, normalizePos, type CompareCategory, type CompareStat, type MockPlayerSeed } from "@/components/match-center/mockData";
import { FormPills, StatBar, TeamBadge } from "@/components/ui";
import { ESPN_LEAGUES } from "@/lib/espn";

export const dynamic = "force-dynamic";

const COLORS = { casa: "#3b82f6", fora: "#f97316" };

function Header({ m }: { m: MatchRow }) {
  const live = m.status === "live";
  return (
    <header className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-gradient-to-b from-zinc-900 to-zinc-950 px-4 pb-4 pt-3 text-zinc-100">
      <div className="pointer-events-none absolute inset-0 pitch opacity-[0.06]" />
      <div className="relative flex items-center justify-between text-[0.6rem] font-semibold text-zinc-400"><span>{m.leagueFlag} {m.leagueName} · {m.round}</span><span>{formatKickoff(m.kickoff, true)}{m.venue ? ` · ${m.venue}` : ""}</span></div>
      <div className="relative mt-3 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
        <Link href={`/times/${m.homeSlug}`} className="flex flex-col items-center gap-1 text-center"><TeamBadge name={m.homeName} color={m.homeColor} colorAlt={m.homeColorAlt} size={52} logo={m.homeLogo} /><span className="text-[0.78rem] font-bold leading-tight">{m.homeName}</span></Link>
        <div className="flex flex-col items-center">
          <div className="flex items-baseline gap-3 text-[2.4rem] font-black leading-none tabular-nums"><span>{m.status === "scheduled" ? "–" : m.homeScore}</span><span className="text-zinc-600">-</span><span>{m.status === "scheduled" ? "–" : m.awayScore}</span></div>
          <span className={`mt-2 rounded-full px-3 py-1 text-[0.6rem] font-extrabold uppercase ${live ? "bg-emerald-500 text-emerald-950" : m.status === "finished" ? "bg-zinc-800 text-zinc-300" : "bg-sky-500/15 text-sky-400"}`}>{live ? `${m.minute}′ ao vivo` : m.status === "finished" ? "Encerrado" : formatKickoff(m.kickoff)}</span>
        </div>
        <Link href={`/times/${m.awaySlug}`} className="flex flex-col items-center gap-1 text-center"><TeamBadge name={m.awayName} color={m.awayColor} colorAlt={m.awayColorAlt} size={52} logo={m.awayLogo} /><span className="text-[0.78rem] font-bold leading-tight">{m.awayName}</span></Link>
      </div>
    </header>
  );
}

export default async function MatchCenterPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await getMatchById(Number(id));
  if (!data) notFound();
  const { match: m, lineups } = data;

  // ---- dados reais (funções existentes) ----
  const [teamRows, analysis] = await Promise.all([
    db.select().from(teams).where(inArray(teams.id, [m.homeId, m.awayId])),
    m.leagueCode ? analyzeMatch(m).catch(() => null) : Promise.resolve(null),
  ]);
  const home = teamRows.find((t) => t.id === m.homeId)!;
  const away = teamRows.find((t) => t.id === m.awayId)!;
  const leagueSlug = ESPN_LEAGUES.find((l) => l.code === m.leagueCode)?.slug;
  const league = leagueSlug ? await getLeagueBySlug(leagueSlug) : null;

  // elencos reais (tabela players) para a matriz e o campo
  const roster = m.leagueCode
    ? await db.select({ p: players, s: playerSeasonStats }).from(playerSeasonStats).innerJoin(players, eq(players.id, playerSeasonStats.playerId)).where(inArray(playerSeasonStats.teamExternalId, [home.externalId ?? "", away.externalId ?? ""]))
    : [];
  const lineupFor = (teamId: number) => lineups.find((l) => l.teamId === teamId);
  const starters = (teamId: number) => new Set((lineupFor(teamId)?.players ?? []).slice(0, 11).map((p) => p.name.toLowerCase()));
  const startersHome = starters(m.homeId), startersAway = starters(m.awayId);
  const seeds: MockPlayerSeed[] = roster
    .filter((r) => r.s.appearances > 0)
    .map((r) => {
      const isHome = r.s.teamExternalId === home.externalId;
      const set = isHome ? startersHome : startersAway;
      return { id: r.p.id, nome: r.p.name, time: isHome ? m.homeName : m.awayName, timeSigla: isHome ? m.homeShort : m.awayShort, foto: r.p.headshot || undefined, posicao: r.p.position, numero: Number(r.p.jersey) || 0, titular: set.size ? set.has(r.p.name.toLowerCase()) : r.s.appearances >= 10 };
    });
  const mediasReais = Object.fromEntries(roster.map((r) => [r.p.id, { gols: r.s.goals / Math.max(1, r.s.appearances), assistencias: r.s.assists / Math.max(1, r.s.appearances), finalizacoes: r.s.shots / Math.max(1, r.s.appearances), finalizacoes_gol: r.s.shotsOnTarget / Math.max(1, r.s.appearances), faltas: r.s.foulsCommitted / Math.max(1, r.s.appearances), amarelos: r.s.yellowCards / Math.max(1, r.s.appearances), defesas: r.s.saves / Math.max(1, r.s.appearances) }]));

  // campo: escalação oficial/prevista real quando existe; senão top-11 por minutos do elenco real
  const pitchTeam = (teamId: number, name: string, color: string) => {
    const l = lineupFor(teamId);
    const list = l?.players.slice(0, 11).map((p, i) => ({ id: i, nome: p.name, numero: p.number, posicao: p.pos, foto: roster.find((r) => r.p.name === p.name)?.p.headshot || undefined })) ??
      roster.filter((r) => (teamId === m.homeId ? r.s.teamExternalId === home.externalId : r.s.teamExternalId === away.externalId)).sort((a, b) => (b.s.minutes ?? b.s.appearances * 60) - (a.s.minutes ?? a.s.appearances * 60)).slice(0, 11).map((r) => ({ id: r.p.id, nome: r.p.name, numero: Number(r.p.jersey) || 0, posicao: normalizePos(r.p.position), foto: r.p.headshot || undefined }));
    const ordered = [...list].sort((a, b) => order(a.posicao) - order(b.posicao));
    const placed = placeFormation(l?.formation ?? (teamId === m.homeId ? home.formation : away.formation), ordered);
    if (placed.length) placed[Math.min(placed.length - 1, 5)].capitao = true; // capitão: fonte não informa — marcado o 6º (volante) como ilustrativo
    return { nome: name, sigla: teamId === m.homeId ? m.homeShort : m.awayShort, cor: color, formacao: l?.formation ?? (teamId === m.homeId ? home.formation : away.formation), jogadores: placed, fonte: l ? l.source : "top-11 por minutos (escalação não divulgada)" };
  };
  const order = (pos: string) => ({ GOL: 0, G: 0, ZAG: 1, D: 1, LAT: 1, VOL: 2, MEI: 2, M: 2, PON: 3, ATA: 3, F: 3 }[normalizePos(pos)] ?? 2);

  // Pré-Live: DISCIPLINA/OUTROS com médias reais quando os times têm amostra; demais mock
  const mock = mockCompareStats(m.homeId, m.awayId, 10);
  const hasReal = home.statsSample >= 3 && away.statsSample >= 3;
  const leagueAvg = (f: (t: typeof teams.$inferSelect) => number) => { const list = (league?.teams ?? []).filter((t) => t.statsSample > 0); return list.length ? list.reduce((s, t) => s + f(t), 0) / list.length : 0; };
  const realDisc: CompareStat[] = hasReal ? [
    { label: "Faltas cometidas", casa: home.avgFouls, fora: away.avgFouls, liga: leagueAvg((t) => t.avgFouls) || mock.DISCIPLINA[0].liga },
    { label: "Cartões", casa: home.avgCards, fora: away.avgCards, liga: leagueAvg((t) => t.avgCards) || mock.DISCIPLINA[2].liga },
  ] : mock.DISCIPLINA;
  const realOutros: CompareStat[] = hasReal ? [
    { label: "Escanteios", casa: home.avgCorners, fora: away.avgCorners, liga: leagueAvg((t) => t.avgCorners) || 9.8 },
    { label: "Finalizações", casa: home.avgShots, fora: away.avgShots, liga: leagueAvg((t) => t.avgShots) || 12 },
    { label: "No alvo", casa: home.avgShotsOnTarget, fora: away.avgShotsOnTarget, liga: leagueAvg((t) => t.avgShotsOnTarget) || 4 },
    { label: "Impedimentos", casa: home.avgOffsides, fora: away.avgOffsides, liga: leagueAvg((t) => t.avgOffsides) || 2 },
    { label: "Posse de bola", casa: home.avgPossession, fora: away.avgPossession, liga: 50, sufixo: "%" },
  ] : mock.OUTROS;
  const compare: Record<CompareCategory, CompareStat[]> = { PASSES: mock.PASSES, DEFESA: mock.DEFESA, DISCIPLINA: realDisc.map((s) => ({ ...s, casaTotal: Math.round(s.casa * Math.min(10, home.statsSample || 10)), foraTotal: Math.round(s.fora * Math.min(10, away.statsSample || 10)) })), OUTROS: realOutros.map((s) => ({ ...s, casaTotal: Math.round(s.casa * Math.min(10, home.statsSample || 10)), foraTotal: Math.round(s.fora * Math.min(10, away.statsSample || 10)) })) };

  // H2H e forma reais (modelo)
  const h2h = analysis?.h2h;
  const form = analysis?.form;
  const toForm = (f?: { last: { opponent: string; home: boolean; gf: number; ga: number; result: "V" | "E" | "D" }[] }) => (f?.last ?? []).slice(0, 5).map((g) => ({ adversario: g.opponent, emCasa: g.home, gf: g.gf, ga: g.ga, resultado: g.result }));

  // Tendências (radiais): base = confrontos diretos; se < 3, usa últimos 10 jogos dos dois times
  const h2hGames = (h2h?.games ?? []).map((g) => ({ hg: g.hg, ag: g.ag }));
  const formGames = [...(form?.home10.last ?? []), ...(form?.away10.last ?? [])].map((g) => ({ hg: g.gf, ag: g.ga }));
  const baseGames = h2hGames.length >= 3 ? h2hGames : formGames;
  const tendencias = baseGames.length ? {
    over15: baseGames.filter((g) => g.hg + g.ag > 1).length, over25: baseGames.filter((g) => g.hg + g.ag > 2).length,
    btts: baseGames.filter((g) => g.hg > 0 && g.ag > 0).length, cleanSheets: baseGames.filter((g) => g.hg === 0 || g.ag === 0).length,
    total: baseGames.length, baseLabel: h2hGames.length >= 3 ? `${baseGames.length} confrontos diretos` : `últimos ${baseGames.length} jogos dos dois times (poucos confrontos diretos)`,
  } : undefined;
  const casa = { nome: m.homeName, sigla: m.homeShort, cor: COLORS.casa, escudo: m.homeLogo || undefined };
  const fora = { nome: m.awayName, sigla: m.awayShort, cor: COLORS.fora, escudo: m.awayLogo || undefined };
  const def = leagueDef(m.leagueCode);

  const panels: Record<MatchTab, React.ReactNode> = {
    OPORTUNIDADES: <OportunidadesBoard mandante={{ id: m.homeId, nome: m.homeName, sigla: m.homeShort, cor: COLORS.casa, escudo: m.homeLogo || undefined }} visitante={{ id: m.awayId, nome: m.awayName, sigla: m.awayShort, cor: COLORS.fora, escudo: m.awayLogo || undefined }} antes={m.status === "scheduled" ? undefined : m.kickoff.toISOString().slice(0, 10)} />,
    "PRÉ-LIVE": <PreLiveCompare casa={casa} fora={fora} stats={compare} realCategories={hasReal ? ["DISCIPLINA", "OUTROS"] : []} jogosBase={10} arbitro={mockReferee(m.id)} />,
    LIVE: m.status === "scheduled" ? <div className="rounded-2xl border border-zinc-800 bg-zinc-950 px-4 py-8 text-center text-[0.72rem] text-zinc-500">A análise ao vivo abre quando a bola rolar ({formatKickoff(m.kickoff, true)}).</div> : <ScouterOracle matchId={m.id} casa={m.homeShort} fora={m.awayShort} autoRefreshMs={m.status === "live" ? 60000 : 0} />,
    H2H: <H2H casa={casa} fora={fora} tendencias={tendencias} resumo={{ vitoriasCasa: h2h?.aWins ?? 0, empates: h2h?.draws ?? 0, vitoriasFora: h2h?.bWins ?? 0 }} historico={(h2h?.games ?? []).map((g) => ({ data: g.date, casa: g.home, fora: g.away, gc: g.hg, gf: g.ag }))} formaCasa={toForm(form?.home5)} formaFora={toForm(form?.away5)} fonte={def ? `resultados oficiais ${def.name}` : "sem histórico"} />,
    JOGADORES: (
      <div className="space-y-3">
        <Pitch casa={pitchTeam(m.homeId, m.homeName, COLORS.casa)} fora={pitchTeam(m.awayId, m.awayName, COLORS.fora)} />
        <Last10Matrix casa={casa} fora={fora} jogadores={seeds} mediasReais={mediasReais} demo />
      </div>
    ),
    ESTATÍSTICAS: (
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950 px-3 py-3 text-zinc-100">
        <p className="text-[0.8rem] font-extrabold">Estatísticas da partida <span className="text-[0.6rem] font-semibold text-zinc-500">· {m.status === "live" ? `ao vivo ${m.minute}′` : m.status === "finished" ? "final" : "aguardando início"} · ESPN</span></p>
        {m.homeShots + m.awayShots > 0 ? (
          <div className="mt-1">
            {[{ label: "Posse", home: m.homePossession, away: m.awayPossession, suffix: "%", icon: "⏱️" }, { label: "Finalizações", home: m.homeShots, away: m.awayShots, icon: "🎯" }, { label: "No alvo", home: m.homeShotsOnTarget, away: m.awayShotsOnTarget, icon: "🥅" }, { label: "Escanteios", home: m.homeCorners, away: m.awayCorners, icon: "🚩" }, { label: "Faltas", home: m.homeFouls, away: m.awayFouls, icon: "✋" }, { label: "Cartões", home: m.homeCards, away: m.awayCards, icon: "🟨" }, { label: "Impedimentos", home: m.homeOffsides, away: m.awayOffsides, icon: "🚫" }].map((s) => <StatBar key={s.label} {...s} />)}
          </div>
        ) : <p className="py-6 text-center text-[0.7rem] text-zinc-500">Sem estatísticas ainda — aparecem assim que o jogo começar.</p>}
      </div>
    ),
    CLASSIFICAÇÃO: league ? (
      <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-950 text-zinc-100">
        <div className="border-b border-zinc-800 px-3 py-2.5 text-[0.8rem] font-extrabold">{league.league.flag} {league.league.name}</div>
        <div className="grid grid-cols-[1.4rem_1fr_1.6rem_2.6rem_2rem_4rem] items-center gap-1 border-b border-zinc-800 px-3 py-1.5 text-[0.52rem] font-bold uppercase text-zinc-500"><span>#</span><span>Time</span><span className="text-center">J</span><span className="text-center">V-E-D</span><span className="text-center">SG</span><span className="text-center">Forma</span></div>
        {league.teams.map((t) => (
          <div key={t.id} className={`grid grid-cols-[1.4rem_1fr_1.6rem_2.6rem_2rem_4rem] items-center gap-1 border-b border-zinc-900 px-3 py-1.5 text-[0.68rem] ${t.id === m.homeId || t.id === m.awayId ? "bg-emerald-500/10" : ""}`}>
            <span className="font-bold text-zinc-500">{t.position}</span><span className="flex min-w-0 items-center gap-1.5 font-semibold"><TeamBadge name={t.name} color={t.badgeColor} colorAlt={t.badgeColorAlt} size={16} logo={t.logo} /><span className="truncate">{t.name}</span></span><span className="text-center text-zinc-400">{t.played}</span><span className="text-center text-zinc-400">{t.wins}-{t.draws}-{t.losses}</span><span className="text-center font-bold">{t.goalsFor - t.goalsAgainst}</span><span className="flex justify-center"><FormPills form={t.form} /></span>
          </div>
        ))}
      </div>
    ) : <div className="rounded-2xl border border-zinc-800 bg-zinc-950 px-4 py-8 text-center text-[0.72rem] text-zinc-500">Classificação indisponível para esta competição.</div>,
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between"><Link href={`/jogos/${m.id}`} className="chip">← Página do jogo</Link><Link href={`/jogos/${m.id}/detalhes`} className="chip">Timeline →</Link></div>
      <Header m={m} />
      <MatchTabs panels={panels} initial="OPORTUNIDADES" liveBadge={m.status === "live" ? `${m.minute}′` : undefined} />
      <p className="px-1 text-[0.56rem] leading-relaxed text-zinc-500">Oportunidades: calculadas com os últimos 10 jogos reais (Sportmonks → Bzzoiro → ESPN). Selos <b>DADOS REAIS</b>/<b>demo</b> nas demais abas indicam a origem; capitão ilustrativo.</p>
    </div>
  );
}

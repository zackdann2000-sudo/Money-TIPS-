import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { simulateLiveEventAction } from "@/app/actions";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getMatchById } from "@/lib/data";
import { EventLine, FormPills, InsightCard, PremiumLock, SectionHeader, StatBar, TeamBadge } from "@/components/ui";
import { LineupBoard, LiveRefresher } from "@/components/client";
import { getAnalysis } from "@/lib/analysis-cache";
import { predictionHistory } from "@/lib/predict";
import { AnalysisPanel, ModelBadge, ProbBar, ProcessingCard, QualityBadge } from "@/components/analysis";
import { MomentumWidget, WillTheyScoreWidget } from "@/components/match-widgets";
import ScouterOracle from "@/components/scouter-oracle";
import { FavoriteButton } from "@/components/favorites-context";
import { AlertBell } from "@/components/alert-bell";
import { formatKickoff, statusLabel } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const data = await getMatchById(Number(id)).catch(() => null);
  if (!data) return { title: "Jogo não encontrado · GreenScore Live" };
  const { match } = data;
  const placar = match.status === "scheduled" ? "" : ` (${match.homeScore}-${match.awayScore})`;
  const title = `${match.homeName} x ${match.awayName}: Estatísticas ao Vivo e Análise`;
  const description = `${match.homeName} x ${match.awayName}${placar} · ${match.leagueName ?? "Futebol"} · ${formatKickoff(match.kickoff, true)} (Brasília). Posse, finalizações, escanteios, faltas, cartões, escalações, probabilidades e análise da IA em tempo real.`;
  return {
    title,
    description,
    openGraph: { title, description, type: "website", siteName: "GreenScore Live", locale: "pt_BR" },
    twitter: { card: "summary", title, description },
    alternates: { canonical: `/jogos/${match.id}` },
  };
}

export default async function MatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await getMatchById(Number(id));
  if (!data) notFound();
  const { match, events, lineups, insights, homeTeam, awayTeam } = data;
  const isReal = match.source === "espn";
  const session = await getSessionUser();
  const info = session ? accessInfo(session) : null;
  const hasAccess = info?.active ?? false;

  const analysis = match.source === "espn" && match.leagueCode ? await getAnalysis(match).catch(() => null) : null;
  const predHistory = analysis ? await predictionHistory(match.id).catch(() => []) : [];
  const homeLineup = lineups.find((l) => l.teamId === match.homeId);
  const awayLineup = lineups.find((l) => l.teamId === match.awayId);
  const redirectTo = `/jogos/${match.id}`;

  const topStats = [
    { label: "Posse de bola", home: match.homePossession, away: match.awayPossession, suffix: "%", icon: "⏱️" },
    { label: "Finalizações", home: match.homeShots, away: match.awayShots, icon: "🎯" },
    { label: "No alvo", home: match.homeShotsOnTarget, away: match.awayShotsOnTarget, icon: "🥅" },
    { label: "Escanteios", home: match.homeCorners, away: match.awayCorners, icon: "🚩" },
    { label: "Faltas", home: match.homeFouls, away: match.awayFouls, icon: "✋" },
    { label: "Cartões", home: match.homeCards, away: match.awayCards, icon: "🟨" },
    { label: "Impedimentos", home: match.homeOffsides, away: match.awayOffsides, icon: "🚫" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href="/jogos" className="chip">← Jogos</Link>
        <div className="flex items-center gap-1.5">
          {match.status !== "finished" ? <LiveRefresher /> : null}
          <Link href={`/jogos/${match.id}/centro`} className="chip !border-emerald-500/40 !text-emerald-500">🎯 Match Center</Link>
          <span className="chip">{match.leagueFlag} {match.round}</span>
        </div>
      </div>

      <section id="visao" className="card scroll-mt-28 overflow-hidden">
        <div className="relative brand-gradient px-3 py-3 text-white">
          <div className="pointer-events-none absolute inset-0 pitch opacity-25" />
          <div className="relative flex items-center justify-between text-[0.62rem] font-semibold text-emerald-50/85">
            <Link href={`/ligas`} className="truncate">{match.leagueFlag} {match.leagueName}</Link>
            <span>{match.venue || "Estádio"} · {formatKickoff(match.kickoff, true)} (Brasília)</span>
          </div>
          <div className="relative mt-2 flex items-center justify-between gap-2">
            <Link href={`/times/${match.homeSlug}`} className="flex flex-1 flex-col items-center gap-1 text-center">
              <TeamBadge name={match.homeName} color={match.homeColor} colorAlt={match.homeColorAlt} size={44} logo={match.homeLogo} />
              <span className="text-[0.78rem] font-bold leading-tight">{match.homeName}</span>
              <span className="text-[0.55rem] text-emerald-100/75">Casa</span>
            </Link>
            <div className="flex flex-col items-center">
              <div className="flex items-baseline gap-2 text-3xl font-black tabular-nums">
                <span>{match.status === "scheduled" ? "–" : match.homeScore}</span>
                <span className="text-emerald-200/60">:</span>
                <span>{match.status === "scheduled" ? "–" : match.awayScore}</span>
              </div>
              <span className={`mt-1 rounded-full px-2 py-0.5 text-[0.6rem] font-extrabold ${match.status === "live" ? "bg-white/20" : "bg-black/20"}`}>
                {match.status === "live" ? <span className="mr-1 inline-block h-1.5 w-1.5 rounded-full bg-emerald-300" /> : null}
                {statusLabel(match.status, match.minute)}
              </span>
              <span className="mt-1 text-[0.55rem] text-emerald-100/70">{match.statusDetail || (match.oddsDetails ? `Odds ${match.oddsDetails}` : match.round)}</span>
            </div>
            <Link href={`/times/${match.awaySlug}`} className="flex flex-1 flex-col items-center gap-1 text-center">
              <TeamBadge name={match.awayName} color={match.awayColor} colorAlt={match.awayColorAlt} size={44} logo={match.awayLogo} />
              <span className="text-[0.78rem] font-bold leading-tight">{match.awayName}</span>
              <span className="text-[0.55rem] text-emerald-100/75">Fora</span>
            </Link>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 px-3 py-2">
          <FavoriteButton team={{ id: match.homeId, name: match.homeName, slug: match.homeSlug, logo: match.homeLogo, color: match.homeColor }} compact />
          <AlertBell teamId={match.homeId} teamName={match.homeName} matchId={match.id} loggedIn={Boolean(session)} compact />
          <span className="-ml-1 text-[0.68rem] font-bold">{match.homeShort}</span>
          <FavoriteButton team={{ id: match.awayId, name: match.awayName, slug: match.awaySlug, logo: match.awayLogo, color: match.awayColor }} compact />
          <AlertBell teamId={match.awayId} teamName={match.awayName} matchId={match.id} loggedIn={Boolean(session)} compact />
          <span className="-ml-1 text-[0.68rem] font-bold">{match.awayShort}</span>
          <span className="chip">🔔 alertas ativos ao favoritar</span>
          {isReal ? (
            <span className="chip ml-auto !border-emerald-500/30 !text-emerald-500">✓ dados oficiais ESPN{match.oddsDetails ? ` · odds ${match.oddsDetails}` : ""}{match.overUnder ? ` · O/U ${match.overUnder}` : ""}</span>
          ) : (
            <form action={simulateLiveEventAction} className="ml-auto">
              <input type="hidden" name="matchId" value={match.id} />
              <input type="hidden" name="redirectTo" value={redirectTo} />
              <button className="btn btn-primary !px-2.5 !py-1 !text-[0.65rem]">
                {match.status === "live" ? "Atualizar lance (demo)" : "Iniciar jogo (demo)"}
              </button>
            </form>
          )}
        </div>
      </section>

      <nav className="no-scrollbar sticky top-[6.1rem] z-20 -mx-3 flex gap-1.5 overflow-x-auto glass px-3 py-1.5 lg:top-0 lg:mx-0 lg:rounded-xl lg:px-2">
        {[["#visao", "Visão geral"], ...(match.status !== "scheduled" ? [["#oracle", "🔮 Oracle"]] : []), ["#ia", "🧠 Análise da IA"], ["#probabilidades", "Probabilidades"], ["#estatisticas", "Estatísticas"], ["#historico", "Histórico"], ["#jogadores", "Jogadores"], ...(match.status === "live" ? [["#ia", "🔴 Ao vivo"]] : [])].map(([href, label]) => (
          <a key={label} href={href} className="chip !py-1.5 whitespace-nowrap">{label}</a>
        ))}
      </nav>

      {match.status !== "scheduled" ? (
        <section id="oracle" className="scroll-mt-28">
          {hasAccess ? (
            <ScouterOracle matchId={match.id} casa={match.homeShort} fora={match.awayShort} autoRefreshMs={match.status === "live" ? 60000 : 0} />
          ) : (
            <PremiumLock title="Scouter Oracle é exclusivo para contas ativas" description="Veredito de intervalo (MANTER · COBRIR · MUDAR · SAIR) com xG, pressão ofensiva e probabilidades da partida." />
          )}
        </section>
      ) : null}

      {analysis ? (
        <section id="ia" className="scroll-mt-28 space-y-2">
          <SectionHeader title="IA Analista — inteligência preditiva" subtitle="Probabilidades calculadas por modelo estatístico com resultados oficiais da competição" icon={<span>🧠</span>} href="/ia" action="Todas as análises" />
          {hasAccess ? (
            <AnalysisPanel match={match} a={analysis} history={predHistory} />
          ) : (
            <div className="space-y-2">
              {analysis.pre ? (
                <div className="card space-y-2 px-3 py-3">
                  <div className="flex flex-wrap gap-1.5"><ModelBadge modelType={analysis.modelType} version={analysis.version} /><QualityBadge quality={analysis.quality} sampleHome={analysis.sampleHome} sampleAway={analysis.sampleAway} /></div>
                  <ProbBar m={analysis.live ?? analysis.pre} homeShort={match.homeShort} awayShort={match.awayShort} title={analysis.live ? `Probabilidade atualizada · ${match.minute}′` : "Previsão pré-jogo (1X2)"} />
                  <p className="text-[0.68rem] leading-relaxed">{analysis.explanation.resumo}</p>
                </div>
              ) : <ProcessingCard homeName={match.homeName} awayName={match.awayName} />}
              <PremiumLock title="Análise completa da IA é exclusiva para contas ativas" description="Probabilidades de gols, placares prováveis, projeções de escanteios/cartões/faltas, cenários, confronto direto e histórico de previsões." />
            </div>
          )}
        </section>
      ) : null}

      <section id="probabilidades" className="scroll-mt-28 hidden" />

      <section id="jogadores" className="scroll-mt-28">
        <SectionHeader title={homeLineup?.matchId || awayLineup?.matchId ? "Escalações oficiais" : "Escalação prevista"} subtitle={homeLineup?.matchId || awayLineup?.matchId ? "Titulares confirmados pela ESPN" : "Baseada na última escalação oficial de cada time"} icon={<span>📋</span>} />
        {hasAccess && (homeLineup || awayLineup) ? (
          <LineupBoard
            sides={[
              homeLineup
                ? { name: match.homeName, short: match.homeShort, color: match.homeColor, colorAlt: match.homeColorAlt, formation: homeLineup.formation, confidence: homeLineup.confidence, source: homeLineup.source, players: homeLineup.players }
                : { name: match.homeName, short: match.homeShort, color: match.homeColor, colorAlt: match.homeColorAlt, formation: "4-3-3", players: [] },
              awayLineup
                ? { name: match.awayName, short: match.awayShort, color: match.awayColor, colorAlt: match.awayColorAlt, formation: awayLineup.formation, confidence: awayLineup.confidence, source: awayLineup.source, players: awayLineup.players }
                : { name: match.awayName, short: match.awayShort, color: match.awayColor, colorAlt: match.awayColorAlt, formation: "4-3-3", players: [] },
            ]}
          />
        ) : (
          hasAccess ? (
            <div className="card px-3 py-4 text-center text-[0.75rem] muted">Escalações ainda não divulgadas para este jogo. Elas aparecem aqui assim que os times forem confirmados (normalmente ~1h antes).</div>
          ) : (
            <PremiumLock title="Escalação prevista é exclusiva VIP" description="Libere as prováveis escalações, dúvidas e formação dos dois times com o plano VIP ou seu dia grátis via Gmail." />
          )
        )}
      </section>

      {analysis?.pre ? (
        <WillTheyScoreWidget
          homeName={match.homeShort} awayName={match.awayShort}
          homeScores={(analysis.live ?? analysis.pre).homeScores} awayScores={(analysis.live ?? analysis.pre).awayScores}
          homeCleanSheet={1 - (analysis.live ?? analysis.pre).awayScores} awayCleanSheet={1 - (analysis.live ?? analysis.pre).homeScores}
          source={analysis.modelType === "fallback_simples" ? "Modelo Simplificado" : analysis.version}
        />
      ) : null}

      {match.status !== "scheduled" ? <MomentumWidget matchId={match.id} homeName={match.homeShort} awayName={match.awayShort} status={match.status} /> : null}

      <section id="estatisticas" className="scroll-mt-28">
        <SectionHeader title="Estatísticas da partida" subtitle="Atualizadas a cada lance" icon={<span>📊</span>} />
        <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-4">
          {[
            { icon: "🚩", label: "Escanteios", value: match.homeCorners + match.awayCorners },
            { icon: "✋", label: "Faltas", value: match.homeFouls + match.awayFouls },
            { icon: "🚫", label: "Impedimentos", value: match.homeOffsides + match.awayOffsides },
            { icon: "🟨", label: "Cartões", value: match.homeCards + match.awayCards },
            { icon: "🎯", label: "Finalizações", value: match.homeShots + match.awayShots },
            { icon: "🥅", label: "No alvo", value: match.homeShotsOnTarget + match.awayShotsOnTarget },
          ].map((item) => (
            <div key={item.label} className="card px-2 py-2 text-center">
              <p className="text-sm">{item.icon}</p>
              <p className="text-[0.95rem] font-black tabular-nums leading-none">{item.value}</p>
              <p className="text-[0.55rem] muted">{item.label}</p>
            </div>
          ))}
        </div>
        {true ? (
          <div className="card mt-2 px-3 py-2">
            <div className="mb-1 flex items-center justify-between text-[0.62rem] font-bold">
              <span className="flex items-center gap-1"><TeamBadge name={match.homeName} color={match.homeColor} colorAlt={match.homeColorAlt} size={16} /> {match.homeShort}</span>
              <span className="flex items-center gap-1">{match.awayShort} <TeamBadge name={match.awayName} color={match.awayColor} colorAlt={match.awayColorAlt} size={16} /></span>
            </div>
            {topStats.map((stat) => <StatBar key={stat.label} {...stat} />)}
          </div>
        ) : (
          null
        )}
      </section>

      <section id="historico" className="scroll-mt-28">
        <SectionHeader title="Lances do jogo" subtitle="Gols, pênaltis, cartões, faltas, impedimentos e escanteios" icon={<span>⏱️</span>} href={`/jogos/${match.id}/detalhes`} action="Timeline estilo app" />
        <div className="card overflow-hidden">
          {events.length ? (
            (hasAccess ? events : events.slice(0, 3)).map((event) => <EventLine key={event.id} event={event} homeName={match.homeName} awayName={match.awayName} />)
          ) : (
            <div className="px-4 py-6 text-center text-[0.78rem] muted">
              {match.status === "scheduled" ? `Nenhum lance ainda. A bola rola às ${formatKickoff(match.kickoff)} (horário de Brasília).` : "Lances detalhados ainda não disponíveis para esta partida."}
            </div>
          )}
          {!hasAccess && events.length > 3 ? (
            <div className="relative border-t px-3 py-3 text-center hairline">
              <div className="pointer-events-none absolute inset-x-0 -top-10 h-10 bg-gradient-to-t from-[var(--surface-2)] to-transparent" />
              <p className="text-[0.72rem] font-bold">+{events.length - 3} lances nesta partida</p>
              <p className="text-[0.62rem] muted">Veja a timeline completa (gols, cartões, substituições, acréscimos) com sua conta ativa.</p>
              <Link href="/planos" className="btn btn-primary mt-2 !px-3 !py-1.5 !text-[0.68rem]">Ver timeline completa</Link>
            </div>
          ) : null}
        </div>
      </section>

      <section>
        <SectionHeader title="Análise e oportunidades" subtitle="Calculadas a partir dos números reais desta partida e dos times" icon={<span>🧠</span>} href="/analises" />
        {hasAccess ? (
          <div className="grid gap-2 sm:grid-cols-2">
            {insights.length ? insights.map((insight) => (
              <InsightCard key={insight.id} insight={insight} matchLabel={`${match.homeShort} x ${match.awayShort}`} />
            )) : (
              <div className="card px-3 py-4 text-[0.75rem] muted sm:col-span-2">As análises aparecem assim que houver dados suficientes (jogo em andamento ou médias reais dos times).</div>
            )}
          </div>
        ) : (
          <PremiumLock title="Análise estatística exclusiva VIP" description="Mercados recomendados de gols, escanteios, cartões e impedimentos com nível de confiança." />
        )}
      </section>

      <section className="grid gap-2 sm:grid-cols-2">
        {[
          { slug: match.homeSlug, name: match.homeName, color: match.homeColor, colorAlt: match.homeColorAlt, short: match.homeShort, logo: match.homeLogo, team: homeTeam },
          { slug: match.awaySlug, name: match.awayName, color: match.awayColor, colorAlt: match.awayColorAlt, short: match.awayShort, logo: match.awayLogo, team: awayTeam },
        ].map((team) => (
          <Link key={team.slug} href={`/times/${team.slug}`} className="card card-hover flex items-center gap-2 px-3 py-2.5">
            <TeamBadge name={team.name} color={team.color} colorAlt={team.colorAlt} size={30} logo={team.logo} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[0.8rem] font-bold">{team.name}</p>
              <div className="flex items-center gap-1.5 text-[0.6rem] muted">
                {team.team?.form ? <FormPills form={team.team.form} /> : null}
                <span>{team.team ? `${team.team.wins}V ${team.team.draws}E ${team.team.losses}D` : "Últimos jogos e desempenho"}</span>
              </div>
            </div>
            <span className="text-[0.7rem] font-bold text-[var(--brand)]">ver →</span>
          </Link>
        ))}
      </section>
    </div>
  );
}

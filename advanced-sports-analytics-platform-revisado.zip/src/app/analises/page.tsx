import Link from "next/link";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getInsights, getMatches } from "@/lib/data";
import { InsightCard, PremiumLock, SectionHeader, StatTile } from "@/components/ui";

export const dynamic = "force-dynamic";

const CATEGORIES = [
  { key: "", label: "Todas" },
  { key: "gols", label: "⚽ Gols" },
  { key: "escanteios", label: "🚩 Escanteios" },
  { key: "cartoes", label: "🟨 Cartões" },
  { key: "faltas", label: "✋ Faltas" },
  { key: "impedimentos", label: "🚫 Impedimentos" },
  { key: "mercados", label: "📈 Mercados" },
  { key: "analise", label: "🧠 Times" },
];

export default async function AnalysisPage({ searchParams }: { searchParams: Promise<{ cat?: string }> }) {
  const params = await searchParams;
  const category = params.cat ?? "";
  const [session, insights, matches] = await Promise.all([
    getSessionUser(),
    getInsights({ category: category || undefined }),
    getMatches({ status: "live" }),
  ]);
  const allInsights = await getInsights();
  const info = session ? accessInfo(session) : null;
  const hasAccess = info?.active ?? false;
  const visible = hasAccess ? insights : insights.slice(0, 2);
  const liveMatch = matches[0];

  const avgConfidence = allInsights.length ? Math.round(allInsights.reduce((sum, row) => sum + row.insight.confidence, 0) / allInsights.length) : 0;

  return (
    <div className="space-y-4">
      <div className="px-1">
        <h1 className="text-xl font-black tracking-tight">Análises & oportunidades</h1>
        <p className="text-[0.7rem] muted">Geradas automaticamente a partir dos números oficiais dos jogos de hoje (ESPN)</p>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <StatTile label="Análises hoje" value={allInsights.length} icon="🧠" />
        <StatTile label="Confiança média" value={`${avgConfidence}%`} icon="📈" />
        <StatTile label="Jogos ao vivo" value={matches.length} icon="🔴" />
        <StatTile label="Mercados" value={new Set(allInsights.map((i) => i.insight.market)).size} icon="🎯" />
      </div>

      {!hasAccess ? (
        <div className="card flex flex-col gap-2 border-emerald-500/40 px-3 py-3 sm:flex-row sm:items-center">
          <div className="flex-1">
            <p className="text-[0.82rem] font-extrabold">🔒 Você está vendo uma prévia das análises</p>
            <p className="text-[0.68rem] muted">Ative seu dia grátis com Gmail ou assine o VIP para liberar todas as oportunidades, escalações e comparativos.</p>
          </div>
          <Link href={session ? "/planos" : "/cadastro"} className="btn btn-primary shrink-0">{session ? "Assinar VIP" : "Testar grátis"}</Link>
        </div>
      ) : null}

      <div className="no-scrollbar -mx-3 flex gap-1.5 overflow-x-auto px-3 lg:mx-0 lg:px-0">
        {CATEGORIES.map((item) => (
          <Link key={item.key} href={item.key ? `/analises?cat=${item.key}` : "/analises"} className={`chip !px-3 !py-1.5 ${category === item.key ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}>
            {item.label}
          </Link>
        ))}
      </div>

      {liveMatch ? (
        <section>
          <SectionHeader title="Destaque do momento" subtitle={`${liveMatch.homeName} x ${liveMatch.awayName} · ${liveMatch.minute}'`} href={`/jogos/${liveMatch.id}`} action="Abrir jogo" icon={<span className="live-dot" />} />
          <div className="card grid grid-cols-4 divide-x divide-[var(--line)] text-center">
            {[
              { label: "gols", value: `${liveMatch.homeScore}-${liveMatch.awayScore}` },
              { label: "escanteios", value: liveMatch.homeCorners + liveMatch.awayCorners },
              { label: "faltas", value: liveMatch.homeFouls + liveMatch.awayFouls },
              { label: "impedimentos", value: liveMatch.homeOffsides + liveMatch.awayOffsides },
            ].map((item) => (
              <div key={item.label} className="px-1 py-2">
                <p className="text-[0.95rem] font-black tabular-nums leading-none">{item.value}</p>
                <p className="mt-0.5 text-[0.52rem] muted">{item.label}</p>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <div className="grid gap-2 sm:grid-cols-2">
        {visible.map((row) => (
          <InsightCard key={row.insight.id} insight={row.insight} matchLabel={row.homeName && row.awayName ? `${row.homeShort} x ${row.awayShort}` : "Análise de time"} href={row.matchId ? `/jogos/${row.matchId}` : undefined} />
        ))}
      </div>

      {!hasAccess ? (
        <PremiumLock title={`Mais ${Math.max(0, insights.length - visible.length)} análises bloqueadas`} description="Libere todas as oportunidades de gols, escanteios, cartões, faltas e impedimentos com acesso VIP." />
      ) : null}

      <section className="card overflow-hidden">
        <div className="border-b px-3 py-2.5 hairline">
          <h2 className="text-[0.9rem] font-extrabold">Metodologia GreenScore</h2>
          <p className="text-[0.65rem] muted">Como calculamos as oportunidades exibidas</p>
        </div>
        <div className="divide-y hairline">
          {[
            { titulo: "Base de dados", texto: "Placar, minuto, escanteios, faltas, cartões, impedimentos, posse e finalizações oficiais de cada partida (ESPN), além da forma e campanha dos times." },
            { titulo: "Projeções ao vivo", texto: "Durante o jogo projetamos escanteios, faltas, cartões e finalizações para os 90 minutos com base no ritmo atual." },
            { titulo: "Confiança", texto: "Cresce com o tempo de jogo decorrido e com o tamanho da amostra de partidas reais do time no sistema." },
            { titulo: "Atualização", texto: "Sincronização automática a cada 45 segundos; nenhum dado é inventado — se não há amostra, a análise não é exibida." },
          ].map((item) => (
            <div key={item.titulo} className="px-3 py-2">
              <p className="text-[0.75rem] font-bold">{item.titulo}</p>
              <p className="text-[0.64rem] leading-relaxed muted">{item.texto}</p>
            </div>
          ))}
        </div>
      </section>

      <p className="px-2 text-center text-[0.6rem] leading-relaxed muted">
        Análises de caráter informativo e estatístico. Não constituem recomendação de aposta. Jogue com responsabilidade · +18.
      </p>
    </div>
  );
}

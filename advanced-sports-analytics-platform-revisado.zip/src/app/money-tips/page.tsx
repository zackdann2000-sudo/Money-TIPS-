import MoneyTips from "@/components/money-tips";

export const dynamic = "force-dynamic";

export default function MoneyTipsPage() {
  return <MoneyTips />;
}

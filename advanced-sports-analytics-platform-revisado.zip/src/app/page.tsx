import Image from "next/image";
import Link from "next/link";
import { accessInfo, getSessionUser, logAccess } from "@/lib/auth";
import { getBanners, getFavorites, getInsights, getLeagues, getMatchesByDay, getTeams } from "@/lib/data";
import { InsightCard, MatchRow, SectionHeader, FormPills, TeamBadge, StatTile, DataSourceBadge } from "@/components/ui";
import { getSyncStatus } from "@/lib/espn";
import { xgForList } from "@/lib/analysis-cache";
import { dayKey, dayLabel, formatKickoff } from "@/lib/utils";
import { LiveRefresher } from "@/components/client";

export const dynamic = "force-dynamic";

const FEATURES = [
  { icon: "⚽", title: "Eventos ao vivo", text: "Gols, pênaltis, cartões, faltas, impedimentos e escanteios minuto a minuto." },
  { icon: "📋", title: "Escalação prevista", text: "Prováveis titulares, formação e confiança do modelo para cada time." },
  { icon: "🔔", title: "Alertas do favorito", text: "Notificação quando seu time entra em campo, marca ou o jogo termina." },
  { icon: "📊", title: "Desempenho", text: "Últimos jogos, xG, posse, finalizações, over 2,5 e ambas marcam." },
  { icon: "🧠", title: "Análises", text: "Oportunidades cruzando médias das ligas com o histórico dos confrontos." },
  { icon: "👑", title: "Painel do dono", text: "Usuários ativos/expirados, planos, faturamento e integrações de API." },
];

export default async function HomePage() {
  const [session, banners, days, insights, leagues, teams, sync] = await Promise.all([
    getSessionUser(),
    getBanners(),
    getMatchesByDay(),
    getInsights({ limit: 4 }),
    getLeagues(),
    getTeams(),
    getSyncStatus().catch(() => null),
  ]);

  const favorites = session ? await getFavorites(session.id).catch(() => []) : [];

  const allMatches = days.flatMap((day) => day.list);
  const liveMatches = allMatches.filter((m) => m.status === "live");
  const todaysKey = dayKey(new Date());
  const todayMatches = days.find((day) => day.day === todaysKey)?.list ?? [];

  const matchesForXg = [...liveMatches, ...allMatches.filter((m) => m.status === "scheduled")].slice(0, 12);
  const xgMap = await xgForList(matchesForXg).catch(() => ({} as Record<number, { home: number; away: number; source: string }>));

  const info = session ? accessInfo(session) : null;
  await logAccess(session?.id ?? null, "/inicio").catch(() => null);

  const favoriteIds = new Set(favorites.map((favorite) => favorite.team.id));
  const favoriteMatches = allMatches
    .filter((match) => favoriteIds.has(match.homeId) || favoriteIds.has(match.awayId))
    .slice(0, 3);

  const upcoming = allMatches
    .filter((match) => match.status === "scheduled" && new Date(match.kickoff).getTime() > Date.now())
    .slice(0, 6);

  const activeTeamIds = new Set(allMatches.flatMap((match) => [match.homeId, match.awayId]));
  const featuredTeams = [
    ...teams.filter((team) => activeTeamIds.has(team.team.id)),
    ...teams.filter((team) => !activeTeamIds.has(team.team.id)),
  ].slice(0, 8);

  return (
    <div className="space-y-5">
      {!session ? <GuestHero /> : <UserStatus session={session} info={info} />}

      <div className="flex flex-wrap items-center gap-1.5 px-1">
        <DataSourceBadge lastSuccessAt={sync?.lastSuccessAt} matches={sync?.matchesSynced ?? 0} />
        <span className="chip">📅 {todayMatches.length} jogos hoje</span>
        <span className="chip">🕒 horário de Brasília</span>
      </div>

      <section className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <StatTile label="Jogos ao vivo" value={liveMatches.length} hint="atualização automática" icon="🔴" />
        <StatTile label="Ligas cobertas" value={leagues.length} hint="2025/26 + 2026" icon="🏆" />
        <StatTile label="Times" value={teams.length} hint="com estatísticas completas" icon="🛡️" />
        <StatTile label="Oportunidades" value={insights.length} hint="análises do dia" icon="📈" />
      </section>

      {banners.length > 0 && (
        <section className="no-scrollbar -mx-3 flex gap-2 overflow-x-auto px-3 pb-1 lg:mx-0 lg:px-0">
          {banners.map((banner) => (
            <Link
              key={banner.id}
              href={banner.ctaHref}
              className={`card relative min-w-[290px] flex-1 overflow-hidden border-0 bg-gradient-to-br ${banner.gradient} p-3 text-white lg:min-w-[320px]`}
            >
              <div className="pointer-events-none absolute inset-0 pitch opacity-30" />
              <div className="relative">
                <span className="chip !border-white/30 !bg-white/15 !text-white">{banner.badge}</span>
                <h3 className="mt-1.5 text-[0.95rem] font-black leading-tight">{banner.title}</h3>
                <p className="mt-0.5 line-clamp-2 text-[0.68rem] text-white/85">{banner.subtitle}</p>
                <span className="mt-2 inline-flex rounded-lg bg-white/20 px-2 py-1 text-[0.62rem] font-extrabold">
                  {banner.ctaLabel} →
                </span>
              </div>
            </Link>
          ))}
        </section>
      )}

      {favoriteMatches.length > 0 && (
        <section>
          <SectionHeader
            title="Seus favoritos em campo"
            subtitle="Alertas de gols, cartões, escanteios e fim de jogo"
            href="/notificacoes"
            action="Alertas"
            icon={<span>⭐</span>}
          />
          <div className="space-y-1.5">
            {favoriteMatches.map((match) => (
              <MatchRow key={match.id} match={match} xg={xgMap[match.id] ?? null} />
            ))}
          </div>
        </section>
      )}

      <section>
        <div className="mb-2 flex items-end justify-between px-1">
          <h2 className="flex items-center gap-1.5 text-[0.95rem] font-extrabold">
            <span className="live-dot" /> Ao vivo agora
          </h2>
          <div className="flex items-center gap-2">
            <LiveRefresher />
            <Link href="/jogos" className="text-[0.7rem] font-bold text-[var(--brand)]">
              Todos →
            </Link>
          </div>
        </div>

        <div className="grid gap-1.5 sm:grid-cols-2">
          {liveMatches.length ? (
            liveMatches.map((match) => (
              <MatchRow key={match.id} match={match} xg={xgMap[match.id] ?? null} />
            ))
          ) : (
            <div className="card px-3 py-4 text-center text-[0.75rem] muted sm:col-span-2">
              Nenhum jogo ao vivo agora. Veja os próximos confrontos abaixo.
            </div>
          )}
        </div>
      </section>

      <section>
        <SectionHeader
          title="Oportunidades estatísticas"
          subtitle="Calculadas ao vivo a partir dos números oficiais das partidas"
          href="/analises"
          icon={<span>📈</span>}
        />
        <div className="grid gap-2 sm:grid-cols-2">
          {insights.map((row) => (
            <InsightCard
              key={row.insight.id}
              insight={row.insight}
              matchLabel={row.homeName && row.awayName ? `${row.homeShort} x ${row.awayShort}` : undefined}
              href={row.matchId ? `/jogos/${row.matchId}` : undefined}
            />
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section>
          <SectionHeader
            title="Jogos de hoje"
            subtitle={`${dayLabel(todaysKey)} · ${todayMatches.length} partidas`}
            href="/jogos"
            icon={<span>📅</span>}
          />
          <div className="space-y-1.5">
            {todayMatches.slice(0, 8).map((match) => (
              <MatchRow key={match.id} match={match} xg={xgMap[match.id] ?? null} />
            ))}
            {!todayMatches.length && (
              <div className="card px-3 py-4 text-center text-[0.75rem] muted">
                Nenhum jogo encontrado para hoje nas competições monitoradas.
              </div>
            )}
          </div>
        </section>

        <section>
          <SectionHeader
            title="Próximos jogos"
            subtitle="Agenda com horário de Brasília"
            href="/jogos"
            icon={<span>⏰</span>}
          />
          <div className="space-y-1.5">
            {upcoming.map((match) => (
              <Link
                key={match.id}
                href={`/jogos/${match.id}`}
                className="card card-hover flex items-center gap-2 px-2.5 py-2"
              >
                <div className="w-12 shrink-0 text-center">
                  <p className="text-[0.65rem] font-extrabold">{formatKickoff(match.kickoff)}</p>
                  <p className="text-[0.52rem] muted">
                    {new Date(match.kickoff).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
                  </p>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.78rem] font-semibold">
                    {match.homeName} <span className="muted">x</span> {match.awayName}
                  </p>
                  <p className="truncate text-[0.58rem] muted">
                    {match.leagueFlag} {match.leagueName} · {match.round}
                  </p>
                </div>
                <span className="chip !text-[0.55rem]">prévia →</span>
              </Link>
            ))}
            {!upcoming.length && (
              <div className="card px-3 py-4 text-center text-[0.75rem] muted">
                Nenhum próximo jogo agendado no momento.
              </div>
            )}
          </div>
        </section>
      </div>

      <QuickLink
        href="/money-tips"
        icon="💜"
        iconClass="bg-violet-500/15"
        title="Money Tips — Pick do Dia"
        text="A melhor oportunidade do dia pelos últimos 10 jogos reais · gráfico de barras · melhores do dia"
        accent="text-violet-400"
      />

      <QuickLink
        href="/ia"
        icon="🧠"
        iconClass="bg-[var(--brand-soft)]"
        title="IA Analista — inteligência preditiva"
        text="Probabilidades 1X2, gols, placares e projeções das partidas de hoje, com resultados oficiais e desempenho auditável"
        accent="text-[var(--brand)]"
      />

      <QuickLink
        href="/jogadores"
        icon="🏅"
        iconClass="bg-[var(--brand-soft)]"
        title="Central de Jogadores — Rankings da temporada"
        text="Artilheiros, assistências, finalizações, faltas, cartões, passes e defesa · filtros e comparador de atletas"
        accent="text-[var(--brand)]"
      />

      <section>
        <SectionHeader
          title="Ligas"
          subtitle="Médias de gols, escanteios e cartões por competição"
          href="/ligas"
          icon={<span>🏆</span>}
        />
        <div className="no-scrollbar -mx-3 flex gap-2 overflow-x-auto px-3 pb-1 lg:mx-0 lg:px-0">
          {leagues.map((league) => (
            <Link key={league.id} href={`/ligas/${league.slug}`} className="card card-hover min-w-[168px] px-3 py-2.5">
              <div className="flex items-center gap-2">
                <span className="text-lg">{league.flag}</span>
                <div className="min-w-0">
                  <p className="truncate text-[0.78rem] font-bold">{league.name}</p>
                  <p className="text-[0.55rem] muted">
                    {league.country} · {league.season}
                  </p>
                </div>
              </div>
              <div className="mt-2 flex gap-1 text-[0.55rem]">
                <span className="chip !py-0">⚽ {league.avgGoals}</span>
                <span className="chip !py-0">🚩 {league.avgCorners}</span>
                <span className="chip !py-0">🟨 {league.avgCards}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader
          title="Times em destaque"
          subtitle="Forma, desempenho e análise completa"
          href="/times"
          icon={<span>🛡️</span>}
        />
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {featuredTeams.map(({ team, leagueFlag }) => (
            <Link key={team.id} href={`/times/${team.slug}`} className="card card-hover px-2.5 py-2">
              <div className="flex items-center gap-1.5">
                <TeamBadge
                  name={team.name}
                  color={team.badgeColor}
                  colorAlt={team.badgeColorAlt}
                  size={26}
                  logo={team.logo}
                />
                <div className="min-w-0">
                  <p className="truncate text-[0.75rem] font-bold">{team.name}</p>
                  <p className="text-[0.55rem] muted">
                    {leagueFlag} {team.wins}V {team.draws}E {team.losses}D
                  </p>
                </div>
              </div>
              <div className="mt-1.5 flex items-center justify-between">
                <FormPills form={team.form} />
                {team.statsSample >= 3 ? (
                  <span className="text-[0.58rem] font-bold text-emerald-500">{team.over25Rate}% over</span>
                ) : (
                  <span className="text-[0.55rem] muted">{team.played} jogos</span>
                )}
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="card overflow-hidden">
        <div className="relative brand-gradient px-4 py-4 text-white">
          <div className="pointer-events-none absolute inset-0 pitch opacity-30" />
          <div className="relative">
            <h2 className="text-base font-black">Tudo que o GreenScore entrega</h2>
            <p className="text-[0.7rem] text-emerald-50/85">
              Feito para o celular, com a mesma profundidade dos grandes apps de estatística.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-px bg-[var(--line)] sm:grid-cols-3">
          {FEATURES.map((feature) => (
            <div key={feature.title} className="bg-[var(--surface-2)] px-3 py-3">
              <span className="text-lg">{feature.icon}</span>
              <p className="mt-1 text-[0.78rem] font-bold">{feature.title}</p>
              <p className="mt-0.5 text-[0.65rem] leading-relaxed muted">{feature.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card flex flex-col items-center gap-2 px-4 py-5 text-center">
        <h2 className="text-[1rem] font-black">Pronto para não perder nenhum lance?</h2>
        <p className="max-w-sm text-[0.72rem] muted">
          Crie sua conta com Gmail e ganhe 1 dia grátis. Depois, continue com o plano VIP a partir de R$ 9,90.
        </p>
        <div className="flex gap-2">
          <Link href="/cadastro" className="btn btn-primary">Começar grátis</Link>
          <Link href="/planos" className="btn btn-ghost">Ver planos</Link>
        </div>
      </section>
    </div>
  );
}

function GuestHero() {
  return (
    <section className="card relative overflow-hidden border-0 p-4 text-white">
      <Image
        src="/images/hero.jpg"
        alt="Estádio iluminado à noite"
        fill
        priority
        sizes="100vw"
        className="object-cover opacity-45"
      />
      <div className="absolute inset-0 bg-gradient-to-tr from-emerald-950/95 via-emerald-900/80 to-emerald-700/55" />
      <div className="pointer-events-none absolute inset-0 pitch opacity-30" />

      <div className="relative">
        <span className="chip !border-white/25 !bg-white/15 !text-white">
          🎁 1 dia grátis com Gmail
        </span>
        <h1 className="mt-2 text-xl font-black leading-tight tracking-tight sm:text-2xl">
          Todo o jogo em números.
          <br />
          Gols, cartões, faltas, impedimentos e escanteios ao vivo.
        </h1>
        <p className="mt-1.5 max-w-md text-[0.75rem] leading-relaxed text-emerald-50/85">
          Placar em tempo real, escalação prevista, desempenho dos times e as melhores oportunidades de mercado.
        </p>
        <div className="mt-3 flex gap-2">
          <Link href="/cadastro" className="btn !bg-white !text-emerald-900">
            Criar conta grátis
          </Link>
          <Link href="/jogos" className="btn !border-white/30 !bg-white/10 !text-white">
            Ver jogos ao vivo
          </Link>
        </div>
        <div className="mt-3 flex flex-wrap gap-2 text-[0.6rem] font-semibold text-emerald-50/80">
          <span>⚽ Placar ao vivo</span>
          <span>🚩 Escanteios</span>
          <span>🟨 Cartões</span>
          <span>🚫 Impedimentos</span>
          <span>📋 Escalação</span>
          <span>🔔 Alertas</span>
        </div>
      </div>
    </section>
  );
}

function UserStatus({ session, info }: { session: Awaited<ReturnType<typeof getSessionUser>>; info: ReturnType<typeof accessInfo> | null }) {
  const active = Boolean(info?.active);

  return (
    <section className={`card flex items-center justify-between gap-3 px-3 py-2.5 ${active ? "" : "border-rose-500/40"}`}>
      <div className="min-w-0">
        <p className="truncate text-[0.8rem] font-extrabold">
          Olá, {session.name.split(" ")[0]} 👋
        </p>
        <p className="text-[0.65rem] muted">
          {active
            ? `Acesso ${info?.label} · expira em ${info?.daysLeft} dia(s) (${new Date(session.accessExpiresAt).toLocaleDateString("pt-BR")})`
            : "Seu acesso expirou — assine o VIP para liberar os dados ao vivo."}
        </p>
      </div>
      <Link
        href={active ? "/conta" : "/planos"}
        className={`btn shrink-0 !px-2.5 !py-1.5 !text-[0.68rem] ${active ? "btn-ghost" : "btn-primary"}`}
      >
        {active ? "Minha conta" : "Assinar VIP"}
      </Link>
    </section>
  );
}

function QuickLink({
  href,
  icon,
  iconClass,
  title,
  text,
  accent,
}: {
  href: string;
  icon: string;
  iconClass: string;
  title: string;
  text: string;
  accent: string;
}) {
  return (
    <Link href={href} className="card card-hover relative flex items-center gap-3 overflow-hidden px-3 py-3">
      <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-xl ${iconClass}`}>
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[0.88rem] font-extrabold">{title}</span>
        <span className="block text-[0.66rem] muted">{text}</span>
      </span>
      <span className={`text-[0.7rem] font-bold ${accent}`}>abrir →</span>
    </Link>
  );
}
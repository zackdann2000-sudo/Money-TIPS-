import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/client";
import { Logo } from "@/components/nav";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function SignupPage() {
  const session = await getSessionUser();
  if (session) redirect("/conta");

  return (
    <div className="mx-auto max-w-md space-y-3 py-2">
      <div className="text-center">
        <div className="flex justify-center"><Logo /></div>
        <h1 className="mt-3 text-xl font-black tracking-tight">Crie sua conta grátis</h1>
        <p className="text-[0.72rem] muted">Gmail libera 1 dia de acesso completo na hora</p>
      </div>

      <div className="card relative overflow-hidden border-emerald-500/40">
        <div className="brand-gradient px-4 py-3 text-white">
          <p className="text-[0.8rem] font-black">🎁 Teste grátis</p>
          <div className="mt-1 grid grid-cols-3 gap-1.5 text-center text-[0.58rem] font-semibold">
            {[["Gmail", "24 horas"], ["Outros", "6 horas"], ["Depois", "VIP"]].map(([label, value]) => (
              <div key={label} className="rounded-lg bg-white/15 py-1.5">
                <p className="text-[0.72rem] font-black">{value}</p>
                <p className="text-emerald-50/80">{label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="px-4 py-4">
          <AuthForm mode="signup" />
        </div>
      </div>

      <div className="card px-3 py-2.5 text-[0.68rem]">
        <p className="font-bold">O que está incluído no acesso</p>
        <div className="mt-1 grid grid-cols-2 gap-1">
          {["Gols e placar ao vivo", "Escanteios e cartões", "Faltas e impedimentos", "Escalação prevista", "Últimos jogos dos times", "Alertas do favorito", "Análises de oportunidades", "Painel com 8 ligas"].map((item) => (
            <span key={item} className="rounded-lg bg-[var(--surface-3)] px-2 py-1 font-semibold">✓ {item}</span>
          ))}
        </div>
      </div>

      <p className="text-center text-[0.72rem] muted">
        Já tem conta? <Link href="/login" className="font-bold text-[var(--brand)]">Entrar</Link>
      </p>
    </div>
  );
}

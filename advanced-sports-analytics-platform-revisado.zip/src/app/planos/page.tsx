import Link from "next/link";
import { subscribeAction } from "@/app/actions";
import { accessInfo, getSessionUser } from "@/lib/auth";
import { getPlans } from "@/lib/data";
import { AccessPill, SectionHeader } from "@/components/ui";
import { brl } from "@/lib/utils";

export const dynamic = "force-dynamic";

const COMPARISON = [
  { feature: "Placar ao vivo e resultado", free: true, vip: true },
  { feature: "Gols, cartões e escanteios", free: true, vip: true },
  { feature: "Faltas e impedimentos detalhados", free: false, vip: true },
  { feature: "Comparativo completo de estatísticas", free: false, vip: true },
  { feature: "Escalação prevista dos dois times", free: false, vip: true },
  { feature: "Últimos jogos e desempenho completo", free: true, vip: true },
  { feature: "Alertas do time favorito", free: false, vip: true },
  { feature: "Análises e oportunidades ilimitadas", free: false, vip: true },
  { feature: "Integrações de API em tempo real", free: false, vip: true },
];

export default async function PlansPage() {
  const [session, plans] = await Promise.all([getSessionUser(), getPlans()]);
  const info = session ? accessInfo(session) : null;

  return (
    <div className="space-y-4">
      <div className="card relative overflow-hidden border-0 brand-gradient px-4 py-4 text-white">
        <div className="pointer-events-none absolute inset-0 pitch opacity-30" />
        <div className="relative">
          <span className="chip !border-white/25 !bg-white/15 !text-white">PLANOS GREENSCORE</span>
          <h1 className="mt-2 text-xl font-black leading-tight">Assine o VIP e não perca nenhum lance</h1>
          <p className="mt-1 max-w-md text-[0.72rem] text-emerald-50/85">
            Acesso completo a gols, cartões, impedimentos, faltas, escanteios, pênaltis, escalações previstas, análises e alertas em tempo real.
          </p>
          {session ? (
            <div className="mt-2 flex items-center gap-2 text-[0.65rem]">
              <AccessPill active={info?.active ?? false} label={info?.label ?? ""} />
              <span className="text-emerald-50/85">expira {new Date(session.accessExpiresAt).toLocaleDateString("pt-BR")}</span>
            </div>
          ) : (
            <Link href="/cadastro" className="btn mt-2 !bg-white !text-emerald-900">Testar 1 dia grátis com Gmail</Link>
          )}
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {plans.map((plan) => (
          <div key={plan.id} className={`card flex flex-col overflow-hidden ${plan.isFeatured ? "border-emerald-500/60 ring-2 ring-emerald-500/20" : ""}`}>
            {plan.isFeatured ? <div className="bg-emerald-500 py-1 text-center text-[0.58rem] font-black uppercase tracking-wide text-white">Mais escolhido</div> : null}
            <div className="flex-1 px-3 py-3">
              <p className="text-[0.85rem] font-extrabold">{plan.name}</p>
              <p className="text-[0.6rem] muted">{plan.tagline}</p>
              <p className="mt-2 text-xl font-black leading-none">{brl(plan.priceCents)}</p>
              <p className="text-[0.58rem] muted">{plan.durationDays} dia(s) de acesso</p>
              <div className="mt-2 space-y-1">
                {plan.features.map((feature) => (
                  <p key={feature} className="flex items-start gap-1 text-[0.65rem] leading-snug">
                    <span className="text-emerald-500">✓</span>{feature}
                  </p>
                ))}
              </div>
            </div>
            <form action={subscribeAction} className="px-3 pb-3">
              <input type="hidden" name="plan" value={plan.slug} />
              <button className={`btn w-full !py-2 !text-[0.72rem] ${plan.isFeatured ? "btn-primary" : "btn-ghost"}`}>
                {session ? "Ativar este plano" : "Criar conta e assinar"}
              </button>
            </form>
          </div>
        ))}
      </div>

      <section>
        <SectionHeader title="Comparativo de acesso" subtitle="O que muda entre teste e VIP" icon={<span>📋</span>} />
        <div className="card overflow-hidden">
          <div className="grid grid-cols-[1fr_64px_64px] border-b px-2.5 py-1.5 text-[0.58rem] font-bold uppercase tracking-wide muted hairline">
            <span>Recurso</span><span className="text-center">Teste</span><span className="text-center">VIP</span>
          </div>
          {COMPARISON.map((row) => (
            <div key={row.feature} className="grid grid-cols-[1fr_64px_64px] items-center border-b px-2.5 py-1.5 text-[0.68rem] last:border-0 hairline">
              <span className="font-semibold">{row.feature}</span>
              <span className="text-center">{row.free ? "✅" : "—"}</span>
              <span className="text-center">{row.vip ? "✅" : "—"}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="grid gap-2 sm:grid-cols-2">
        <div className="card px-3 py-3">
          <p className="text-[0.8rem] font-extrabold">📱 Feito para o celular</p>
          <p className="mt-1 text-[0.68rem] leading-relaxed muted">Interface compacta estilo FlashScore/SofaScore, com navegação inferior, placares atualizados e alertas na tela. Tema escuro e claro inclusos.</p>
        </div>
        <div className="card px-3 py-3">
          <p className="text-[0.8rem] font-extrabold">🔐 Acesso com data definida</p>
          <p className="mt-1 text-[0.68rem] leading-relaxed muted">Cada usuário tem uma data de expiração calculada pelo plano escolhido. Cadastros com Gmail recebem 1 dia grátis e depois precisam renovar o VIP.</p>
        </div>
      </section>

      <p className="text-center text-[0.62rem] leading-relaxed muted">
        Pagamento simulado nesta demonstração: ao ativar um plano, o acesso é liberado imediatamente pela quantidade de dias correspondente.
      </p>
    </div>
  );
}

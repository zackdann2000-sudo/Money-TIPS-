import Link from "next/link";
import { DonutChart, ClientOnly } from "@/components/charts";
import { StatTile, SectionHeader } from "@/components/ui";
import { getTrackRecord } from "@/lib/track-record";
import { ESPN_LEAGUES } from "@/lib/espn";

export const dynamic = "force-dynamic";

export default async function TrackRecordPage({ searchParams }: { searchParams: Promise<{ dias?: string }> }) {
  const sp = await searchParams;
  const days = [7, 14, 30, 90].includes(Number(sp.dias)) ? Number(sp.dias) : 30;
  const tr = await getTrackRecord(days);
  const leagueName = (code: string) => ESPN_LEAGUES.find((l) => l.code === code)?.name ?? code;
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><Link href="/ia" className="chip">← IA Analista</Link><Link href="/ia/desempenho" className="chip">Backtest & metodologia →</Link></div>
      <section className="card relative overflow-hidden border-0 brand-gradient px-4 py-4 text-white">
        <div className="pointer-events-none absolute inset-0 pitch opacity-25" />
        <div className="relative">
          <span className="chip !border-white/25 !bg-white/15 !text-white">TRACK RECORD</span>
          <h1 className="mt-1.5 text-xl font-black leading-tight">Desempenho do modelo</h1>
          <p className="text-[0.72rem] text-emerald-50/85">Previsões pré-jogo registradas pelo site antes de cada partida e conferidas com o resultado real. Green = o favorito do modelo (1X2) venceu.</p>
        </div>
      </section>

      <div className="flex gap-1.5">{[7, 14, 30, 90].map((d) => <Link key={d} href={`/desempenho?dias=${d}`} className={`chip !px-3 !py-1.5 ${days === d ? "!border-emerald-500/50 !bg-emerald-500/10 !text-emerald-500" : ""}`}>Últimos {d} dias</Link>)}</div>

      <section className="card grid gap-3 px-3 py-4 sm:grid-cols-[180px_1fr]">
        <ClientOnly height={160}><DonutChart green={tr.greens} red={tr.reds} /></ClientOnly>
        <div className="grid grid-cols-2 gap-2 self-center sm:grid-cols-4">
          <StatTile label={`Taxa de acerto (${days} d)`} value={tr.settled ? `${tr.taxa}%` : "—"} hint={`${tr.settled} previsões liquidadas`} icon="🎯" />
          <StatTile label="Greens" value={tr.greens} hint={tr.greens ? `prob. média ${Math.round(tr.avgProbGreens * 100)}%` : "favorito venceu"} icon="🟢" />
          <StatTile label="Reds" value={tr.reds} hint="favorito não venceu" icon="🔴" />
          <StatTile label="Pendentes" value={tr.pending} hint="jogos ainda não encerrados" icon="⏳" />
        </div>
      </section>

      {tr.byLeague.length ? (
        <section>
          <SectionHeader title="Por competição" subtitle="Acerto do favorito do modelo" icon={<span>🏆</span>} />
          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {tr.byLeague.map((l) => (
              <div key={l.league} className="flex items-center gap-2 px-3 py-2 text-[0.7rem]">
                <span className="w-40 truncate font-semibold">{leagueName(l.league)}</span>
                <div className="flex h-2 flex-1 overflow-hidden rounded-full bg-[var(--surface-3)]"><div className="bg-emerald-500" style={{ width: `${l.taxa}%` }} /><div className="bg-rose-500" style={{ width: `${100 - l.taxa}%` }} /></div>
                <span className="w-24 text-right tabular-nums"><b className="text-emerald-500">{l.g}</b> · <b className="text-rose-500">{l.r}</b> · {l.taxa}%</span>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section>
        <SectionHeader title="Histórico de previsões" subtitle="Mais recentes primeiro · pick = favorito do modelo" icon={<span>🧾</span>} />
        {tr.items.length === 0 ? <div className="card px-4 py-8 text-center text-[0.74rem] muted">Ainda não há previsões registradas neste período. Elas são gravadas automaticamente quando alguém abre a análise de um jogo antes de ele começar.</div> : (
          <div className="card divide-y divide-[var(--line)] overflow-hidden">
            {tr.items.map((i) => (
              <Link key={i.id} href={i.matchId ? `/jogos/${i.matchId}` : "#"} className="flex items-center gap-2 px-3 py-2 text-[0.7rem]">
                <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${i.result === "green" ? "bg-emerald-500" : i.result === "red" ? "bg-rose-500" : "bg-zinc-400"}`} />
                <span className="min-w-0 flex-1 truncate font-semibold">{i.home} <span className="muted">x</span> {i.away} <span className="muted">· {leagueName(i.league)}</span></span>
                <span className="hidden text-[0.6rem] muted sm:block">pick: <b className="text-[var(--ink)]">{i.pickLabel}</b> {Math.round(i.prob * 100)}%</span>
                <span className="w-12 text-right font-black tabular-nums">{i.score}</span>
                <span className={`w-14 text-right text-[0.6rem] font-bold uppercase ${i.result === "green" ? "text-emerald-500" : i.result === "red" ? "text-rose-500" : "muted"}`}>{i.result === "pending" ? "pendente" : i.result}</span>
              </Link>
            ))}
          </div>
        )}
      </section>
      <p className="px-1 text-[0.58rem] leading-relaxed muted">Métricas probabilísticas (Brier, log loss, calibração) e backtest histórico em <Link href="/ia/desempenho" className="font-bold text-[var(--brand)]">Backtest & metodologia</Link>. Acertar o favorito não é garantia: o modelo é avaliado pela qualidade das probabilidades, não só pelo resultado.</p>
    </div>
  );
}

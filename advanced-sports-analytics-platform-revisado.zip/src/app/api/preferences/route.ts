import { getSessionUser } from "@/lib/auth";
import { listarPreferencias, obterPreferencias, removerPreferencias, salvarPreferencias } from "@/lib/alert-engine";
import type { AlertFlags } from "@/db/schema";

export const dynamic = "force-dynamic";

const KEYS: (keyof AlertFlags)[] = ["goals", "redCards", "lineups", "matchStart", "matchEnd", "substitutions", "yellowCards", "corners", "pressure"];

/** GET /api/preferences?teamId=1[&matchId=2] → preferência do usuário (ou lista completa sem params). */
export async function GET(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Faça login." }, { status: 401 });
  const sp = new URL(request.url).searchParams;
  const teamId = Number(sp.get("teamId"));
  if (!teamId) return Response.json({ preferences: await listarPreferencias(user.id) });
  const matchId = Number(sp.get("matchId")) || null;
  const pref = await obterPreferencias(user.id, teamId, matchId);
  return Response.json({ preference: pref });
}

/** POST /api/preferences { teamId, matchId?, alerts: {...}, muted? } */
export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Faça login para salvar alertas." }, { status: 401 });
  let body: { teamId?: number; matchId?: number | null; alerts?: Partial<AlertFlags>; muted?: boolean };
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }
  const teamId = Number(body.teamId);
  if (!Number.isInteger(teamId) || teamId <= 0) return Response.json({ error: "teamId inválido." }, { status: 400 });
  const matchId = body.matchId ? Number(body.matchId) : null;
  const alerts = Object.fromEntries(KEYS.map((k) => [k, Boolean(body.alerts?.[k])])) as AlertFlags;
  const id = await salvarPreferencias(user.id, teamId, matchId, alerts, Boolean(body.muted));
  return Response.json({ ok: true, id, alerts });
}

/** DELETE /api/preferences { teamId, matchId? } */
export async function DELETE(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Não autenticado." }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as { teamId?: number; matchId?: number | null };
  if (!body.teamId) return Response.json({ error: "teamId obrigatório." }, { status: 400 });
  await removerPreferencias(user.id, Number(body.teamId), body.matchId ? Number(body.matchId) : null);
  return Response.json({ ok: true });
}

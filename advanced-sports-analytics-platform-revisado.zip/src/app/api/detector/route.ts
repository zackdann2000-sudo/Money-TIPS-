import { buscarOportunidades, CATEGORIAS, LIGAS, type Categoria, type Filtros, type Local, type Periodo } from "@/lib/detector";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** GET /api/detector?categoria=Gols&periodo=Jogo%20Todo&linha=1.5&data=YYYY-MM-DD&liga=todas&amostra=10&local=casa&pagina=1 */
export async function GET(request: Request) {
  const sp = new URL(request.url).searchParams;
  const categoria = sp.get("categoria") as Categoria | null;
  const cat = CATEGORIAS.find((c) => c.key === categoria);
  if (!cat) return Response.json({ error: "Categoria inválida." }, { status: 400 });
  const periodo = (sp.get("periodo") === "1º Tempo" ? "1º Tempo" : "Jogo Todo") as Periodo;
  if (periodo === "1º Tempo" && !cat.suporta1T) return Response.json({ error: `${cat.key} não possui dados de 1º tempo na fonte.` }, { status: 400 });
  const linha = Number(sp.get("linha") ?? cat.linhas[0] ?? 0);
  if (!cat.semLinha && !cat.linhas.includes(linha)) return Response.json({ error: "Linha inválida para este mercado." }, { status: 400 });
  const data = sp.get("data") ?? "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return Response.json({ error: "Data inválida (YYYY-MM-DD)." }, { status: 400 });
  const liga = sp.get("liga") ?? "todas";
  if (!LIGAS.some((l) => l.code === liga)) return Response.json({ error: "Liga inválida." }, { status: 400 });
  const amostra = Number(sp.get("amostra")) === 5 ? 5 : 10;
  const localRaw = sp.get("local");
  const local: Local = localRaw === "casa" || localRaw === "fora" ? localRaw : "ambos";
  const filtros: Filtros = { categoria: cat.key, periodo, linha, data, liga, amostra, local, pagina: Number(sp.get("pagina")) || 1, porPagina: Number(sp.get("porPagina")) || 10, minTaxa: 70 };
  try {
    const result = await buscarOportunidades(filtros);
    return Response.json(result, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("detector", error);
    return Response.json({ error: "Falha ao gerar resultados." }, { status: 500 });
  }
}

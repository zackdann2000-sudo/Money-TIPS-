import { getMatchById } from "@/lib/data";
import { callIntegration, getIntegration } from "@/lib/providers";

export const dynamic = "force-dynamic";

type Point = { minute: number; value: number };

/**
 * GET /api/jogos/:id/momentum → pressão minuto a minuto.
 * Fonte real: Bzzoiro `/events/{id}/stats/` → campo `momentum: [{ m, v }]` (v > 0 mandante, v < 0 visitante).
 * Se a partida não existir na Bzzoiro, retorna { source: "mock" } com uma curva ilustrativa — o front marca como DEMO.
 * ↳ Ponto de integração para outra API (ex.: Sportmonks "pressure index"): mapear para Point[] aqui.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const data = await getMatchById(Number(id));
  if (!data) return Response.json({ error: "Partida não encontrada." }, { status: 404 });
  const { match: m, events } = data;
  const goals = events.filter((e) => e.type === "goal" || e.type === "penalty").map((e) => ({ minute: e.minute, side: e.side as "home" | "away" }));
  if (m.status !== "scheduled" && (await getIntegration("bzzoiro"))) {
    const day = m.kickoff.toISOString().slice(0, 10);
    const ev = await callIntegration("bzzoiro", "/events/", { date_from: day, date_to: day, page_size: "200" });
    type Ev = { id: number; home_team: string; away_team: string };
    const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
    const same = (a: string, b: string) => { const x = norm(a), y = norm(b); return x === y || x.includes(y) || y.includes(x); };
    const found = ev.ok ? ((ev.data as { results?: Ev[] }).results ?? []).find((e) => same(e.home_team, m.homeName) && same(e.away_team, m.awayName)) : null;
    if (found) {
      const st = await callIntegration("bzzoiro", `/events/${found.id}/stats/`);
      const mom = st.ok ? ((st.data as { momentum?: { m: number; v: number }[] }).momentum ?? []) : [];
      if (mom.length >= 10) {
        const points: Point[] = mom.map((p) => ({ minute: p.m, value: Math.max(-100, Math.min(100, p.v)) }));
        return Response.json({ source: "bzzoiro", points, goals }, { headers: { "Cache-Control": "no-store" } });
      }
    }
  }
  // ---- MOCK (design) — substituir pela API quando disponível ----
  const seed = m.id * 7919;
  const rnd = (i: number) => { const x = Math.sin(seed + i * 12.9898) * 43758.5453; return x - Math.floor(x); };
  const points: Point[] = Array.from({ length: 90 }, (_, i) => ({ minute: i + 1, value: Math.round((Math.sin(i / 9) * 45 + (rnd(i) - 0.5) * 50)) }));
  return Response.json({ source: "mock", points, goals }, { headers: { "Cache-Control": "no-store" } });
}

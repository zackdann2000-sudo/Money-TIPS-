import { getOracleData } from "@/lib/oracle";

export const dynamic = "force-dynamic";

/** GET /api/jogos/:id/oracle — veredito do Scouter Oracle para a partida. */
export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const matchId = Number(id);
  if (!Number.isInteger(matchId) || matchId <= 0) return Response.json({ error: "Identificador de partida inválido." }, { status: 400 });
  try {
    const result = await getOracleData(matchId);
    if ("error" in result) return Response.json({ error: result.error }, { status: result.status });
    return Response.json(result, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("oracle route", error);
    return Response.json({ error: "Falha ao calcular o veredito. Tente novamente em instantes." }, { status: 500 });
  }
}

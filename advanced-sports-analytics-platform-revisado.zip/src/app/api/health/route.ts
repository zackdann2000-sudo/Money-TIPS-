import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await db.execute(sql`select 1`);
    if (new URL(request.url).searchParams.get("cache") === "1") {
      const { apiCacheStats } = await import("@/lib/api-cache");
      return Response.json({ ok: true, cache: apiCacheStats() });
    }
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}

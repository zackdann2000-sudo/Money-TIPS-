import { and, desc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { matches, notifications } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { getFavorites, getUnreadCount } from "@/lib/data";
import { normalizePrefs } from "@/lib/alerts";
import { ensureFreshData } from "@/lib/espn";

export const dynamic = "force-dynamic";

/**
 * Feed pessoal de alertas: devolve somente as notificações do usuário logado
 * (já filtradas pelas preferências que ele configurou) criadas após `since`.
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const since = Number(searchParams.get("since") ?? 0) || 0;
  try {
    try {
      await ensureFreshData();
    } catch {
      /* sincronização opcional */
    }
    const session = await getSessionUser();
    const liveRows = await db
      .select({ id: matches.id, homeTeamId: matches.homeTeamId, awayTeamId: matches.awayTeamId })
      .from(matches)
      .where(eq(matches.status, "live"));
    const liveTeamIds = new Set(liveRows.flatMap((row) => [row.homeTeamId, row.awayTeamId]));

    if (!session) {
      return Response.json({ liveCount: liveRows.length, loggedIn: false, unread: 0, favoriteTeams: [], notifications: [], lastId: 0, sound: false, stamp: Date.now() });
    }

    const prefs = normalizePrefs(session.alertPrefs);
    const favorites = await getFavorites(session.id);
    const favoriteTeams = favorites.filter((row) => liveTeamIds.has(row.team.id)).map((row) => ({ id: row.team.id, name: row.team.name }));
    const unread = await getUnreadCount(session.id);

    const rows = await db
      .select({ id: notifications.id, type: notifications.type, title: notifications.title, body: notifications.body, matchId: notifications.matchId, teamId: notifications.teamId })
      .from(notifications)
      .where(since > 0 ? and(eq(notifications.userId, session.id), gt(notifications.id, since)) : eq(notifications.userId, session.id))
      .orderBy(desc(notifications.id))
      .limit(since > 0 ? 10 : 1);

    const lastId = rows[0]?.id ?? since;
    return Response.json({
      liveCount: liveRows.length,
      loggedIn: true,
      unread,
      favoriteTeams,
      sound: prefs.sound,
      lastId,
      notifications: since > 0 ? rows.reverse() : [],
      stamp: Date.now(),
    });
  } catch (error) {
    console.error("live api error", error);
    return Response.json({ liveCount: 0, loggedIn: false, unread: 0, favoriteTeams: [], notifications: [], lastId: since, sound: false, stamp: Date.now() }, { status: 200 });
  }
}

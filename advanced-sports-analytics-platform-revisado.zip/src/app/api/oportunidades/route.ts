import { calcularOportunidades } from "@/lib/opportunities";

export const dynamic = "force-dynamic";

/** GET /api/oportunidades?timeId=12&mandante=1[&antes=YYYY-MM-DD] */
export async function GET(request: Request) {
  const sp = new URL(request.url).searchParams;
  const timeId = Number(sp.get("timeId"));
  if (!Number.isInteger(timeId) || timeId <= 0) return Response.json({ error: "timeId inválido." }, { status: 400 });
  const isMandante = sp.get("mandante") !== "0";
  const antes = sp.get("antes") && /^\d{4}-\d{2}-\d{2}$/.test(sp.get("antes")!) ? new Date(`${sp.get("antes")}T00:00:00Z`) : new Date();
  const result = await calcularOportunidades(timeId, isMandante, antes);
  // formato pedido: array puro em `oportunidades`; o restante é contexto
  return Response.json(result, { headers: { "Cache-Control": "no-store" } });
}

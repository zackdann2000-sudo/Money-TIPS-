import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { favorites, notifications, teams } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { getFavorites } from "@/lib/data";

export const dynamic = "force-dynamic";

/** GET /api/favorites — favoritos do usuário logado (fonte usada pelos alertas). */
export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ favorites: [], loggedIn: false }, { status: 200 });
  const rows = await getFavorites(user.id);
  return Response.json({ loggedIn: true, favorites: rows.map((r) => ({ id: r.team.id, name: r.team.name, slug: r.team.slug, logo: r.team.logo, color: r.team.badgeColor })) });
}

/** POST /api/favorites { teamId, action: "add" | "remove" } */
export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Faça login para sincronizar favoritos." }, { status: 401 });
  let body: { teamId?: number; action?: string };
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "JSON inválido." }, { status: 400 });
  }
  const teamId = Number(body.teamId);
  if (!Number.isInteger(teamId) || teamId <= 0) return Response.json({ error: "teamId inválido." }, { status: 400 });
  const [team] = await db.select({ id: teams.id, name: teams.name }).from(teams).where(eq(teams.id, teamId)).limit(1);
  if (!team) return Response.json({ error: "Time não encontrado." }, { status: 404 });

  const [existing] = await db.select({ id: favorites.id }).from(favorites).where(and(eq(favorites.userId, user.id), eq(favorites.teamId, teamId))).limit(1);
  if (body.action === "remove") {
    if (existing) await db.delete(favorites).where(eq(favorites.id, existing.id));
    return Response.json({ ok: true, favorite: false });
  }
  if (!existing) {
    await db.insert(favorites).values({ userId: user.id, teamId });
    await db.insert(notifications).values({ userId: user.id, teamId, type: "favorite", title: `⭐ ${team.name} adicionado aos favoritos`, body: "Você receberá os alertas configurados para este time." });
  }
  return Response.json({ ok: true, favorite: true });
}

import { getDailyMatchesWithLiveStats, getLiveMatchStats } from "@/lib/sports-alert";

export const dynamic = "force-dynamic";

/**
 * GET /api/sports-alert?date=YYYY-MM-DD   → lista do dia no formato Sports Alert (basicStats preenchido nos jogos ao vivo)
 * GET /api/sports-alert?matchId=123&source=sportmonks → basicStats de uma partida
 */
export async function GET(request: Request) {
  const sp = new URL(request.url).searchParams;
  const matchId = Number(sp.get("matchId"));
  if (matchId) {
    const source = sp.get("source") === "bzzoiro" ? "bzzoiro" : "sportmonks";
    const stats = await getLiveMatchStats(matchId, source);
    return Response.json({ matchId, basicStats: stats }, { headers: { "Cache-Control": "no-store" } });
  }
  const date = sp.get("date") && /^\d{4}-\d{2}-\d{2}$/.test(sp.get("date")!) ? sp.get("date")! : undefined;
  const feed = await getDailyMatchesWithLiveStats(date);
  const status = feed.source === "none" ? 502 : 200;
  return Response.json(feed, { status, headers: { "Cache-Control": "no-store" } });
}

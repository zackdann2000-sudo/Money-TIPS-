import { loadStatRows, METRICS, PLAYER_LEAGUES, rankRows, syncLeaguePlayers, currentSeasonFor, getPlayersSyncState } from "@/lib/players";

export const dynamic = "force-dynamic";

const buckets = new Map<string, { count: number; reset: number }>();
function rateLimited(ip: string, limit = 60) {
  const now = Date.now();
  const bucket = buckets.get(ip);
  if (!bucket || bucket.reset < now) {
    buckets.set(ip, { count: 1, reset: now + 60_000 });
    return false;
  }
  bucket.count += 1;
  return bucket.count > limit;
}

const POSITIONS = new Set(["G", "D", "M", "F"]);

/** API pública de rankings (somente leitura). Parâmetros validados no servidor. */
export async function GET(request: Request) {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  if (rateLimited(ip)) return Response.json({ error: "Limite de requisições excedido. Tente novamente em instantes." }, { status: 429 });

  const sp = new URL(request.url).searchParams;
  const league = sp.get("liga") ?? "bra.1";
  if (!PLAYER_LEAGUES.some((l) => l.code === league)) return Response.json({ error: "Liga inválida." }, { status: 400 });
  const metricKey = sp.get("metrica") ?? "goals";
  if (!METRICS.some((m) => m.key === metricKey)) return Response.json({ error: "Métrica inválida." }, { status: 400 });
  const position = sp.get("posicao") ?? "";
  if (position && !POSITIONS.has(position)) return Response.json({ error: "Posição inválida." }, { status: 400 });
  const clamp = (v: string | null, min: number, max: number, fallback: number) => {
    const num = Number(v);
    return Number.isFinite(num) && v !== null ? Math.min(max, Math.max(min, Math.trunc(num))) : fallback;
  };

  const state = await getPlayersSyncState(league);
  if (!state?.lastSuccessAt) await syncLeaguePlayers(league);
  const season = clamp(sp.get("temporada"), 2000, 2100, 0) || (await currentSeasonFor(league)) || undefined;
  const rows = await loadStatRows({ league, season, team: sp.get("time") ?? undefined, position: position || undefined });
  const result = rankRows(rows, {
    metric: metricKey,
    minApps: clamp(sp.get("minJogos"), 0, 60, 1),
    minMinutes: clamp(sp.get("minMinutos"), 0, 6000, 0),
    order: sp.get("ordem") === "asc" ? "asc" : "desc",
    search: sp.get("q")?.slice(0, 60) ?? undefined,
    nationality: sp.get("pais")?.slice(0, 40) ?? undefined,
    page: clamp(sp.get("pagina"), 1, 500, 1),
    pageSize: clamp(sp.get("tamanho"), 10, 100, 25),
  });
  return Response.json({
    source: "ESPN",
    league,
    season,
    metric: { key: result.metric.key, label: result.metric.label, category: result.metric.category, note: result.metric.note ?? null, minSample: result.metric.minSample?.label ?? null },
    total: result.total,
    excludedForSample: result.excludedForSample,
    updatedAt: state?.lastSuccessAt ?? null,
    items: result.items.map((i) => ({
      rank: i.rank,
      playerId: i.stat.player.id,
      name: i.stat.player.name,
      position: i.stat.player.position,
      nationality: i.stat.player.nationality,
      team: i.stat.teamName,
      appearances: i.stat.appearances,
      minutes: i.stat.minutes,
      value: i.value,
      perGame: i.perGame,
      per90: i.per90,
    })),
  });
}

import { getSessionUser } from "@/lib/auth";
import { PLAYER_LEAGUES, syncLeaguePlayers } from "@/lib/players";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * Sincroniza elencos e estatísticas de jogadores.
 * Acesso: administrador logado OU cron com header `x-sync-secret` igual a SYNC_SECRET.
 * GET /api/players/sync?liga=bra.1&force=1
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const secret = process.env.SYNC_SECRET;
  const viaCron = Boolean(secret) && request.headers.get("x-sync-secret") === secret;
  const user = viaCron ? null : await getSessionUser();
  if (!viaCron && user?.role !== "admin") return Response.json({ error: "Não autorizado." }, { status: 401 });

  const league = searchParams.get("liga");
  const force = searchParams.get("force") === "1";
  const targets = league ? PLAYER_LEAGUES.filter((l) => l.code === league) : PLAYER_LEAGUES.slice(0, 6);
  if (!targets.length) return Response.json({ error: "Liga inválida." }, { status: 400 });
  const results: Record<string, unknown> = {};
  for (const target of targets) {
    results[target.code] = await syncLeaguePlayers(target.code, force);
  }
  return Response.json({ ok: true, results });
}

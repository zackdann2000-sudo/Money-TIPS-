import { ensureSeed } from "@/db/seed";
import { getSyncStatus, syncEspn } from "@/lib/espn";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Sincroniza os jogos reais (ESPN). Pode ser chamado por cron: GET /api/sync?force=1 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const force = searchParams.get("force") === "1";
  try {
    await ensureSeed();
  } catch {
    /* seed opcional */
  }
  const report = await syncEspn(force);
  const status = await getSyncStatus();
  return Response.json({
    ...report,
    lastSuccessAt: status?.lastSuccessAt ?? null,
    lastMessage: status?.lastMessage ?? "",
    matchesSynced: status?.matchesSynced ?? 0,
  });
}

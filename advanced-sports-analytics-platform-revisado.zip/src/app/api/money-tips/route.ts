import { getPickDoDia } from "@/lib/money-tips";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** GET /api/money-tips?data=YYYY-MM-DD → { jogo, analiseTexto, oportunidade } do Pick do Dia (+ melhores). */
export async function GET(request: Request) {
  const sp = new URL(request.url).searchParams;
  const data = sp.get("data") && /^\d{4}-\d{2}-\d{2}$/.test(sp.get("data")!) ? sp.get("data")! : undefined;
  try {
    const result = await getPickDoDia(data);
    const pick = result.pick;
    return Response.json(
      {
        data: result.data,
        jogosAnalisados: result.jogosAnalisados,
        aviso: result.aviso ?? null,
        // formato pedido (nível raiz) + extras
        jogo: pick?.jogo ?? null,
        analiseTexto: pick?.analiseTexto ?? null,
        oportunidade: pick?.oportunidade ?? null,
        melhores: result.melhores,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    console.error("money-tips", error);
    return Response.json({ error: "Falha ao calcular o Pick do Dia." }, { status: 500 });
  }
}

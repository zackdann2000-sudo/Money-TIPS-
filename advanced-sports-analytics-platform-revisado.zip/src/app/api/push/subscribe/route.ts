import { getSessionUser } from "@/lib/auth";
import { enviarNotificacao, listarSubscriptions, pushEnabled, removerSubscription, salvarSubscription, vapidPublicKey } from "@/lib/push";

export const dynamic = "force-dynamic";

/** GET → chave pública VAPID + inscrições do usuário logado. */
export async function GET() {
  const user = await getSessionUser();
  const subs = user ? await listarSubscriptions(user.id) : [];
  return Response.json({ enabled: pushEnabled(), publicKey: vapidPublicKey(), loggedIn: Boolean(user), subscriptions: subs.map((s) => ({ id: s.id, userAgent: s.userAgent, createdAt: s.createdAt, lastUsedAt: s.lastUsedAt, endpointHost: new URL(s.endpoint).host })) });
}

/** POST { subscription, userAgent } → salva a inscrição associada ao usuário logado. */
export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Faça login para ativar as notificações push." }, { status: 401 });
  if (!pushEnabled()) return Response.json({ error: "Servidor sem chaves VAPID configuradas." }, { status: 503 });
  try {
    const body = (await request.json()) as { subscription: { endpoint: string; keys: { p256dh: string; auth: string } }; userAgent?: string };
    await salvarSubscription(user.id, body.subscription, body.userAgent ?? request.headers.get("user-agent") ?? "");
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Subscription inválida." }, { status: 400 });
  }
}

/** DELETE { endpoint } → remove a inscrição deste dispositivo. */
export async function DELETE(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Não autenticado." }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as { endpoint?: string };
  if (!body.endpoint) return Response.json({ error: "endpoint obrigatório." }, { status: 400 });
  await removerSubscription(body.endpoint, user.id);
  return Response.json({ ok: true });
}

/** PUT → envia uma notificação de teste para o próprio usuário. */
export async function PUT() {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Não autenticado." }, { status: 401 });
  const result = await enviarNotificacao(user.id, "🔔 GreenScore — teste de push", "Se você está lendo isto fora do site, o Web Push está funcionando!", { url: "/notificacoes", tag: "teste", type: "test" });
  return Response.json(result);
}

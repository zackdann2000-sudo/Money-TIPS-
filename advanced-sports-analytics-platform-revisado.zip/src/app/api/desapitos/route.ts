import { buscarDesapitos, type Amostra, type Periodo } from "@/lib/desapito";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** GET /api/desapitos?data=YYYY-MM-DD&periodo=Jogo%20completo&amostra=10&liga=todas&duplos=1 */
export async function GET(request: Request) {
  const sp = new URL(request.url).searchParams;
  const data = sp.get("data") && /^\d{4}-\d{2}-\d{2}$/.test(sp.get("data")!) ? sp.get("data")! : undefined;
  const periodoRaw = sp.get("periodo");
  const periodo: Periodo = periodoRaw === "1º tempo" || periodoRaw === "2º tempo" ? periodoRaw : "Jogo completo";
  const amostra: Amostra = Number(sp.get("amostra")) === 5 ? 5 : 10;
  const liga = sp.get("liga") ?? "todas";
  try {
    const r = await buscarDesapitos({ data, periodo, amostra, liga, apenasDuplos: sp.get("duplos") === "1" });
    return Response.json(r, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("desapitos", error);
    return Response.json({ error: "Falha ao calcular desapitos." }, { status: 500 });
  }
}

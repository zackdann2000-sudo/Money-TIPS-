import { registerUser } from "@/lib/users";

export const dynamic = "force-dynamic";

/**
 * Cadastro via API (útil para apps mobile e integrações).
 * Cadastros com @gmail.com recebem automaticamente 1 dia de acesso completo.
 */
export async function POST(request: Request) {
  let payload: { name?: string; email?: string; password?: string };
  try {
    payload = await request.json();
  } catch {
    return Response.json({ ok: false, error: "JSON inválido." }, { status: 400 });
  }
  const result = await registerUser({
    name: String(payload.name ?? ""),
    email: String(payload.email ?? ""),
    password: String(payload.password ?? ""),
  });
  if (!result.ok) return Response.json(result, { status: 400 });
  return Response.json(
    {
      ok: true,
      userId: result.userId,
      email: result.email,
      trialSource: result.trialSource,
      accessExpiresAt: result.accessExpiresAt.toISOString(),
      message:
        result.trialSource === "gmail-trial"
          ? "Conta Gmail criada com 1 dia grátis de acesso completo."
          : "Conta criada com 6 horas de teste. Assine o VIP para continuar depois.",
    },
    { status: 201 },
  );
}

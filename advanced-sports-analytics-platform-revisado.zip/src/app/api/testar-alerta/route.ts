import { getSessionUser } from "@/lib/auth";
import { simularGol } from "@/lib/alert-engine";

export const dynamic = "force-dynamic";

/**
 * GET /api/testar-alerta?teamId=123[&player=Gabigol&minute=32]
 * Simula um gol do time, consulta as preferências e dispara push (Web Push + OneSignal) para quem pediu "Gols".
 * Restrito a administradores para não disparar push em massa por acidente.
 */
export async function GET(request: Request) {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") return Response.json({ error: "Apenas administradores podem disparar alertas de teste." }, { status: 401 });
  const sp = new URL(request.url).searchParams;
  const teamId = Number(sp.get("teamId"));
  if (!Number.isInteger(teamId) || teamId <= 0) return Response.json({ error: "teamId inválido." }, { status: 400 });
  try {
    const result = await simularGol(teamId, sp.get("player") ?? "Gabigol", Number(sp.get("minute")) || 32);
    return Response.json({ ok: true, ...result });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Falha" }, { status: 400 });
  }
}

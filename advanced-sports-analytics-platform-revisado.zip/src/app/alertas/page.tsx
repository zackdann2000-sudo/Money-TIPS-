import Link from "next/link";
import SportsAlertBoard from "@/components/sports-alert-cards";
import { getSessionUser } from "@/lib/auth";
import { getIntegration } from "@/lib/providers";
import { todayUtcDate } from "@/lib/sports-alert";

export const dynamic = "force-dynamic";

export default async function SportsAlertPage() {
  const [session, sm] = await Promise.all([getSessionUser(), getIntegration("sportmonks")]);
  return (
    <div className="space-y-4">
      <section className="card relative overflow-hidden border-0 bg-gradient-to-br from-zinc-900 via-zinc-800 to-emerald-800 px-4 py-4 text-white">
        <div className="pointer-events-none absolute inset-0 pitch opacity-20" />
        <div className="relative">
          <span className="chip !border-white/25 !bg-white/15 !text-white">FEED SPORTS ALERT</span>
          <h1 className="mt-1.5 text-xl font-black leading-tight">Jogos do dia</h1>
          <p className="text-[0.72rem] text-emerald-50/85">Logos, horário, país e status no formato do Sports Alert · xG, posse e chutes nos jogos ao vivo.</p>
        </div>
      </section>
      {!sm ? (
        <div className="card border-amber-500/40 px-3 py-2.5 text-[0.7rem]">
          <b>Sportmonks ainda sem chave.</b> O feed está usando a Bzzoiro (já ativa) como fallback — sem logos dos times. Cole sua chave da Sportmonks em {session?.role === "admin" ? <Link href="/admin/apis" className="font-bold text-[var(--brand)]">Admin → APIs de dados</Link> : "Admin → APIs de dados"} para ativar logos oficiais e xG da Sportmonks.
        </div>
      ) : null}
      <SportsAlertBoard initialDate={todayUtcDate()} />
    </div>
  );
}

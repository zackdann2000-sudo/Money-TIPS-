import DesapitosBoard from "@/components/desapitos-board";
import { ESPN_LEAGUES } from "@/lib/espn";

export const dynamic = "force-dynamic";

export default function DesapitosPage() {
  return <DesapitosBoard ligas={ESPN_LEAGUES.map((l) => ({ code: l.code, name: l.name, flag: l.flag }))} />;
}

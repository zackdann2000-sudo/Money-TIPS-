import Link from "next/link";
import { getLeagues, getMatches } from "@/lib/data";
import { MatchRow, SectionHeader, TeamBadge, FormPills } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function LeaguesPage() {
  const [leagues, matches] = await Promise.all([getLeagues(), getMatches()]);
  return (
    <div className="space-y-4">
      <div className="px-1">
        <h1 className="text-xl font-black tracking-tight">Ligas & competições</h1>
        <p className="text-[0.7rem] muted">Médias, classificação, jogos e análises por competição</p>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        {leagues.map((league) => {
          const leagueMatches = matches.filter((m) => m.leagueId === league.id);
          const live = leagueMatches.filter((m) => m.status === "live").length;
          return (
            <Link key={league.id} href={`/ligas/${league.slug}`} className="card card-hover overflow-hidden">
              <div className="flex items-center gap-2.5 px-3 py-3" style={{ background: `linear-gradient(120deg, ${league.color}22, transparent)` }}>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--surface-2)] text-lg shadow-sm">{league.flag}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.88rem] font-extrabold">{league.name}</p>
                  <p className="text-[0.6rem] muted">{league.country} · {league.season} · {leagueMatches.length} jogos</p>
                </div>
                {live > 0 ? <span className="chip !border-emerald-500/40 !bg-emerald-500/10 !text-emerald-500"><span className="live-dot" />{live}</span> : null}
              </div>
              <div className="grid grid-cols-3 divide-x divide-[var(--line)] border-t text-center hairline">
                <div className="py-1.5"><p className="text-[0.8rem] font-black">{league.avgGoals}</p><p className="text-[0.5rem] muted">gols/jogo</p></div>
                <div className="py-1.5"><p className="text-[0.8rem] font-black">{league.avgCorners}</p><p className="text-[0.5rem] muted">escanteios</p></div>
                <div className="py-1.5"><p className="text-[0.8rem] font-black">{league.avgCards}</p><p className="text-[0.5rem] muted">cartões</p></div>
              </div>
            </Link>
          );
        })}
      </div>

      <section>
        <SectionHeader title="Jogos das competições" subtitle="Seleção de partidas monitoradas" href="/jogos" />
        <div className="grid gap-1.5 sm:grid-cols-2">
          {matches.filter((m) => m.status !== "scheduled").slice(0, 6).map((match) => <MatchRow key={match.id} match={match} />)}
        </div>
      </section>

      <section className="card overflow-hidden">
        <div className="brand-gradient px-4 py-3 text-white">
          <h2 className="text-[0.95rem] font-extrabold">Como o GreenScore cobre as ligas</h2>
          <p className="text-[0.68rem] text-emerald-50/85">Médias reais do futebol europeu, brasileiro e sul-americano, atualizadas por integrações de API.</p>
        </div>
        <div className="divide-y hairline">
          {[
            ["🏆 Classificação", "Posição, pontos, saldo, forma e aproveitamento de cada clube."],
            ["📊 Médias da liga", "Gols, escanteios, cartões, faltas e impedimentos por jogo."],
            ["🔎 Análises", "Oportunidades filtradas por liga com nível de confiança."],
            ["📅 Calendário", "Rodadas, próximos jogos e resultados encerrados."],
          ].map(([title, text]) => (
            <div key={title} className="px-3 py-2">
              <p className="text-[0.75rem] font-bold">{title}</p>
              <p className="text-[0.65rem] muted">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="Destaques de times" subtitle="Forma atual por clube" href="/times" />
        <div className="no-scrollbar -mx-3 flex gap-2 overflow-x-auto px-3 pb-1 lg:mx-0 lg:px-0">
          {[["Flamengo", "#d5102b", "#1a1a1a", "VVVEV"], ["Real Madrid", "#febe10", "#00529f", "VVVVV"], ["Manchester City", "#6cabdd", "#1c2c5b", "VVVVE"], ["Bayern", "#dc052d", "#0066b2", "VVVVE"]].map(([name, color, colorAlt, form]) => (
            <div key={name} className="card min-w-[170px] px-2.5 py-2">
              <div className="flex items-center gap-2">
                <TeamBadge name={name} color={color} colorAlt={colorAlt} size={24} />
                <p className="truncate text-[0.74rem] font-bold">{name}</p>
              </div>
              <div className="mt-1.5"><FormPills form={form} /></div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

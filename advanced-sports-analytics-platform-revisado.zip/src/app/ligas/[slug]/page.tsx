import Link from "next/link";
import { notFound } from "next/navigation";
import { getInsights, getLeagueBySlug } from "@/lib/data";
import { FormPills, InsightCard, MatchRow, SectionHeader, TeamBadge, StatTile } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function LeaguePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getLeagueBySlug(slug);
  if (!data) notFound();
  const { league, teams, matches } = data;
  const insights = await getInsights({ limit: 6 });
  const live = matches.filter((m) => m.status === "live");
  const upcoming = matches.filter((m) => m.status === "scheduled");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href="/ligas" className="chip">← Ligas</Link>
        <span className="chip">{league.season}</span>
      </div>

      <section className="card overflow-hidden">
        <div className="flex items-center gap-3 px-3 py-3" style={{ background: `linear-gradient(120deg, ${league.color}33, transparent)` }}>
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--surface-2)] text-2xl shadow-sm">{league.flag}</span>
          <div>
            <h1 className="text-lg font-black leading-tight">{league.name}</h1>
            <p className="text-[0.65rem] muted">{league.country} · {teams.length} times monitorados · {matches.length} jogos</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 p-2">
          <StatTile label="Gols/jogo" value={league.avgGoals} icon="⚽" />
          <StatTile label="Escanteios" value={league.avgCorners} icon="🚩" />
          <StatTile label="Cartões" value={league.avgCards} icon="🟨" />
        </div>
      </section>

      <section>
        <SectionHeader title="Classificação" subtitle="Posição, aproveitamento e forma" icon={<span>🏆</span>} />
        <div className="card overflow-hidden">
          <div className="flex items-center gap-1.5 border-b px-2.5 py-1.5 text-[0.52rem] font-bold uppercase tracking-wide muted hairline">
            <span className="w-3">#</span><span className="flex-1">Time</span><span className="w-5 text-center">J</span><span className="w-8 text-center">V-E-D</span><span className="w-7 text-center">SG</span><span className="w-11 text-center">Forma</span>
          </div>
          {teams.map((team) => (
            <Link key={team.id} href={`/times/${team.slug}`} className="flex items-center gap-1.5 border-b px-2.5 py-1.5 last:border-0 hairline hover:bg-[var(--surface-3)]">
              <span className={`w-3 text-[0.62rem] font-bold ${team.position <= 4 ? "text-emerald-500" : "muted"}`}>{team.position}</span>
              <span className="flex flex-1 items-center gap-1.5 truncate text-[0.7rem] font-semibold">
                <TeamBadge name={team.name} color={team.badgeColor} colorAlt={team.badgeColorAlt} size={18} />{team.name}
              </span>
              <span className="w-5 text-center text-[0.62rem] tabular-nums muted">{team.played}</span>
              <span className="w-8 text-center text-[0.62rem] tabular-nums muted">{team.wins}-{team.draws}-{team.losses}</span>
              <span className="w-7 text-center text-[0.62rem] font-bold tabular-nums">{team.goalsFor - team.goalsAgainst}</span>
              <span className="w-11"><FormPills form={team.form} /></span>
            </Link>
          ))}
        </div>
      </section>

      {live.length ? (
        <section>
          <SectionHeader title="Ao vivo na competição" icon={<span className="live-dot" />} />
          <div className="space-y-1.5">{live.map((match) => <MatchRow key={match.id} match={match} />)}</div>
        </section>
      ) : null}

      <section>
        <SectionHeader title="Próximos jogos" subtitle="Agenda da competição" href="/jogos" />
        <div className="space-y-1.5">
          {upcoming.length ? upcoming.map((match) => <MatchRow key={match.id} match={match} />) : <div className="card px-3 py-4 text-center text-[0.75rem] muted">Sem jogos agendados.</div>}
        </div>
      </section>

      <section>
        <SectionHeader title="Oportunidades da liga" subtitle="Mercados com melhor índice estatístico" href="/analises" icon={<span>📈</span>} />
        <div className="grid gap-2 sm:grid-cols-2">
          {insights.slice(0, 4).map((row) => (
            <InsightCard key={row.insight.id} insight={row.insight} matchLabel={row.homeShort && row.awayShort ? `${row.homeShort} x ${row.awayShort}` : undefined} href={row.matchId ? `/jogos/${row.matchId}` : undefined} />
          ))}
        </div>
      </section>

      <section className="card px-3 py-2.5">
        <p className="text-[0.75rem] font-bold">Sobre a cobertura</p>
        <p className="mt-1 text-[0.66rem] leading-relaxed muted">
          Dados de gols, escanteios, cartões, faltas e impedimentos são cruzados com o histórico de cada clube. As médias da competição
          ajudam a identificar jogos acima ou abaixo do padrão ofensivo. Use as informações como apoio analítico — não há garantia de resultados.
        </p>
      </section>
    </div>
  );
}

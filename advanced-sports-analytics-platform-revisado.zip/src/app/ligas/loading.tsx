import { TileRowSkeleton, MatchListSkeleton } from "@/components/skeletons";
export default function Loading() { return <div className="space-y-4"><TileRowSkeleton count={4} /><MatchListSkeleton rows={6} header={false} /></div>; }

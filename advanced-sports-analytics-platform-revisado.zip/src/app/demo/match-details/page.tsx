import Link from "next/link";
import MatchDetails, { mockEvents } from "@/components/match-details";

export const dynamic = "force-static";

/** Demonstração do componente MatchDetails com o array mockEvents (sem depender de API). */
export default function MatchDetailsDemoPage() {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between"><Link href="/jogos" className="chip">← Jogos</Link><span className="chip !border-amber-500/40 !text-amber-500">componente com dados mock</span></div>
      <MatchDetails
        casa={{ nome: "Atlético-MG", sigla: "CAM", cor: "#1f1f1f" }}
        fora={{ nome: "Vasco da Gama", sigla: "VAS", cor: "#0b0b0b" }}
        placar={{ casa: 1, fora: 2 }}
        status="Encerrado"
        competicao="Brasileirão Série A · Rodada 31"
        dataHora="18/10 · 16:00"
        estadio="Arena MRV"
        eventos={mockEvents}
        estatisticas={[
          { label: "Posse de bola", casa: 58, fora: 42, sufixo: "%", icone: "⏱️" },
          { label: "Finalizações", casa: 14, fora: 9, icone: "🎯" },
          { label: "No alvo", casa: 5, fora: 4, icone: "🥅" },
          { label: "Escanteios", casa: 7, fora: 3, icone: "🚩" },
          { label: "Faltas", casa: 13, fora: 16, icone: "✋" },
          { label: "Cartões", casa: 2, fora: 3, icone: "🟨" },
        ]}
        avancadas={[
          { label: "Precisão (no alvo %)", casa: 36, fora: 44, sufixo: "%" },
          { label: "Fora do alvo", casa: 9, fora: 5 },
        ]}
        formacoes={{
          casa: { formacao: "4-2-3-1", tecnico: "Gabriel Milito", titulares: [{ numero: 1, nome: "Everson", posicao: "GOL" }, { numero: 2, nome: "Saravia", posicao: "LAT" }, { numero: 3, nome: "Lyanco", posicao: "ZAG" }, { numero: 4, nome: "Igor Rabello", posicao: "ZAG" }, { numero: 6, nome: "Arana", posicao: "LAT" }, { numero: 5, nome: "Battaglia", posicao: "VOL" }, { numero: 8, nome: "Otávio", posicao: "VOL" }, { numero: 10, nome: "Scarpa", posicao: "MEI" }, { numero: 7, nome: "Hulk", posicao: "ATA" }, { numero: 11, nome: "Paulinho", posicao: "ATA" }, { numero: 9, nome: "Castillo R.", posicao: "ATA" }] },
          fora: { formacao: "4-3-3", tecnico: "Fernando Diniz", titulares: [{ numero: 1, nome: "Léo Jardim", posicao: "GOL" }, { numero: 2, nome: "Paulo Henrique", posicao: "LAT" }, { numero: 3, nome: "João Victor", posicao: "ZAG" }, { numero: 4, nome: "Léo", posicao: "ZAG" }, { numero: 6, nome: "Lucas Piton", posicao: "LAT" }, { numero: 5, nome: "Hugo Moura", posicao: "VOL" }, { numero: 8, nome: "Coutinho", posicao: "MEI" }, { numero: 10, nome: "Payet", posicao: "MEI" }, { numero: 7, nome: "Rayan", posicao: "ATA" }, { numero: 11, nome: "Barreal A.", posicao: "ATA" }, { numero: 9, nome: "Vegetti", posicao: "ATA" }] },
        }}
        demo
      />
      <p className="px-1 text-[0.6rem] muted">Em jogos reais, acesse <code>/jogos/[id]/detalhes</code>: a mesma tela é preenchida com os eventos oficiais (gols com assistência, cartões, substituições com quem saiu/entrou, acréscimos).</p>
    </div>
  );
}

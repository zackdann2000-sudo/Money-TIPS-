# Proxy OneSignal (Cloudflare Workers)

1. Acesse https://dash.cloudflare.com/?account=workers → **Create Worker** → nome `onesignal-proxy`.
2. Apague o código padrão, cole `index.js` e troque `MYSUBDOMAIN` pela URL que o Cloudflare mostrar
   (ex.: `https://onesignal-proxy.zackdann.workers.dev`). **Deploy**.
3. Teste: `https://SEU-WORKER.workers.dev/sdks/web/v16/TwoSignalSDK.page.js` deve devolver JavaScript.
4. No site, abra `src/lib/onesignal-config.ts` e cole a mesma URL em `ONESIGNAL_PROXY_BASE`. Rebuild.

Enquanto `ONESIGNAL_PROXY_BASE` estiver vazio, o site usa o proxy embutido em `/osproxy` (mesmo domínio),
que já funciona sem Cloudflare.
